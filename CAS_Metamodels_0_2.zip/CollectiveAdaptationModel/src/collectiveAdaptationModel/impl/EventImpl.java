/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.Adaptation;
import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.Event;
import collectiveAdaptationModel.IssueType;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.EventImpl#getAdaptation <em>Adaptation</em>}</li>
 *   <li>{@link collectiveAdaptationModel.impl.EventImpl#getIssue <em>Issue</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EventImpl extends NamedElementImpl implements Event {
	/**
	 * The cached value of the '{@link #getAdaptation() <em>Adaptation</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdaptation()
	 * @generated
	 * @ordered
	 */
	protected EList<Adaptation> adaptation;

	/**
	 * The cached value of the '{@link #getIssue() <em>Issue</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIssue()
	 * @generated
	 * @ordered
	 */
	protected IssueType issue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.EVENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Adaptation> getAdaptation() {
		if (adaptation == null) {
			adaptation = new EObjectResolvingEList<Adaptation>(Adaptation.class, this, CollectiveAdaptationModelPackage.EVENT__ADAPTATION);
		}
		return adaptation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IssueType getIssue() {
		if (issue != null && issue.eIsProxy()) {
			InternalEObject oldIssue = (InternalEObject)issue;
			issue = (IssueType)eResolveProxy(oldIssue);
			if (issue != oldIssue) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollectiveAdaptationModelPackage.EVENT__ISSUE, oldIssue, issue));
			}
		}
		return issue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IssueType basicGetIssue() {
		return issue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIssue(IssueType newIssue) {
		IssueType oldIssue = issue;
		issue = newIssue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollectiveAdaptationModelPackage.EVENT__ISSUE, oldIssue, issue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT__ADAPTATION:
				return getAdaptation();
			case CollectiveAdaptationModelPackage.EVENT__ISSUE:
				if (resolve) return getIssue();
				return basicGetIssue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT__ADAPTATION:
				getAdaptation().clear();
				getAdaptation().addAll((Collection<? extends Adaptation>)newValue);
				return;
			case CollectiveAdaptationModelPackage.EVENT__ISSUE:
				setIssue((IssueType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT__ADAPTATION:
				getAdaptation().clear();
				return;
			case CollectiveAdaptationModelPackage.EVENT__ISSUE:
				setIssue((IssueType)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT__ADAPTATION:
				return adaptation != null && !adaptation.isEmpty();
			case CollectiveAdaptationModelPackage.EVENT__ISSUE:
				return issue != null;
		}
		return super.eIsSet(featureID);
	}

} //EventImpl
