/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.CollectiveAdaptation;
import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.EventHandler;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collective Adaptation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.CollectiveAdaptationImpl#getEventhandlers <em>Eventhandlers</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CollectiveAdaptationImpl extends MinimalEObjectImpl.Container implements CollectiveAdaptation {
	/**
	 * The cached value of the '{@link #getEventhandlers() <em>Eventhandlers</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEventhandlers()
	 * @generated
	 * @ordered
	 */
	protected EList<EventHandler> eventhandlers;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollectiveAdaptationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.COLLECTIVE_ADAPTATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EventHandler> getEventhandlers() {
		if (eventhandlers == null) {
			eventhandlers = new EObjectContainmentEList<EventHandler>(EventHandler.class, this, CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION__EVENTHANDLERS);
		}
		return eventhandlers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION__EVENTHANDLERS:
				return ((InternalEList<?>)getEventhandlers()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION__EVENTHANDLERS:
				return getEventhandlers();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION__EVENTHANDLERS:
				getEventhandlers().clear();
				getEventhandlers().addAll((Collection<? extends EventHandler>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION__EVENTHANDLERS:
				getEventhandlers().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION__EVENTHANDLERS:
				return eventhandlers != null && !eventhandlers.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CollectiveAdaptationImpl
