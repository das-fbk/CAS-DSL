/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.ecore.EObject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solver</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.Solver#getSolverSpecification <em>Solver Specification</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getSolver()
 * @model
 * @generated
 */
public interface Solver extends EObject {

	/**
	 * Returns the value of the '<em><b>Solver Specification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Solver Specification</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Solver Specification</em>' reference.
	 * @see #setSolverSpecification(ensembleModel.Solver)
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getSolver_SolverSpecification()
	 * @model required="true"
	 * @generated
	 */
	ensembleModel.Solver getSolverSpecification();

	/**
	 * Sets the value of the '{@link collectiveAdaptationModel.Solver#getSolverSpecification <em>Solver Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Solver Specification</em>' reference.
	 * @see #getSolverSpecification()
	 * @generated
	 */
	void setSolverSpecification(ensembleModel.Solver value);
} // Solver
