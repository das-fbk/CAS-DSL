/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collective Adaptation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.CollectiveAdaptation#getEventhandlers <em>Eventhandlers</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getCollectiveAdaptation()
 * @model
 * @generated
 */
public interface CollectiveAdaptation extends EObject {
	/**
	 * Returns the value of the '<em><b>Eventhandlers</b></em>' containment reference list.
	 * The list contents are of type {@link collectiveAdaptationModel.EventHandler}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Eventhandlers</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Eventhandlers</em>' containment reference list.
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getCollectiveAdaptation_Eventhandlers()
	 * @model containment="true"
	 * @generated
	 */
	EList<EventHandler> getEventhandlers();

} // CollectiveAdaptation
