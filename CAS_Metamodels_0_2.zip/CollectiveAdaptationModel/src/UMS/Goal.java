/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Goal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.Goal#getAbstractactivity <em>Abstractactivity</em>}</li>
 *   <li>{@link UMS.Goal#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getGoal()
 * @model
 * @generated
 */
public interface Goal extends Annotation {
	/**
	 * Returns the value of the '<em><b>Abstractactivity</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.AbstractActivity#getGoal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Abstractactivity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abstractactivity</em>' reference.
	 * @see #setAbstractactivity(AbstractActivity)
	 * @see UMS.UMSPackage#getGoal_Abstractactivity()
	 * @see UMS.AbstractActivity#getGoal
	 * @model opposite="goal"
	 * @generated
	 */
	AbstractActivity getAbstractactivity();

	/**
	 * Sets the value of the '{@link UMS.Goal#getAbstractactivity <em>Abstractactivity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Abstractactivity</em>' reference.
	 * @see #getAbstractactivity()
	 * @generated
	 */
	void setAbstractactivity(AbstractActivity value);

	/**
	 * Returns the value of the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstate</em>' reference.
	 * @see #setLstate(LState)
	 * @see UMS.UMSPackage#getGoal_Lstate()
	 * @model
	 * @generated
	 */
	LState getLstate();

	/**
	 * Sets the value of the '{@link UMS.Goal#getLstate <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lstate</em>' reference.
	 * @see #getLstate()
	 * @generated
	 */
	void setLstate(LState value);

} // Goal
