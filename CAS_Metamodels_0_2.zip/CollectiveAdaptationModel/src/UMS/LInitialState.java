/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LInitial State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.LInitialState#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getLInitialState()
 * @model
 * @generated
 */
public interface LInitialState extends LState {
	/**
	 * Returns the value of the '<em><b>Outgoingltransition IS</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoingltransition IS</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoingltransition IS</em>' reference.
	 * @see #setOutgoingltransitionIS(OutgoingLTransition)
	 * @see UMS.UMSPackage#getLInitialState_OutgoingltransitionIS()
	 * @see UMS.OutgoingLTransition#getLinitialstate
	 * @model opposite="linitialstate"
	 * @generated
	 */
	OutgoingLTransition getOutgoingltransitionIS();

	/**
	 * Sets the value of the '{@link UMS.LInitialState#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outgoingltransition IS</em>' reference.
	 * @see #getOutgoingltransitionIS()
	 * @generated
	 */
	void setOutgoingltransitionIS(OutgoingLTransition value);

} // LInitialState
