/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Effect</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.Effect#getActivity <em>Activity</em>}</li>
 *   <li>{@link UMS.Effect#getLevent <em>Levent</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getEffect()
 * @model
 * @generated
 */
public interface Effect extends Annotation {
	/**
	 * Returns the value of the '<em><b>Activity</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.Activity#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activity</em>' reference.
	 * @see #setActivity(Activity)
	 * @see UMS.UMSPackage#getEffect_Activity()
	 * @see UMS.Activity#getEffect
	 * @model opposite="effect"
	 * @generated
	 */
	Activity getActivity();

	/**
	 * Sets the value of the '{@link UMS.Effect#getActivity <em>Activity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activity</em>' reference.
	 * @see #getActivity()
	 * @generated
	 */
	void setActivity(Activity value);

	/**
	 * Returns the value of the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Levent</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Levent</em>' reference.
	 * @see #setLevent(LEvent)
	 * @see UMS.UMSPackage#getEffect_Levent()
	 * @model
	 * @generated
	 */
	LEvent getLevent();

	/**
	 * Sets the value of the '{@link UMS.Effect#getLevent <em>Levent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Levent</em>' reference.
	 * @see #getLevent()
	 * @generated
	 */
	void setLevent(LEvent value);

} // Effect
