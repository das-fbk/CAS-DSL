/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.OutputActivity#getOutgoingtransition <em>Outgoingtransition</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getOutputActivity()
 * @model
 * @generated
 */
public interface OutputActivity extends Activity {
	/**
	 * Returns the value of the '<em><b>Outgoingtransition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.OutgoingTransition#getOutputactivity <em>Outputactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoingtransition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoingtransition</em>' reference.
	 * @see #setOutgoingtransition(OutgoingTransition)
	 * @see UMS.UMSPackage#getOutputActivity_Outgoingtransition()
	 * @see UMS.OutgoingTransition#getOutputactivity
	 * @model opposite="outputactivity"
	 * @generated
	 */
	OutgoingTransition getOutgoingtransition();

	/**
	 * Sets the value of the '{@link UMS.OutputActivity#getOutgoingtransition <em>Outgoingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outgoingtransition</em>' reference.
	 * @see #getOutgoingtransition()
	 * @generated
	 */
	void setOutgoingtransition(OutgoingTransition value);

} // OutputActivity
