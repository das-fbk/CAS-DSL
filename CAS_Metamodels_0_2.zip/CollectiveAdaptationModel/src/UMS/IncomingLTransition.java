/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Incoming LTransition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.IncomingLTransition#getLevent <em>Levent</em>}</li>
 *   <li>{@link UMS.IncomingLTransition#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getIncomingLTransition()
 * @model
 * @generated
 */
public interface IncomingLTransition extends LTransition {
	/**
	 * Returns the value of the '<em><b>Levent</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.LEvent#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Levent</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Levent</em>' reference.
	 * @see #setLevent(LEvent)
	 * @see UMS.UMSPackage#getIncomingLTransition_Levent()
	 * @see UMS.LEvent#getIncomingltransition
	 * @model opposite="incomingltransition"
	 * @generated
	 */
	LEvent getLevent();

	/**
	 * Sets the value of the '{@link UMS.IncomingLTransition#getLevent <em>Levent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Levent</em>' reference.
	 * @see #getLevent()
	 * @generated
	 */
	void setLevent(LEvent value);

	/**
	 * Returns the value of the '<em><b>Lstate</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.LState#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstate</em>' reference.
	 * @see #setLstate(LState)
	 * @see UMS.UMSPackage#getIncomingLTransition_Lstate()
	 * @see UMS.LState#getIncomingltransition
	 * @model opposite="incomingltransition"
	 * @generated
	 */
	LState getLstate();

	/**
	 * Sets the value of the '{@link UMS.IncomingLTransition#getLstate <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lstate</em>' reference.
	 * @see #getLstate()
	 * @generated
	 */
	void setLstate(LState value);

} // IncomingLTransition
