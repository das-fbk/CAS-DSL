/**
 */
package ensembleModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.Role#getDORoleName <em>DO Role Name</em>}</li>
 *   <li>{@link ensembleModel.Role#getTriggeredIssues <em>Triggered Issues</em>}</li>
 *   <li>{@link ensembleModel.Role#getRoleSolvers <em>Role Solvers</em>}</li>
 *   <li>{@link ensembleModel.Role#getRoleParameters <em>Role Parameters</em>}</li>
 *   <li>{@link ensembleModel.Role#getPreferences <em>Preferences</em>}</li>
 *   <li>{@link ensembleModel.Role#getDomainobject <em>Domainobject</em>}</li>
 * </ul>
 *
 * @see ensembleModel.EnsembleModelPackage#getRole()
 * @model
 * @generated
 */
public interface Role extends EObject {
	/**
	 * Returns the value of the '<em><b>DO Role Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>DO Role Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>DO Role Name</em>' attribute.
	 * @see #setDORoleName(String)
	 * @see ensembleModel.EnsembleModelPackage#getRole_DORoleName()
	 * @model
	 * @generated
	 */
	String getDORoleName();

	/**
	 * Sets the value of the '{@link ensembleModel.Role#getDORoleName <em>DO Role Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>DO Role Name</em>' attribute.
	 * @see #getDORoleName()
	 * @generated
	 */
	void setDORoleName(String value);

	/**
	 * Returns the value of the '<em><b>Triggered Issues</b></em>' reference list.
	 * The list contents are of type {@link ensembleModel.IssueType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Triggered Issues</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Triggered Issues</em>' reference list.
	 * @see ensembleModel.EnsembleModelPackage#getRole_TriggeredIssues()
	 * @model
	 * @generated
	 */
	EList<IssueType> getTriggeredIssues();

	/**
	 * Returns the value of the '<em><b>Role Solvers</b></em>' containment reference list.
	 * The list contents are of type {@link ensembleModel.Solver}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Role Solvers</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role Solvers</em>' containment reference list.
	 * @see ensembleModel.EnsembleModelPackage#getRole_RoleSolvers()
	 * @model containment="true"
	 * @generated
	 */
	EList<Solver> getRoleSolvers();

	/**
	 * Returns the value of the '<em><b>Role Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link ensembleModel.RoleParameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Role Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role Parameters</em>' containment reference list.
	 * @see ensembleModel.EnsembleModelPackage#getRole_RoleParameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<RoleParameter> getRoleParameters();

	/**
	 * Returns the value of the '<em><b>Preferences</b></em>' containment reference list.
	 * The list contents are of type {@link ensembleModel.Preference}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Preferences</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Preferences</em>' containment reference list.
	 * @see ensembleModel.EnsembleModelPackage#getRole_Preferences()
	 * @model containment="true"
	 * @generated
	 */
	EList<Preference> getPreferences();

	/**
	 * Returns the value of the '<em><b>Domainobject</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ensembleModel.DomainObject#getRoles <em>Roles</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Domainobject</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Domainobject</em>' reference.
	 * @see #setDomainobject(DomainObject)
	 * @see ensembleModel.EnsembleModelPackage#getRole_Domainobject()
	 * @see ensembleModel.DomainObject#getRoles
	 * @model opposite="roles" required="true"
	 * @generated
	 */
	DomainObject getDomainobject();

	/**
	 * Sets the value of the '{@link ensembleModel.Role#getDomainobject <em>Domainobject</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Domainobject</em>' reference.
	 * @see #getDomainobject()
	 * @generated
	 */
	void setDomainobject(DomainObject value);

} // Role
