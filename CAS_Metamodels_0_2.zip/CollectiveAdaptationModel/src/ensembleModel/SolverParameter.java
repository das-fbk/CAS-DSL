/**
 */
package ensembleModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solver Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ensembleModel.EnsembleModelPackage#getSolverParameter()
 * @model
 * @generated
 */
public interface SolverParameter extends NamedValue {
} // SolverParameter
