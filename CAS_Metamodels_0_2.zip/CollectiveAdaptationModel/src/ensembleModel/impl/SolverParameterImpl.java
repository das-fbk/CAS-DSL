/**
 */
package ensembleModel.impl;

import ensembleModel.EnsembleModelPackage;
import ensembleModel.SolverParameter;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Solver Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SolverParameterImpl extends NamedValueImpl implements SolverParameter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SolverParameterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.SOLVER_PARAMETER;
	}

} //SolverParameterImpl
