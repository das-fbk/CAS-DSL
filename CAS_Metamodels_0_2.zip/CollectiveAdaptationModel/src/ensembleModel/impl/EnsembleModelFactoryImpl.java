/**
 */
package ensembleModel.impl;

import ensembleModel.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class EnsembleModelFactoryImpl extends EFactoryImpl implements EnsembleModelFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static EnsembleModelFactory init() {
		try {
			EnsembleModelFactory theEnsembleModelFactory = (EnsembleModelFactory)EPackage.Registry.INSTANCE.getEFactory(EnsembleModelPackage.eNS_URI);
			if (theEnsembleModelFactory != null) {
				return theEnsembleModelFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new EnsembleModelFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnsembleModelFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case EnsembleModelPackage.ENSEMBLE: return createEnsemble();
			case EnsembleModelPackage.ROLE: return createRole();
			case EnsembleModelPackage.ISSUE_TYPE: return createIssueType();
			case EnsembleModelPackage.SOLVER: return createSolver();
			case EnsembleModelPackage.ROLE_PARAMETER: return createRoleParameter();
			case EnsembleModelPackage.PREFERENCE: return createPreference();
			case EnsembleModelPackage.ISSUE_PARAMETER: return createIssueParameter();
			case EnsembleModelPackage.SOLVER_PARAMETER: return createSolverParameter();
			case EnsembleModelPackage.DOMAIN_OBJECT: return createDomainObject();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ensemble createEnsemble() {
		EnsembleImpl ensemble = new EnsembleImpl();
		return ensemble;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Role createRole() {
		RoleImpl role = new RoleImpl();
		return role;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IssueType createIssueType() {
		IssueTypeImpl issueType = new IssueTypeImpl();
		return issueType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Solver createSolver() {
		SolverImpl solver = new SolverImpl();
		return solver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleParameter createRoleParameter() {
		RoleParameterImpl roleParameter = new RoleParameterImpl();
		return roleParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Preference createPreference() {
		PreferenceImpl preference = new PreferenceImpl();
		return preference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IssueParameter createIssueParameter() {
		IssueParameterImpl issueParameter = new IssueParameterImpl();
		return issueParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SolverParameter createSolverParameter() {
		SolverParameterImpl solverParameter = new SolverParameterImpl();
		return solverParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainObject createDomainObject() {
		DomainObjectImpl domainObject = new DomainObjectImpl();
		return domainObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnsembleModelPackage getEnsembleModelPackage() {
		return (EnsembleModelPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static EnsembleModelPackage getPackage() {
		return EnsembleModelPackage.eINSTANCE;
	}

} //EnsembleModelFactoryImpl
