/**
 */
package ensembleModel.impl;

import ensembleModel.EnsembleModelPackage;
import ensembleModel.IssueParameter;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Issue Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IssueParameterImpl extends NamedValueImpl implements IssueParameter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IssueParameterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.ISSUE_PARAMETER;
	}

} //IssueParameterImpl
