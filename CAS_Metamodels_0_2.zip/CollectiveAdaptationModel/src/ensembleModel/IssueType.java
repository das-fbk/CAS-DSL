/**
 */
package ensembleModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Issue Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.IssueType#getName <em>Name</em>}</li>
 *   <li>{@link ensembleModel.IssueType#getIssueParameters <em>Issue Parameters</em>}</li>
 *   <li>{@link ensembleModel.IssueType#getSolvers <em>Solvers</em>}</li>
 * </ul>
 *
 * @see ensembleModel.EnsembleModelPackage#getIssueType()
 * @model
 * @generated
 */
public interface IssueType extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ensembleModel.EnsembleModelPackage#getIssueType_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ensembleModel.IssueType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Issue Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link ensembleModel.IssueParameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Issue Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Issue Parameters</em>' containment reference list.
	 * @see ensembleModel.EnsembleModelPackage#getIssueType_IssueParameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<IssueParameter> getIssueParameters();

	/**
	 * Returns the value of the '<em><b>Solvers</b></em>' reference list.
	 * The list contents are of type {@link ensembleModel.Solver}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Solvers</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Solvers</em>' reference list.
	 * @see ensembleModel.EnsembleModelPackage#getIssueType_Solvers()
	 * @model
	 * @generated
	 */
	EList<Solver> getSolvers();

} // IssueType
