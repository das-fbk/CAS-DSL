/**
 */
package ensembleModel.tests;

import ensembleModel.NamedValue;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Named Value</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class NamedValueTest extends TestCase {

	/**
	 * The fixture for this Named Value test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NamedValue fixture = null;

	/**
	 * Constructs a new Named Value test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NamedValueTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Named Value test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(NamedValue fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Named Value test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NamedValue getFixture() {
		return fixture;
	}

} //NamedValueTest
