/**
 */
package ensembleModel.tests;

import ensembleModel.EnsembleModelFactory;
import ensembleModel.RoleParameter;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Role Parameter</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class RoleParameterTest extends NamedValueTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(RoleParameterTest.class);
	}

	/**
	 * Constructs a new Role Parameter test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleParameterTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Role Parameter test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected RoleParameter getFixture() {
		return (RoleParameter)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(EnsembleModelFactory.eINSTANCE.createRoleParameter());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //RoleParameterTest
