/**
 */
package UMS.tests;

import UMS.OutgoingLTransition;
import UMS.UMSFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Outgoing LTransition</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class OutgoingLTransitionTest extends LTransitionTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(OutgoingLTransitionTest.class);
	}

	/**
	 * Constructs a new Outgoing LTransition test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransitionTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Outgoing LTransition test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected OutgoingLTransition getFixture() {
		return (OutgoingLTransition)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(UMSFactory.eINSTANCE.createOutgoingLTransition());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //OutgoingLTransitionTest
