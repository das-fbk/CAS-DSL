/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getFragment()
 * @model
 * @generated
 */
public interface Fragment extends AdaptiveSystemMM.Process {
} // Fragment
