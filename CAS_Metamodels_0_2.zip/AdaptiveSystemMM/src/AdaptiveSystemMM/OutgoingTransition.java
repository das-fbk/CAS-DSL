/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Outgoing Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.OutgoingTransition#getState <em>State</em>}</li>
 *   <li>{@link AdaptiveSystemMM.OutgoingTransition#getOutputactivity <em>Outputactivity</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingTransition()
 * @model
 * @generated
 */
public interface OutgoingTransition extends Transition {
	/**
	 * Returns the value of the '<em><b>State</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.State#getOutgoingtransition <em>Outgoingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' reference.
	 * @see #setState(State)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingTransition_State()
	 * @see AdaptiveSystemMM.State#getOutgoingtransition
	 * @model opposite="outgoingtransition"
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.OutgoingTransition#getState <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

	/**
	 * Returns the value of the '<em><b>Outputactivity</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.OutputActivity#getOutgoingtransition <em>Outgoingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outputactivity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outputactivity</em>' reference.
	 * @see #setOutputactivity(OutputActivity)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingTransition_Outputactivity()
	 * @see AdaptiveSystemMM.OutputActivity#getOutgoingtransition
	 * @model opposite="outgoingtransition"
	 * @generated
	 */
	OutputActivity getOutputactivity();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.OutgoingTransition#getOutputactivity <em>Outputactivity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outputactivity</em>' reference.
	 * @see #getOutputactivity()
	 * @generated
	 */
	void setOutputactivity(OutputActivity value);

} // OutgoingTransition
