/**
 */
package AdaptiveSystemMM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Domain Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.DomainObject#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.DomainObject#getCore_process <em>Core process</em>}</li>
 *   <li>{@link AdaptiveSystemMM.DomainObject#getFragment <em>Fragment</em>}</li>
 *   <li>{@link AdaptiveSystemMM.DomainObject#getInternaldomainknowledge <em>Internaldomainknowledge</em>}</li>
 *   <li>{@link AdaptiveSystemMM.DomainObject#getExternaldomainknowledge <em>Externaldomainknowledge</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getDomainObject()
 * @model
 * @generated
 */
public interface DomainObject extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getDomainObject_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.DomainObject#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Core process</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Core process</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Core process</em>' containment reference.
	 * @see #setCore_process(CoreProcess)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getDomainObject_Core_process()
	 * @model containment="true" required="true"
	 * @generated
	 */
	CoreProcess getCore_process();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.DomainObject#getCore_process <em>Core process</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Core process</em>' containment reference.
	 * @see #getCore_process()
	 * @generated
	 */
	void setCore_process(CoreProcess value);

	/**
	 * Returns the value of the '<em><b>Fragment</b></em>' containment reference list.
	 * The list contents are of type {@link AdaptiveSystemMM.Fragment}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fragment</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fragment</em>' containment reference list.
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getDomainObject_Fragment()
	 * @model containment="true"
	 * @generated
	 */
	EList<Fragment> getFragment();

	/**
	 * Returns the value of the '<em><b>Internaldomainknowledge</b></em>' containment reference list.
	 * The list contents are of type {@link AdaptiveSystemMM.DomainProperty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Internaldomainknowledge</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internaldomainknowledge</em>' containment reference list.
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getDomainObject_Internaldomainknowledge()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<DomainProperty> getInternaldomainknowledge();

	/**
	 * Returns the value of the '<em><b>Externaldomainknowledge</b></em>' reference list.
	 * The list contents are of type {@link AdaptiveSystemMM.DomainProperty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Externaldomainknowledge</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Externaldomainknowledge</em>' reference list.
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getDomainObject_Externaldomainknowledge()
	 * @model required="true"
	 * @generated
	 */
	EList<DomainProperty> getExternaldomainknowledge();

} // DomainObject
