/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Core Process</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getCoreProcess()
 * @model
 * @generated
 */
public interface CoreProcess extends AdaptiveSystemMM.Process {
} // CoreProcess
