/**
 */
package AdaptiveSystemMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LState</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.LState#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.LState#getIncomingltransition <em>Incomingltransition</em>}</li>
 *   <li>{@link AdaptiveSystemMM.LState#getOutgoingltransition <em>Outgoingltransition</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getLState()
 * @model
 * @generated
 */
public interface LState extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getLState_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.LState#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Incomingltransition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.IncomingLTransition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incomingltransition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incomingltransition</em>' reference.
	 * @see #setIncomingltransition(IncomingLTransition)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getLState_Incomingltransition()
	 * @see AdaptiveSystemMM.IncomingLTransition#getLstate
	 * @model opposite="lstate"
	 * @generated
	 */
	IncomingLTransition getIncomingltransition();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.LState#getIncomingltransition <em>Incomingltransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Incomingltransition</em>' reference.
	 * @see #getIncomingltransition()
	 * @generated
	 */
	void setIncomingltransition(IncomingLTransition value);

	/**
	 * Returns the value of the '<em><b>Outgoingltransition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.OutgoingLTransition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoingltransition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoingltransition</em>' reference.
	 * @see #setOutgoingltransition(OutgoingLTransition)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getLState_Outgoingltransition()
	 * @see AdaptiveSystemMM.OutgoingLTransition#getLstate
	 * @model opposite="lstate"
	 * @generated
	 */
	OutgoingLTransition getOutgoingltransition();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.LState#getOutgoingltransition <em>Outgoingltransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outgoingltransition</em>' reference.
	 * @see #getOutgoingltransition()
	 * @generated
	 */
	void setOutgoingltransition(OutgoingLTransition value);

} // LState
