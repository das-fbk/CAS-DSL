/**
 */
package AdaptiveSystemMM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see AdaptiveSystemMM.AdaptiveSystemMMFactory
 * @model kind="package"
 * @generated
 */
public interface AdaptiveSystemMMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "AdaptiveSystemMM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/AdaptiveSystemMM";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "AdaptiveSystemMM";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AdaptiveSystemMMPackage eINSTANCE = AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl.init();

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.DomainObjectImpl <em>Domain Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.DomainObjectImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getDomainObject()
	 * @generated
	 */
	int DOMAIN_OBJECT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Core process</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__CORE_PROCESS = 1;

	/**
	 * The feature id for the '<em><b>Fragment</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__FRAGMENT = 2;

	/**
	 * The feature id for the '<em><b>Internaldomainknowledge</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE = 3;

	/**
	 * The feature id for the '<em><b>Externaldomainknowledge</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE = 4;

	/**
	 * The number of structural features of the '<em>Domain Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Domain Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.ProcessImpl <em>Process</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.ProcessImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getProcess()
	 * @generated
	 */
	int PROCESS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Activities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__ACTIVITIES = 1;

	/**
	 * The feature id for the '<em><b>States</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__STATES = 2;

	/**
	 * The feature id for the '<em><b>Transitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__TRANSITIONS = 3;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__ANNOTATIONS = 4;

	/**
	 * The number of structural features of the '<em>Process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.ActivityImpl <em>Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.ActivityImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getActivity()
	 * @generated
	 */
	int ACTIVITY = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__PRECONDITION = 1;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__EFFECT = 2;

	/**
	 * The number of structural features of the '<em>Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.InputActivityImpl <em>Input Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.InputActivityImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getInputActivity()
	 * @generated
	 */
	int INPUT_ACTIVITY = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The feature id for the '<em><b>Incomingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__INCOMINGTRANSITION = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Input Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Input Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.OutputActivityImpl <em>Output Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.OutputActivityImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getOutputActivity()
	 * @generated
	 */
	int OUTPUT_ACTIVITY = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The feature id for the '<em><b>Outgoingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__OUTGOINGTRANSITION = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Output Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Output Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.AbstractActivityImpl <em>Abstract Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.AbstractActivityImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getAbstractActivity()
	 * @generated
	 */
	int ABSTRACT_ACTIVITY = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The feature id for the '<em><b>Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__GOAL = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Abstract Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Abstract Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.ConcreteActivityImpl <em>Concrete Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.ConcreteActivityImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getConcreteActivity()
	 * @generated
	 */
	int CONCRETE_ACTIVITY = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The number of structural features of the '<em>Concrete Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Concrete Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.StateImpl <em>State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.StateImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getState()
	 * @generated
	 */
	int STATE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Is Initial</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__IS_INITIAL = 1;

	/**
	 * The feature id for the '<em><b>Incomingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__INCOMINGTRANSITION = 2;

	/**
	 * The feature id for the '<em><b>Outgoingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__OUTGOINGTRANSITION = 3;

	/**
	 * The number of structural features of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.TransitionImpl <em>Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.TransitionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getTransition()
	 * @generated
	 */
	int TRANSITION = 8;

	/**
	 * The number of structural features of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.OutgoingTransitionImpl <em>Outgoing Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.OutgoingTransitionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getOutgoingTransition()
	 * @generated
	 */
	int OUTGOING_TRANSITION = 9;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION__STATE = TRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Outputactivity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION__OUTPUTACTIVITY = TRANSITION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Outgoing Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION_FEATURE_COUNT = TRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Outgoing Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION_OPERATION_COUNT = TRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.IncomingTransitionImpl <em>Incoming Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.IncomingTransitionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getIncomingTransition()
	 * @generated
	 */
	int INCOMING_TRANSITION = 10;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION__STATE = TRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Inputactivity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION__INPUTACTIVITY = TRANSITION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Incoming Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION_FEATURE_COUNT = TRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Incoming Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION_OPERATION_COUNT = TRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.AnnotationImpl <em>Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.AnnotationImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getAnnotation()
	 * @generated
	 */
	int ANNOTATION = 11;

	/**
	 * The number of structural features of the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.PreconditionImpl <em>Precondition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.PreconditionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getPrecondition()
	 * @generated
	 */
	int PRECONDITION = 12;

	/**
	 * The feature id for the '<em><b>Activity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION__ACTIVITY = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION__LSTATE = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Precondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Precondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.EffectImpl <em>Effect</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.EffectImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getEffect()
	 * @generated
	 */
	int EFFECT = 13;

	/**
	 * The feature id for the '<em><b>Activity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__ACTIVITY = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__LEVENT = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Effect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Effect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.GoalImpl <em>Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.GoalImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getGoal()
	 * @generated
	 */
	int GOAL = 14;

	/**
	 * The feature id for the '<em><b>Abstractactivity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__ABSTRACTACTIVITY = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__LSTATE = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.DomainPropertyImpl <em>Domain Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.DomainPropertyImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getDomainProperty()
	 * @generated
	 */
	int DOMAIN_PROPERTY = 15;

	/**
	 * The feature id for the '<em><b>Lstates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LSTATES = 0;

	/**
	 * The feature id for the '<em><b>Linitialstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LINITIALSTATE = 1;

	/**
	 * The feature id for the '<em><b>Levents</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LEVENTS = 2;

	/**
	 * The feature id for the '<em><b>Ltransitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LTRANSITIONS = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__NAME = 4;

	/**
	 * The number of structural features of the '<em>Domain Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Domain Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.LStateImpl <em>LState</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.LStateImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLState()
	 * @generated
	 */
	int LSTATE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Incomingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE__INCOMINGLTRANSITION = 1;

	/**
	 * The feature id for the '<em><b>Outgoingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE__OUTGOINGLTRANSITION = 2;

	/**
	 * The number of structural features of the '<em>LState</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>LState</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.LInitialStateImpl <em>LInitial State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.LInitialStateImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLInitialState()
	 * @generated
	 */
	int LINITIAL_STATE = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__NAME = LSTATE__NAME;

	/**
	 * The feature id for the '<em><b>Incomingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__INCOMINGLTRANSITION = LSTATE__INCOMINGLTRANSITION;

	/**
	 * The feature id for the '<em><b>Outgoingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__OUTGOINGLTRANSITION = LSTATE__OUTGOINGLTRANSITION;

	/**
	 * The feature id for the '<em><b>Outgoingltransition IS</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__OUTGOINGLTRANSITION_IS = LSTATE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>LInitial State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE_FEATURE_COUNT = LSTATE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>LInitial State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE_OPERATION_COUNT = LSTATE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.LEventImpl <em>LEvent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.LEventImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLEvent()
	 * @generated
	 */
	int LEVENT = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Outgoingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT__OUTGOINGLTRANSITION = 1;

	/**
	 * The feature id for the '<em><b>Incomingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT__INCOMINGLTRANSITION = 2;

	/**
	 * The number of structural features of the '<em>LEvent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>LEvent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.LTransitionImpl <em>LTransition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.LTransitionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLTransition()
	 * @generated
	 */
	int LTRANSITION = 19;

	/**
	 * The number of structural features of the '<em>LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LTRANSITION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LTRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.IncomingLTransitionImpl <em>Incoming LTransition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.IncomingLTransitionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getIncomingLTransition()
	 * @generated
	 */
	int INCOMING_LTRANSITION = 20;

	/**
	 * The feature id for the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION__LEVENT = LTRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION__LSTATE = LTRANSITION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Incoming LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION_FEATURE_COUNT = LTRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Incoming LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION_OPERATION_COUNT = LTRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.OutgoingLTransitionImpl <em>Outgoing LTransition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.OutgoingLTransitionImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getOutgoingLTransition()
	 * @generated
	 */
	int OUTGOING_LTRANSITION = 21;

	/**
	 * The feature id for the '<em><b>Linitialstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION__LINITIALSTATE = LTRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION__LEVENT = LTRANSITION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION__LSTATE = LTRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Outgoing LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION_FEATURE_COUNT = LTRANSITION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Outgoing LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION_OPERATION_COUNT = LTRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.AdaptiveSystemImpl <em>Adaptive System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getAdaptiveSystem()
	 * @generated
	 */
	int ADAPTIVE_SYSTEM = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Domainobjects</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM__DOMAINOBJECTS = 1;

	/**
	 * The number of structural features of the '<em>Adaptive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Adaptive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM_OPERATION_COUNT = 0;


	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.CoreProcessImpl <em>Core Process</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.CoreProcessImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getCoreProcess()
	 * @generated
	 */
	int CORE_PROCESS = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS__NAME = PROCESS__NAME;

	/**
	 * The feature id for the '<em><b>Activities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS__ACTIVITIES = PROCESS__ACTIVITIES;

	/**
	 * The feature id for the '<em><b>States</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS__STATES = PROCESS__STATES;

	/**
	 * The feature id for the '<em><b>Transitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS__TRANSITIONS = PROCESS__TRANSITIONS;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS__ANNOTATIONS = PROCESS__ANNOTATIONS;

	/**
	 * The number of structural features of the '<em>Core Process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS_FEATURE_COUNT = PROCESS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Core Process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CORE_PROCESS_OPERATION_COUNT = PROCESS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link AdaptiveSystemMM.impl.FragmentImpl <em>Fragment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see AdaptiveSystemMM.impl.FragmentImpl
	 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getFragment()
	 * @generated
	 */
	int FRAGMENT = 24;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT__NAME = PROCESS__NAME;

	/**
	 * The feature id for the '<em><b>Activities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT__ACTIVITIES = PROCESS__ACTIVITIES;

	/**
	 * The feature id for the '<em><b>States</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT__STATES = PROCESS__STATES;

	/**
	 * The feature id for the '<em><b>Transitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT__TRANSITIONS = PROCESS__TRANSITIONS;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT__ANNOTATIONS = PROCESS__ANNOTATIONS;

	/**
	 * The number of structural features of the '<em>Fragment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT_FEATURE_COUNT = PROCESS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Fragment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAGMENT_OPERATION_COUNT = PROCESS_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.DomainObject <em>Domain Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Domain Object</em>'.
	 * @see AdaptiveSystemMM.DomainObject
	 * @generated
	 */
	EClass getDomainObject();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.DomainObject#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.DomainObject#getName()
	 * @see #getDomainObject()
	 * @generated
	 */
	EAttribute getDomainObject_Name();

	/**
	 * Returns the meta object for the containment reference '{@link AdaptiveSystemMM.DomainObject#getCore_process <em>Core process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Core process</em>'.
	 * @see AdaptiveSystemMM.DomainObject#getCore_process()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Core_process();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.DomainObject#getFragment <em>Fragment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fragment</em>'.
	 * @see AdaptiveSystemMM.DomainObject#getFragment()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Fragment();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.DomainObject#getInternaldomainknowledge <em>Internaldomainknowledge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Internaldomainknowledge</em>'.
	 * @see AdaptiveSystemMM.DomainObject#getInternaldomainknowledge()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Internaldomainknowledge();

	/**
	 * Returns the meta object for the reference list '{@link AdaptiveSystemMM.DomainObject#getExternaldomainknowledge <em>Externaldomainknowledge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Externaldomainknowledge</em>'.
	 * @see AdaptiveSystemMM.DomainObject#getExternaldomainknowledge()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Externaldomainknowledge();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Process <em>Process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Process</em>'.
	 * @see AdaptiveSystemMM.Process
	 * @generated
	 */
	EClass getProcess();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.Process#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.Process#getName()
	 * @see #getProcess()
	 * @generated
	 */
	EAttribute getProcess_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.Process#getActivities <em>Activities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Activities</em>'.
	 * @see AdaptiveSystemMM.Process#getActivities()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_Activities();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.Process#getStates <em>States</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>States</em>'.
	 * @see AdaptiveSystemMM.Process#getStates()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_States();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.Process#getTransitions <em>Transitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transitions</em>'.
	 * @see AdaptiveSystemMM.Process#getTransitions()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_Transitions();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.Process#getAnnotations <em>Annotations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Annotations</em>'.
	 * @see AdaptiveSystemMM.Process#getAnnotations()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_Annotations();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Activity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Activity</em>'.
	 * @see AdaptiveSystemMM.Activity
	 * @generated
	 */
	EClass getActivity();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.Activity#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.Activity#getName()
	 * @see #getActivity()
	 * @generated
	 */
	EAttribute getActivity_Name();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Activity#getPrecondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Precondition</em>'.
	 * @see AdaptiveSystemMM.Activity#getPrecondition()
	 * @see #getActivity()
	 * @generated
	 */
	EReference getActivity_Precondition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Activity#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Effect</em>'.
	 * @see AdaptiveSystemMM.Activity#getEffect()
	 * @see #getActivity()
	 * @generated
	 */
	EReference getActivity_Effect();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.InputActivity <em>Input Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Activity</em>'.
	 * @see AdaptiveSystemMM.InputActivity
	 * @generated
	 */
	EClass getInputActivity();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.InputActivity#getIncomingtransition <em>Incomingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingtransition</em>'.
	 * @see AdaptiveSystemMM.InputActivity#getIncomingtransition()
	 * @see #getInputActivity()
	 * @generated
	 */
	EReference getInputActivity_Incomingtransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.OutputActivity <em>Output Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output Activity</em>'.
	 * @see AdaptiveSystemMM.OutputActivity
	 * @generated
	 */
	EClass getOutputActivity();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.OutputActivity#getOutgoingtransition <em>Outgoingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingtransition</em>'.
	 * @see AdaptiveSystemMM.OutputActivity#getOutgoingtransition()
	 * @see #getOutputActivity()
	 * @generated
	 */
	EReference getOutputActivity_Outgoingtransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.AbstractActivity <em>Abstract Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Activity</em>'.
	 * @see AdaptiveSystemMM.AbstractActivity
	 * @generated
	 */
	EClass getAbstractActivity();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.AbstractActivity#getGoal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Goal</em>'.
	 * @see AdaptiveSystemMM.AbstractActivity#getGoal()
	 * @see #getAbstractActivity()
	 * @generated
	 */
	EReference getAbstractActivity_Goal();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.ConcreteActivity <em>Concrete Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Concrete Activity</em>'.
	 * @see AdaptiveSystemMM.ConcreteActivity
	 * @generated
	 */
	EClass getConcreteActivity();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State</em>'.
	 * @see AdaptiveSystemMM.State
	 * @generated
	 */
	EClass getState();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.State#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.State#getName()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_Name();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.State#isIsInitial <em>Is Initial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Initial</em>'.
	 * @see AdaptiveSystemMM.State#isIsInitial()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_IsInitial();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.State#getIncomingtransition <em>Incomingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingtransition</em>'.
	 * @see AdaptiveSystemMM.State#getIncomingtransition()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Incomingtransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.State#getOutgoingtransition <em>Outgoingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingtransition</em>'.
	 * @see AdaptiveSystemMM.State#getOutgoingtransition()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Outgoingtransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Transition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition</em>'.
	 * @see AdaptiveSystemMM.Transition
	 * @generated
	 */
	EClass getTransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.OutgoingTransition <em>Outgoing Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Outgoing Transition</em>'.
	 * @see AdaptiveSystemMM.OutgoingTransition
	 * @generated
	 */
	EClass getOutgoingTransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.OutgoingTransition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see AdaptiveSystemMM.OutgoingTransition#getState()
	 * @see #getOutgoingTransition()
	 * @generated
	 */
	EReference getOutgoingTransition_State();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.OutgoingTransition#getOutputactivity <em>Outputactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outputactivity</em>'.
	 * @see AdaptiveSystemMM.OutgoingTransition#getOutputactivity()
	 * @see #getOutgoingTransition()
	 * @generated
	 */
	EReference getOutgoingTransition_Outputactivity();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.IncomingTransition <em>Incoming Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Incoming Transition</em>'.
	 * @see AdaptiveSystemMM.IncomingTransition
	 * @generated
	 */
	EClass getIncomingTransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.IncomingTransition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see AdaptiveSystemMM.IncomingTransition#getState()
	 * @see #getIncomingTransition()
	 * @generated
	 */
	EReference getIncomingTransition_State();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.IncomingTransition#getInputactivity <em>Inputactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Inputactivity</em>'.
	 * @see AdaptiveSystemMM.IncomingTransition#getInputactivity()
	 * @see #getIncomingTransition()
	 * @generated
	 */
	EReference getIncomingTransition_Inputactivity();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Annotation <em>Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Annotation</em>'.
	 * @see AdaptiveSystemMM.Annotation
	 * @generated
	 */
	EClass getAnnotation();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Precondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Precondition</em>'.
	 * @see AdaptiveSystemMM.Precondition
	 * @generated
	 */
	EClass getPrecondition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Precondition#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Activity</em>'.
	 * @see AdaptiveSystemMM.Precondition#getActivity()
	 * @see #getPrecondition()
	 * @generated
	 */
	EReference getPrecondition_Activity();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Precondition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see AdaptiveSystemMM.Precondition#getLstate()
	 * @see #getPrecondition()
	 * @generated
	 */
	EReference getPrecondition_Lstate();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Effect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Effect</em>'.
	 * @see AdaptiveSystemMM.Effect
	 * @generated
	 */
	EClass getEffect();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Effect#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Activity</em>'.
	 * @see AdaptiveSystemMM.Effect#getActivity()
	 * @see #getEffect()
	 * @generated
	 */
	EReference getEffect_Activity();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Effect#getLevent <em>Levent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Levent</em>'.
	 * @see AdaptiveSystemMM.Effect#getLevent()
	 * @see #getEffect()
	 * @generated
	 */
	EReference getEffect_Levent();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Goal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Goal</em>'.
	 * @see AdaptiveSystemMM.Goal
	 * @generated
	 */
	EClass getGoal();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Goal#getAbstractactivity <em>Abstractactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Abstractactivity</em>'.
	 * @see AdaptiveSystemMM.Goal#getAbstractactivity()
	 * @see #getGoal()
	 * @generated
	 */
	EReference getGoal_Abstractactivity();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.Goal#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see AdaptiveSystemMM.Goal#getLstate()
	 * @see #getGoal()
	 * @generated
	 */
	EReference getGoal_Lstate();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.DomainProperty <em>Domain Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Domain Property</em>'.
	 * @see AdaptiveSystemMM.DomainProperty
	 * @generated
	 */
	EClass getDomainProperty();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.DomainProperty#getLstates <em>Lstates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Lstates</em>'.
	 * @see AdaptiveSystemMM.DomainProperty#getLstates()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Lstates();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.DomainProperty#getLinitialstate <em>Linitialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Linitialstate</em>'.
	 * @see AdaptiveSystemMM.DomainProperty#getLinitialstate()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Linitialstate();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.DomainProperty#getLevents <em>Levents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Levents</em>'.
	 * @see AdaptiveSystemMM.DomainProperty#getLevents()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Levents();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.DomainProperty#getLtransitions <em>Ltransitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ltransitions</em>'.
	 * @see AdaptiveSystemMM.DomainProperty#getLtransitions()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Ltransitions();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.DomainProperty#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.DomainProperty#getName()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EAttribute getDomainProperty_Name();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.LState <em>LState</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LState</em>'.
	 * @see AdaptiveSystemMM.LState
	 * @generated
	 */
	EClass getLState();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.LState#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.LState#getName()
	 * @see #getLState()
	 * @generated
	 */
	EAttribute getLState_Name();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.LState#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingltransition</em>'.
	 * @see AdaptiveSystemMM.LState#getIncomingltransition()
	 * @see #getLState()
	 * @generated
	 */
	EReference getLState_Incomingltransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.LState#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingltransition</em>'.
	 * @see AdaptiveSystemMM.LState#getOutgoingltransition()
	 * @see #getLState()
	 * @generated
	 */
	EReference getLState_Outgoingltransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.LInitialState <em>LInitial State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LInitial State</em>'.
	 * @see AdaptiveSystemMM.LInitialState
	 * @generated
	 */
	EClass getLInitialState();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.LInitialState#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingltransition IS</em>'.
	 * @see AdaptiveSystemMM.LInitialState#getOutgoingltransitionIS()
	 * @see #getLInitialState()
	 * @generated
	 */
	EReference getLInitialState_OutgoingltransitionIS();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.LEvent <em>LEvent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LEvent</em>'.
	 * @see AdaptiveSystemMM.LEvent
	 * @generated
	 */
	EClass getLEvent();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.LEvent#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.LEvent#getName()
	 * @see #getLEvent()
	 * @generated
	 */
	EAttribute getLEvent_Name();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.LEvent#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingltransition</em>'.
	 * @see AdaptiveSystemMM.LEvent#getOutgoingltransition()
	 * @see #getLEvent()
	 * @generated
	 */
	EReference getLEvent_Outgoingltransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.LEvent#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingltransition</em>'.
	 * @see AdaptiveSystemMM.LEvent#getIncomingltransition()
	 * @see #getLEvent()
	 * @generated
	 */
	EReference getLEvent_Incomingltransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.LTransition <em>LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LTransition</em>'.
	 * @see AdaptiveSystemMM.LTransition
	 * @generated
	 */
	EClass getLTransition();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.IncomingLTransition <em>Incoming LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Incoming LTransition</em>'.
	 * @see AdaptiveSystemMM.IncomingLTransition
	 * @generated
	 */
	EClass getIncomingLTransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.IncomingLTransition#getLevent <em>Levent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Levent</em>'.
	 * @see AdaptiveSystemMM.IncomingLTransition#getLevent()
	 * @see #getIncomingLTransition()
	 * @generated
	 */
	EReference getIncomingLTransition_Levent();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.IncomingLTransition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see AdaptiveSystemMM.IncomingLTransition#getLstate()
	 * @see #getIncomingLTransition()
	 * @generated
	 */
	EReference getIncomingLTransition_Lstate();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.OutgoingLTransition <em>Outgoing LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Outgoing LTransition</em>'.
	 * @see AdaptiveSystemMM.OutgoingLTransition
	 * @generated
	 */
	EClass getOutgoingLTransition();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Linitialstate</em>'.
	 * @see AdaptiveSystemMM.OutgoingLTransition#getLinitialstate()
	 * @see #getOutgoingLTransition()
	 * @generated
	 */
	EReference getOutgoingLTransition_Linitialstate();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.OutgoingLTransition#getLevent <em>Levent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Levent</em>'.
	 * @see AdaptiveSystemMM.OutgoingLTransition#getLevent()
	 * @see #getOutgoingLTransition()
	 * @generated
	 */
	EReference getOutgoingLTransition_Levent();

	/**
	 * Returns the meta object for the reference '{@link AdaptiveSystemMM.OutgoingLTransition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see AdaptiveSystemMM.OutgoingLTransition#getLstate()
	 * @see #getOutgoingLTransition()
	 * @generated
	 */
	EReference getOutgoingLTransition_Lstate();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.AdaptiveSystem <em>Adaptive System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Adaptive System</em>'.
	 * @see AdaptiveSystemMM.AdaptiveSystem
	 * @generated
	 */
	EClass getAdaptiveSystem();

	/**
	 * Returns the meta object for the attribute '{@link AdaptiveSystemMM.AdaptiveSystem#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see AdaptiveSystemMM.AdaptiveSystem#getName()
	 * @see #getAdaptiveSystem()
	 * @generated
	 */
	EAttribute getAdaptiveSystem_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link AdaptiveSystemMM.AdaptiveSystem#getDomainobjects <em>Domainobjects</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Domainobjects</em>'.
	 * @see AdaptiveSystemMM.AdaptiveSystem#getDomainobjects()
	 * @see #getAdaptiveSystem()
	 * @generated
	 */
	EReference getAdaptiveSystem_Domainobjects();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.CoreProcess <em>Core Process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Core Process</em>'.
	 * @see AdaptiveSystemMM.CoreProcess
	 * @generated
	 */
	EClass getCoreProcess();

	/**
	 * Returns the meta object for class '{@link AdaptiveSystemMM.Fragment <em>Fragment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fragment</em>'.
	 * @see AdaptiveSystemMM.Fragment
	 * @generated
	 */
	EClass getFragment();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	AdaptiveSystemMMFactory getAdaptiveSystemMMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.DomainObjectImpl <em>Domain Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.DomainObjectImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getDomainObject()
		 * @generated
		 */
		EClass DOMAIN_OBJECT = eINSTANCE.getDomainObject();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN_OBJECT__NAME = eINSTANCE.getDomainObject_Name();

		/**
		 * The meta object literal for the '<em><b>Core process</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__CORE_PROCESS = eINSTANCE.getDomainObject_Core_process();

		/**
		 * The meta object literal for the '<em><b>Fragment</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__FRAGMENT = eINSTANCE.getDomainObject_Fragment();

		/**
		 * The meta object literal for the '<em><b>Internaldomainknowledge</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE = eINSTANCE.getDomainObject_Internaldomainknowledge();

		/**
		 * The meta object literal for the '<em><b>Externaldomainknowledge</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE = eINSTANCE.getDomainObject_Externaldomainknowledge();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.ProcessImpl <em>Process</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.ProcessImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getProcess()
		 * @generated
		 */
		EClass PROCESS = eINSTANCE.getProcess();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS__NAME = eINSTANCE.getProcess_Name();

		/**
		 * The meta object literal for the '<em><b>Activities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__ACTIVITIES = eINSTANCE.getProcess_Activities();

		/**
		 * The meta object literal for the '<em><b>States</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__STATES = eINSTANCE.getProcess_States();

		/**
		 * The meta object literal for the '<em><b>Transitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__TRANSITIONS = eINSTANCE.getProcess_Transitions();

		/**
		 * The meta object literal for the '<em><b>Annotations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__ANNOTATIONS = eINSTANCE.getProcess_Annotations();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.ActivityImpl <em>Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.ActivityImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getActivity()
		 * @generated
		 */
		EClass ACTIVITY = eINSTANCE.getActivity();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTIVITY__NAME = eINSTANCE.getActivity_Name();

		/**
		 * The meta object literal for the '<em><b>Precondition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTIVITY__PRECONDITION = eINSTANCE.getActivity_Precondition();

		/**
		 * The meta object literal for the '<em><b>Effect</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTIVITY__EFFECT = eINSTANCE.getActivity_Effect();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.InputActivityImpl <em>Input Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.InputActivityImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getInputActivity()
		 * @generated
		 */
		EClass INPUT_ACTIVITY = eINSTANCE.getInputActivity();

		/**
		 * The meta object literal for the '<em><b>Incomingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_ACTIVITY__INCOMINGTRANSITION = eINSTANCE.getInputActivity_Incomingtransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.OutputActivityImpl <em>Output Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.OutputActivityImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getOutputActivity()
		 * @generated
		 */
		EClass OUTPUT_ACTIVITY = eINSTANCE.getOutputActivity();

		/**
		 * The meta object literal for the '<em><b>Outgoingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTPUT_ACTIVITY__OUTGOINGTRANSITION = eINSTANCE.getOutputActivity_Outgoingtransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.AbstractActivityImpl <em>Abstract Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.AbstractActivityImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getAbstractActivity()
		 * @generated
		 */
		EClass ABSTRACT_ACTIVITY = eINSTANCE.getAbstractActivity();

		/**
		 * The meta object literal for the '<em><b>Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_ACTIVITY__GOAL = eINSTANCE.getAbstractActivity_Goal();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.ConcreteActivityImpl <em>Concrete Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.ConcreteActivityImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getConcreteActivity()
		 * @generated
		 */
		EClass CONCRETE_ACTIVITY = eINSTANCE.getConcreteActivity();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.StateImpl <em>State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.StateImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getState()
		 * @generated
		 */
		EClass STATE = eINSTANCE.getState();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__NAME = eINSTANCE.getState_Name();

		/**
		 * The meta object literal for the '<em><b>Is Initial</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__IS_INITIAL = eINSTANCE.getState_IsInitial();

		/**
		 * The meta object literal for the '<em><b>Incomingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__INCOMINGTRANSITION = eINSTANCE.getState_Incomingtransition();

		/**
		 * The meta object literal for the '<em><b>Outgoingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__OUTGOINGTRANSITION = eINSTANCE.getState_Outgoingtransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.TransitionImpl <em>Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.TransitionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getTransition()
		 * @generated
		 */
		EClass TRANSITION = eINSTANCE.getTransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.OutgoingTransitionImpl <em>Outgoing Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.OutgoingTransitionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getOutgoingTransition()
		 * @generated
		 */
		EClass OUTGOING_TRANSITION = eINSTANCE.getOutgoingTransition();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_TRANSITION__STATE = eINSTANCE.getOutgoingTransition_State();

		/**
		 * The meta object literal for the '<em><b>Outputactivity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_TRANSITION__OUTPUTACTIVITY = eINSTANCE.getOutgoingTransition_Outputactivity();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.IncomingTransitionImpl <em>Incoming Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.IncomingTransitionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getIncomingTransition()
		 * @generated
		 */
		EClass INCOMING_TRANSITION = eINSTANCE.getIncomingTransition();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_TRANSITION__STATE = eINSTANCE.getIncomingTransition_State();

		/**
		 * The meta object literal for the '<em><b>Inputactivity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_TRANSITION__INPUTACTIVITY = eINSTANCE.getIncomingTransition_Inputactivity();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.AnnotationImpl <em>Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.AnnotationImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getAnnotation()
		 * @generated
		 */
		EClass ANNOTATION = eINSTANCE.getAnnotation();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.PreconditionImpl <em>Precondition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.PreconditionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getPrecondition()
		 * @generated
		 */
		EClass PRECONDITION = eINSTANCE.getPrecondition();

		/**
		 * The meta object literal for the '<em><b>Activity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRECONDITION__ACTIVITY = eINSTANCE.getPrecondition_Activity();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRECONDITION__LSTATE = eINSTANCE.getPrecondition_Lstate();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.EffectImpl <em>Effect</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.EffectImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getEffect()
		 * @generated
		 */
		EClass EFFECT = eINSTANCE.getEffect();

		/**
		 * The meta object literal for the '<em><b>Activity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EFFECT__ACTIVITY = eINSTANCE.getEffect_Activity();

		/**
		 * The meta object literal for the '<em><b>Levent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EFFECT__LEVENT = eINSTANCE.getEffect_Levent();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.GoalImpl <em>Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.GoalImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getGoal()
		 * @generated
		 */
		EClass GOAL = eINSTANCE.getGoal();

		/**
		 * The meta object literal for the '<em><b>Abstractactivity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__ABSTRACTACTIVITY = eINSTANCE.getGoal_Abstractactivity();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__LSTATE = eINSTANCE.getGoal_Lstate();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.DomainPropertyImpl <em>Domain Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.DomainPropertyImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getDomainProperty()
		 * @generated
		 */
		EClass DOMAIN_PROPERTY = eINSTANCE.getDomainProperty();

		/**
		 * The meta object literal for the '<em><b>Lstates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LSTATES = eINSTANCE.getDomainProperty_Lstates();

		/**
		 * The meta object literal for the '<em><b>Linitialstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LINITIALSTATE = eINSTANCE.getDomainProperty_Linitialstate();

		/**
		 * The meta object literal for the '<em><b>Levents</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LEVENTS = eINSTANCE.getDomainProperty_Levents();

		/**
		 * The meta object literal for the '<em><b>Ltransitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LTRANSITIONS = eINSTANCE.getDomainProperty_Ltransitions();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN_PROPERTY__NAME = eINSTANCE.getDomainProperty_Name();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.LStateImpl <em>LState</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.LStateImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLState()
		 * @generated
		 */
		EClass LSTATE = eINSTANCE.getLState();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LSTATE__NAME = eINSTANCE.getLState_Name();

		/**
		 * The meta object literal for the '<em><b>Incomingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LSTATE__INCOMINGLTRANSITION = eINSTANCE.getLState_Incomingltransition();

		/**
		 * The meta object literal for the '<em><b>Outgoingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LSTATE__OUTGOINGLTRANSITION = eINSTANCE.getLState_Outgoingltransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.LInitialStateImpl <em>LInitial State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.LInitialStateImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLInitialState()
		 * @generated
		 */
		EClass LINITIAL_STATE = eINSTANCE.getLInitialState();

		/**
		 * The meta object literal for the '<em><b>Outgoingltransition IS</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LINITIAL_STATE__OUTGOINGLTRANSITION_IS = eINSTANCE.getLInitialState_OutgoingltransitionIS();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.LEventImpl <em>LEvent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.LEventImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLEvent()
		 * @generated
		 */
		EClass LEVENT = eINSTANCE.getLEvent();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LEVENT__NAME = eINSTANCE.getLEvent_Name();

		/**
		 * The meta object literal for the '<em><b>Outgoingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LEVENT__OUTGOINGLTRANSITION = eINSTANCE.getLEvent_Outgoingltransition();

		/**
		 * The meta object literal for the '<em><b>Incomingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LEVENT__INCOMINGLTRANSITION = eINSTANCE.getLEvent_Incomingltransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.LTransitionImpl <em>LTransition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.LTransitionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getLTransition()
		 * @generated
		 */
		EClass LTRANSITION = eINSTANCE.getLTransition();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.IncomingLTransitionImpl <em>Incoming LTransition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.IncomingLTransitionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getIncomingLTransition()
		 * @generated
		 */
		EClass INCOMING_LTRANSITION = eINSTANCE.getIncomingLTransition();

		/**
		 * The meta object literal for the '<em><b>Levent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_LTRANSITION__LEVENT = eINSTANCE.getIncomingLTransition_Levent();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_LTRANSITION__LSTATE = eINSTANCE.getIncomingLTransition_Lstate();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.OutgoingLTransitionImpl <em>Outgoing LTransition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.OutgoingLTransitionImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getOutgoingLTransition()
		 * @generated
		 */
		EClass OUTGOING_LTRANSITION = eINSTANCE.getOutgoingLTransition();

		/**
		 * The meta object literal for the '<em><b>Linitialstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_LTRANSITION__LINITIALSTATE = eINSTANCE.getOutgoingLTransition_Linitialstate();

		/**
		 * The meta object literal for the '<em><b>Levent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_LTRANSITION__LEVENT = eINSTANCE.getOutgoingLTransition_Levent();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_LTRANSITION__LSTATE = eINSTANCE.getOutgoingLTransition_Lstate();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.AdaptiveSystemImpl <em>Adaptive System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getAdaptiveSystem()
		 * @generated
		 */
		EClass ADAPTIVE_SYSTEM = eINSTANCE.getAdaptiveSystem();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADAPTIVE_SYSTEM__NAME = eINSTANCE.getAdaptiveSystem_Name();

		/**
		 * The meta object literal for the '<em><b>Domainobjects</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADAPTIVE_SYSTEM__DOMAINOBJECTS = eINSTANCE.getAdaptiveSystem_Domainobjects();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.CoreProcessImpl <em>Core Process</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.CoreProcessImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getCoreProcess()
		 * @generated
		 */
		EClass CORE_PROCESS = eINSTANCE.getCoreProcess();

		/**
		 * The meta object literal for the '{@link AdaptiveSystemMM.impl.FragmentImpl <em>Fragment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see AdaptiveSystemMM.impl.FragmentImpl
		 * @see AdaptiveSystemMM.impl.AdaptiveSystemMMPackageImpl#getFragment()
		 * @generated
		 */
		EClass FRAGMENT = eINSTANCE.getFragment();

	}

} //AdaptiveSystemMMPackage
