/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Outgoing LTransition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}</li>
 *   <li>{@link AdaptiveSystemMM.OutgoingLTransition#getLevent <em>Levent</em>}</li>
 *   <li>{@link AdaptiveSystemMM.OutgoingLTransition#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingLTransition()
 * @model
 * @generated
 */
public interface OutgoingLTransition extends LTransition {
	/**
	 * Returns the value of the '<em><b>Linitialstate</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.LInitialState#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Linitialstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Linitialstate</em>' reference.
	 * @see #setLinitialstate(LInitialState)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingLTransition_Linitialstate()
	 * @see AdaptiveSystemMM.LInitialState#getOutgoingltransitionIS
	 * @model opposite="outgoingltransitionIS"
	 * @generated
	 */
	LInitialState getLinitialstate();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Linitialstate</em>' reference.
	 * @see #getLinitialstate()
	 * @generated
	 */
	void setLinitialstate(LInitialState value);

	/**
	 * Returns the value of the '<em><b>Levent</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.LEvent#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Levent</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Levent</em>' reference.
	 * @see #setLevent(LEvent)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingLTransition_Levent()
	 * @see AdaptiveSystemMM.LEvent#getOutgoingltransition
	 * @model opposite="outgoingltransition"
	 * @generated
	 */
	LEvent getLevent();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.OutgoingLTransition#getLevent <em>Levent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Levent</em>' reference.
	 * @see #getLevent()
	 * @generated
	 */
	void setLevent(LEvent value);

	/**
	 * Returns the value of the '<em><b>Lstate</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.LState#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstate</em>' reference.
	 * @see #setLstate(LState)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getOutgoingLTransition_Lstate()
	 * @see AdaptiveSystemMM.LState#getOutgoingltransition
	 * @model opposite="outgoingltransition"
	 * @generated
	 */
	LState getLstate();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.OutgoingLTransition#getLstate <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lstate</em>' reference.
	 * @see #getLstate()
	 * @generated
	 */
	void setLstate(LState value);

} // OutgoingLTransition
