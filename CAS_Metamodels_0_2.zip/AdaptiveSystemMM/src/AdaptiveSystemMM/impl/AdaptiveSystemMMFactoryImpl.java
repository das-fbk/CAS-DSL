/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AbstractActivity;
import AdaptiveSystemMM.AdaptiveSystem;
import AdaptiveSystemMM.AdaptiveSystemMMFactory;
import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.ConcreteActivity;
import AdaptiveSystemMM.CoreProcess;
import AdaptiveSystemMM.DomainObject;
import AdaptiveSystemMM.DomainProperty;
import AdaptiveSystemMM.Effect;
import AdaptiveSystemMM.Fragment;
import AdaptiveSystemMM.Goal;
import AdaptiveSystemMM.IncomingLTransition;
import AdaptiveSystemMM.IncomingTransition;
import AdaptiveSystemMM.InputActivity;
import AdaptiveSystemMM.LEvent;
import AdaptiveSystemMM.LInitialState;
import AdaptiveSystemMM.LState;
import AdaptiveSystemMM.OutgoingLTransition;
import AdaptiveSystemMM.OutgoingTransition;
import AdaptiveSystemMM.OutputActivity;
import AdaptiveSystemMM.Precondition;
import AdaptiveSystemMM.State;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class AdaptiveSystemMMFactoryImpl extends EFactoryImpl implements AdaptiveSystemMMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AdaptiveSystemMMFactory init() {
		try {
			AdaptiveSystemMMFactory theAdaptiveSystemMMFactory = (AdaptiveSystemMMFactory)EPackage.Registry.INSTANCE.getEFactory(AdaptiveSystemMMPackage.eNS_URI);
			if (theAdaptiveSystemMMFactory != null) {
				return theAdaptiveSystemMMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new AdaptiveSystemMMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptiveSystemMMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT: return createDomainObject();
			case AdaptiveSystemMMPackage.INPUT_ACTIVITY: return createInputActivity();
			case AdaptiveSystemMMPackage.OUTPUT_ACTIVITY: return createOutputActivity();
			case AdaptiveSystemMMPackage.ABSTRACT_ACTIVITY: return createAbstractActivity();
			case AdaptiveSystemMMPackage.CONCRETE_ACTIVITY: return createConcreteActivity();
			case AdaptiveSystemMMPackage.STATE: return createState();
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION: return createOutgoingTransition();
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION: return createIncomingTransition();
			case AdaptiveSystemMMPackage.PRECONDITION: return createPrecondition();
			case AdaptiveSystemMMPackage.EFFECT: return createEffect();
			case AdaptiveSystemMMPackage.GOAL: return createGoal();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY: return createDomainProperty();
			case AdaptiveSystemMMPackage.LSTATE: return createLState();
			case AdaptiveSystemMMPackage.LINITIAL_STATE: return createLInitialState();
			case AdaptiveSystemMMPackage.LEVENT: return createLEvent();
			case AdaptiveSystemMMPackage.INCOMING_LTRANSITION: return createIncomingLTransition();
			case AdaptiveSystemMMPackage.OUTGOING_LTRANSITION: return createOutgoingLTransition();
			case AdaptiveSystemMMPackage.ADAPTIVE_SYSTEM: return createAdaptiveSystem();
			case AdaptiveSystemMMPackage.CORE_PROCESS: return createCoreProcess();
			case AdaptiveSystemMMPackage.FRAGMENT: return createFragment();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainObject createDomainObject() {
		DomainObjectImpl domainObject = new DomainObjectImpl();
		return domainObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputActivity createInputActivity() {
		InputActivityImpl inputActivity = new InputActivityImpl();
		return inputActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputActivity createOutputActivity() {
		OutputActivityImpl outputActivity = new OutputActivityImpl();
		return outputActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractActivity createAbstractActivity() {
		AbstractActivityImpl abstractActivity = new AbstractActivityImpl();
		return abstractActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConcreteActivity createConcreteActivity() {
		ConcreteActivityImpl concreteActivity = new ConcreteActivityImpl();
		return concreteActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingTransition createOutgoingTransition() {
		OutgoingTransitionImpl outgoingTransition = new OutgoingTransitionImpl();
		return outgoingTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingTransition createIncomingTransition() {
		IncomingTransitionImpl incomingTransition = new IncomingTransitionImpl();
		return incomingTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Precondition createPrecondition() {
		PreconditionImpl precondition = new PreconditionImpl();
		return precondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effect createEffect() {
		EffectImpl effect = new EffectImpl();
		return effect;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Goal createGoal() {
		GoalImpl goal = new GoalImpl();
		return goal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainProperty createDomainProperty() {
		DomainPropertyImpl domainProperty = new DomainPropertyImpl();
		return domainProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LState createLState() {
		LStateImpl lState = new LStateImpl();
		return lState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LInitialState createLInitialState() {
		LInitialStateImpl lInitialState = new LInitialStateImpl();
		return lInitialState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LEvent createLEvent() {
		LEventImpl lEvent = new LEventImpl();
		return lEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingLTransition createIncomingLTransition() {
		IncomingLTransitionImpl incomingLTransition = new IncomingLTransitionImpl();
		return incomingLTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition createOutgoingLTransition() {
		OutgoingLTransitionImpl outgoingLTransition = new OutgoingLTransitionImpl();
		return outgoingLTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptiveSystem createAdaptiveSystem() {
		AdaptiveSystemImpl adaptiveSystem = new AdaptiveSystemImpl();
		return adaptiveSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoreProcess createCoreProcess() {
		CoreProcessImpl coreProcess = new CoreProcessImpl();
		return coreProcess;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fragment createFragment() {
		FragmentImpl fragment = new FragmentImpl();
		return fragment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptiveSystemMMPackage getAdaptiveSystemMMPackage() {
		return (AdaptiveSystemMMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static AdaptiveSystemMMPackage getPackage() {
		return AdaptiveSystemMMPackage.eINSTANCE;
	}

} //AdaptiveSystemMMFactoryImpl
