/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.CoreProcess;
import AdaptiveSystemMM.DomainObject;
import AdaptiveSystemMM.DomainProperty;

import AdaptiveSystemMM.Fragment;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Domain Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.DomainObjectImpl#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainObjectImpl#getCore_process <em>Core process</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainObjectImpl#getFragment <em>Fragment</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainObjectImpl#getInternaldomainknowledge <em>Internaldomainknowledge</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainObjectImpl#getExternaldomainknowledge <em>Externaldomainknowledge</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DomainObjectImpl extends MinimalEObjectImpl.Container implements DomainObject {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCore_process() <em>Core process</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCore_process()
	 * @generated
	 * @ordered
	 */
	protected CoreProcess core_process;

	/**
	 * The cached value of the '{@link #getFragment() <em>Fragment</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFragment()
	 * @generated
	 * @ordered
	 */
	protected EList<Fragment> fragment;

	/**
	 * The cached value of the '{@link #getInternaldomainknowledge() <em>Internaldomainknowledge</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInternaldomainknowledge()
	 * @generated
	 * @ordered
	 */
	protected EList<DomainProperty> internaldomainknowledge;

	/**
	 * The cached value of the '{@link #getExternaldomainknowledge() <em>Externaldomainknowledge</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExternaldomainknowledge()
	 * @generated
	 * @ordered
	 */
	protected EList<DomainProperty> externaldomainknowledge;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DomainObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.DOMAIN_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.DOMAIN_OBJECT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CoreProcess getCore_process() {
		return core_process;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCore_process(CoreProcess newCore_process, NotificationChain msgs) {
		CoreProcess oldCore_process = core_process;
		core_process = newCore_process;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS, oldCore_process, newCore_process);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCore_process(CoreProcess newCore_process) {
		if (newCore_process != core_process) {
			NotificationChain msgs = null;
			if (core_process != null)
				msgs = ((InternalEObject)core_process).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS, null, msgs);
			if (newCore_process != null)
				msgs = ((InternalEObject)newCore_process).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS, null, msgs);
			msgs = basicSetCore_process(newCore_process, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS, newCore_process, newCore_process));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fragment> getFragment() {
		if (fragment == null) {
			fragment = new EObjectContainmentEList<Fragment>(Fragment.class, this, AdaptiveSystemMMPackage.DOMAIN_OBJECT__FRAGMENT);
		}
		return fragment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DomainProperty> getInternaldomainknowledge() {
		if (internaldomainknowledge == null) {
			internaldomainknowledge = new EObjectContainmentEList<DomainProperty>(DomainProperty.class, this, AdaptiveSystemMMPackage.DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE);
		}
		return internaldomainknowledge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DomainProperty> getExternaldomainknowledge() {
		if (externaldomainknowledge == null) {
			externaldomainknowledge = new EObjectResolvingEList<DomainProperty>(DomainProperty.class, this, AdaptiveSystemMMPackage.DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE);
		}
		return externaldomainknowledge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS:
				return basicSetCore_process(null, msgs);
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__FRAGMENT:
				return ((InternalEList<?>)getFragment()).basicRemove(otherEnd, msgs);
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE:
				return ((InternalEList<?>)getInternaldomainknowledge()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__NAME:
				return getName();
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS:
				return getCore_process();
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__FRAGMENT:
				return getFragment();
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE:
				return getInternaldomainknowledge();
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE:
				return getExternaldomainknowledge();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__NAME:
				setName((String)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS:
				setCore_process((CoreProcess)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__FRAGMENT:
				getFragment().clear();
				getFragment().addAll((Collection<? extends Fragment>)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE:
				getInternaldomainknowledge().clear();
				getInternaldomainknowledge().addAll((Collection<? extends DomainProperty>)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE:
				getExternaldomainknowledge().clear();
				getExternaldomainknowledge().addAll((Collection<? extends DomainProperty>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS:
				setCore_process((CoreProcess)null);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__FRAGMENT:
				getFragment().clear();
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE:
				getInternaldomainknowledge().clear();
				return;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE:
				getExternaldomainknowledge().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__CORE_PROCESS:
				return core_process != null;
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__FRAGMENT:
				return fragment != null && !fragment.isEmpty();
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE:
				return internaldomainknowledge != null && !internaldomainknowledge.isEmpty();
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE:
				return externaldomainknowledge != null && !externaldomainknowledge.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DomainObjectImpl
