/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.IncomingTransition;
import AdaptiveSystemMM.InputActivity;
import AdaptiveSystemMM.State;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Incoming Transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.IncomingTransitionImpl#getState <em>State</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.IncomingTransitionImpl#getInputactivity <em>Inputactivity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IncomingTransitionImpl extends TransitionImpl implements IncomingTransition {
	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected State state;

	/**
	 * The cached value of the '{@link #getInputactivity() <em>Inputactivity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputactivity()
	 * @generated
	 * @ordered
	 */
	protected InputActivity inputactivity;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IncomingTransitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.INCOMING_TRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State getState() {
		if (state != null && state.eIsProxy()) {
			InternalEObject oldState = (InternalEObject)state;
			state = (State)eResolveProxy(oldState);
			if (state != oldState) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE, oldState, state));
			}
		}
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State basicGetState() {
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetState(State newState, NotificationChain msgs) {
		State oldState = state;
		state = newState;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE, oldState, newState);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState(State newState) {
		if (newState != state) {
			NotificationChain msgs = null;
			if (state != null)
				msgs = ((InternalEObject)state).eInverseRemove(this, AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION, State.class, msgs);
			if (newState != null)
				msgs = ((InternalEObject)newState).eInverseAdd(this, AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION, State.class, msgs);
			msgs = basicSetState(newState, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE, newState, newState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputActivity getInputactivity() {
		if (inputactivity != null && inputactivity.eIsProxy()) {
			InternalEObject oldInputactivity = (InternalEObject)inputactivity;
			inputactivity = (InputActivity)eResolveProxy(oldInputactivity);
			if (inputactivity != oldInputactivity) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY, oldInputactivity, inputactivity));
			}
		}
		return inputactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputActivity basicGetInputactivity() {
		return inputactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetInputactivity(InputActivity newInputactivity, NotificationChain msgs) {
		InputActivity oldInputactivity = inputactivity;
		inputactivity = newInputactivity;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY, oldInputactivity, newInputactivity);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInputactivity(InputActivity newInputactivity) {
		if (newInputactivity != inputactivity) {
			NotificationChain msgs = null;
			if (inputactivity != null)
				msgs = ((InternalEObject)inputactivity).eInverseRemove(this, AdaptiveSystemMMPackage.INPUT_ACTIVITY__INCOMINGTRANSITION, InputActivity.class, msgs);
			if (newInputactivity != null)
				msgs = ((InternalEObject)newInputactivity).eInverseAdd(this, AdaptiveSystemMMPackage.INPUT_ACTIVITY__INCOMINGTRANSITION, InputActivity.class, msgs);
			msgs = basicSetInputactivity(newInputactivity, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY, newInputactivity, newInputactivity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE:
				if (state != null)
					msgs = ((InternalEObject)state).eInverseRemove(this, AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION, State.class, msgs);
				return basicSetState((State)otherEnd, msgs);
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY:
				if (inputactivity != null)
					msgs = ((InternalEObject)inputactivity).eInverseRemove(this, AdaptiveSystemMMPackage.INPUT_ACTIVITY__INCOMINGTRANSITION, InputActivity.class, msgs);
				return basicSetInputactivity((InputActivity)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE:
				return basicSetState(null, msgs);
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY:
				return basicSetInputactivity(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE:
				if (resolve) return getState();
				return basicGetState();
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY:
				if (resolve) return getInputactivity();
				return basicGetInputactivity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE:
				setState((State)newValue);
				return;
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY:
				setInputactivity((InputActivity)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE:
				setState((State)null);
				return;
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY:
				setInputactivity((InputActivity)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE:
				return state != null;
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION__INPUTACTIVITY:
				return inputactivity != null;
		}
		return super.eIsSet(featureID);
	}

} //IncomingTransitionImpl
