/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.DomainProperty;
import AdaptiveSystemMM.LEvent;
import AdaptiveSystemMM.LInitialState;
import AdaptiveSystemMM.LState;
import AdaptiveSystemMM.LTransition;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Domain Property</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.DomainPropertyImpl#getLstates <em>Lstates</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainPropertyImpl#getLinitialstate <em>Linitialstate</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainPropertyImpl#getLevents <em>Levents</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainPropertyImpl#getLtransitions <em>Ltransitions</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.DomainPropertyImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DomainPropertyImpl extends MinimalEObjectImpl.Container implements DomainProperty {
	/**
	 * The cached value of the '{@link #getLstates() <em>Lstates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLstates()
	 * @generated
	 * @ordered
	 */
	protected EList<LState> lstates;

	/**
	 * The cached value of the '{@link #getLinitialstate() <em>Linitialstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinitialstate()
	 * @generated
	 * @ordered
	 */
	protected LInitialState linitialstate;

	/**
	 * The cached value of the '{@link #getLevents() <em>Levents</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLevents()
	 * @generated
	 * @ordered
	 */
	protected EList<LEvent> levents;

	/**
	 * The cached value of the '{@link #getLtransitions() <em>Ltransitions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLtransitions()
	 * @generated
	 * @ordered
	 */
	protected EList<LTransition> ltransitions;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DomainPropertyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.DOMAIN_PROPERTY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LState> getLstates() {
		if (lstates == null) {
			lstates = new EObjectContainmentEList<LState>(LState.class, this, AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LSTATES);
		}
		return lstates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LInitialState getLinitialstate() {
		if (linitialstate != null && linitialstate.eIsProxy()) {
			InternalEObject oldLinitialstate = (InternalEObject)linitialstate;
			linitialstate = (LInitialState)eResolveProxy(oldLinitialstate);
			if (linitialstate != oldLinitialstate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LINITIALSTATE, oldLinitialstate, linitialstate));
			}
		}
		return linitialstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LInitialState basicGetLinitialstate() {
		return linitialstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLinitialstate(LInitialState newLinitialstate) {
		LInitialState oldLinitialstate = linitialstate;
		linitialstate = newLinitialstate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LINITIALSTATE, oldLinitialstate, linitialstate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LEvent> getLevents() {
		if (levents == null) {
			levents = new EObjectContainmentEList<LEvent>(LEvent.class, this, AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LEVENTS);
		}
		return levents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LTransition> getLtransitions() {
		if (ltransitions == null) {
			ltransitions = new EObjectContainmentEList<LTransition>(LTransition.class, this, AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LTRANSITIONS);
		}
		return ltransitions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.DOMAIN_PROPERTY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LSTATES:
				return ((InternalEList<?>)getLstates()).basicRemove(otherEnd, msgs);
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LEVENTS:
				return ((InternalEList<?>)getLevents()).basicRemove(otherEnd, msgs);
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LTRANSITIONS:
				return ((InternalEList<?>)getLtransitions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LSTATES:
				return getLstates();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LINITIALSTATE:
				if (resolve) return getLinitialstate();
				return basicGetLinitialstate();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LEVENTS:
				return getLevents();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LTRANSITIONS:
				return getLtransitions();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LSTATES:
				getLstates().clear();
				getLstates().addAll((Collection<? extends LState>)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LINITIALSTATE:
				setLinitialstate((LInitialState)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LEVENTS:
				getLevents().clear();
				getLevents().addAll((Collection<? extends LEvent>)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LTRANSITIONS:
				getLtransitions().clear();
				getLtransitions().addAll((Collection<? extends LTransition>)newValue);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LSTATES:
				getLstates().clear();
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LINITIALSTATE:
				setLinitialstate((LInitialState)null);
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LEVENTS:
				getLevents().clear();
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LTRANSITIONS:
				getLtransitions().clear();
				return;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LSTATES:
				return lstates != null && !lstates.isEmpty();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LINITIALSTATE:
				return linitialstate != null;
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LEVENTS:
				return levents != null && !levents.isEmpty();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__LTRANSITIONS:
				return ltransitions != null && !ltransitions.isEmpty();
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DomainPropertyImpl
