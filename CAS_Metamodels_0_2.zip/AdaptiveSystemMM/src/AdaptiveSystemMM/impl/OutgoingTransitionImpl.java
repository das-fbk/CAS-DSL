/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.OutgoingTransition;
import AdaptiveSystemMM.OutputActivity;
import AdaptiveSystemMM.State;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Outgoing Transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.OutgoingTransitionImpl#getState <em>State</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.OutgoingTransitionImpl#getOutputactivity <em>Outputactivity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutgoingTransitionImpl extends TransitionImpl implements OutgoingTransition {
	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected State state;

	/**
	 * The cached value of the '{@link #getOutputactivity() <em>Outputactivity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputactivity()
	 * @generated
	 * @ordered
	 */
	protected OutputActivity outputactivity;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutgoingTransitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.OUTGOING_TRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State getState() {
		if (state != null && state.eIsProxy()) {
			InternalEObject oldState = (InternalEObject)state;
			state = (State)eResolveProxy(oldState);
			if (state != oldState) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE, oldState, state));
			}
		}
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State basicGetState() {
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetState(State newState, NotificationChain msgs) {
		State oldState = state;
		state = newState;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE, oldState, newState);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState(State newState) {
		if (newState != state) {
			NotificationChain msgs = null;
			if (state != null)
				msgs = ((InternalEObject)state).eInverseRemove(this, AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION, State.class, msgs);
			if (newState != null)
				msgs = ((InternalEObject)newState).eInverseAdd(this, AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION, State.class, msgs);
			msgs = basicSetState(newState, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE, newState, newState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputActivity getOutputactivity() {
		if (outputactivity != null && outputactivity.eIsProxy()) {
			InternalEObject oldOutputactivity = (InternalEObject)outputactivity;
			outputactivity = (OutputActivity)eResolveProxy(oldOutputactivity);
			if (outputactivity != oldOutputactivity) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY, oldOutputactivity, outputactivity));
			}
		}
		return outputactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputActivity basicGetOutputactivity() {
		return outputactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutputactivity(OutputActivity newOutputactivity, NotificationChain msgs) {
		OutputActivity oldOutputactivity = outputactivity;
		outputactivity = newOutputactivity;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY, oldOutputactivity, newOutputactivity);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutputactivity(OutputActivity newOutputactivity) {
		if (newOutputactivity != outputactivity) {
			NotificationChain msgs = null;
			if (outputactivity != null)
				msgs = ((InternalEObject)outputactivity).eInverseRemove(this, AdaptiveSystemMMPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION, OutputActivity.class, msgs);
			if (newOutputactivity != null)
				msgs = ((InternalEObject)newOutputactivity).eInverseAdd(this, AdaptiveSystemMMPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION, OutputActivity.class, msgs);
			msgs = basicSetOutputactivity(newOutputactivity, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY, newOutputactivity, newOutputactivity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE:
				if (state != null)
					msgs = ((InternalEObject)state).eInverseRemove(this, AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION, State.class, msgs);
				return basicSetState((State)otherEnd, msgs);
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY:
				if (outputactivity != null)
					msgs = ((InternalEObject)outputactivity).eInverseRemove(this, AdaptiveSystemMMPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION, OutputActivity.class, msgs);
				return basicSetOutputactivity((OutputActivity)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE:
				return basicSetState(null, msgs);
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY:
				return basicSetOutputactivity(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE:
				if (resolve) return getState();
				return basicGetState();
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY:
				if (resolve) return getOutputactivity();
				return basicGetOutputactivity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE:
				setState((State)newValue);
				return;
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY:
				setOutputactivity((OutputActivity)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE:
				setState((State)null);
				return;
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY:
				setOutputactivity((OutputActivity)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE:
				return state != null;
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY:
				return outputactivity != null;
		}
		return super.eIsSet(featureID);
	}

} //OutgoingTransitionImpl
