/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.Fragment;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FragmentImpl extends ProcessImpl implements Fragment {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FragmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.FRAGMENT;
	}

} //FragmentImpl
