/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.IncomingTransition;
import AdaptiveSystemMM.OutgoingTransition;
import AdaptiveSystemMM.State;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.StateImpl#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.StateImpl#isIsInitial <em>Is Initial</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.StateImpl#getIncomingtransition <em>Incomingtransition</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.StateImpl#getOutgoingtransition <em>Outgoingtransition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StateImpl extends MinimalEObjectImpl.Container implements State {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsInitial() <em>Is Initial</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsInitial()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_INITIAL_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsInitial() <em>Is Initial</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsInitial()
	 * @generated
	 * @ordered
	 */
	protected boolean isInitial = IS_INITIAL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIncomingtransition() <em>Incomingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncomingtransition()
	 * @generated
	 * @ordered
	 */
	protected IncomingTransition incomingtransition;

	/**
	 * The cached value of the '{@link #getOutgoingtransition() <em>Outgoingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoingtransition()
	 * @generated
	 * @ordered
	 */
	protected OutgoingTransition outgoingtransition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.STATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.STATE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsInitial() {
		return isInitial;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsInitial(boolean newIsInitial) {
		boolean oldIsInitial = isInitial;
		isInitial = newIsInitial;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.STATE__IS_INITIAL, oldIsInitial, isInitial));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingTransition getIncomingtransition() {
		if (incomingtransition != null && incomingtransition.eIsProxy()) {
			InternalEObject oldIncomingtransition = (InternalEObject)incomingtransition;
			incomingtransition = (IncomingTransition)eResolveProxy(oldIncomingtransition);
			if (incomingtransition != oldIncomingtransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION, oldIncomingtransition, incomingtransition));
			}
		}
		return incomingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingTransition basicGetIncomingtransition() {
		return incomingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIncomingtransition(IncomingTransition newIncomingtransition, NotificationChain msgs) {
		IncomingTransition oldIncomingtransition = incomingtransition;
		incomingtransition = newIncomingtransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION, oldIncomingtransition, newIncomingtransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncomingtransition(IncomingTransition newIncomingtransition) {
		if (newIncomingtransition != incomingtransition) {
			NotificationChain msgs = null;
			if (incomingtransition != null)
				msgs = ((InternalEObject)incomingtransition).eInverseRemove(this, AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE, IncomingTransition.class, msgs);
			if (newIncomingtransition != null)
				msgs = ((InternalEObject)newIncomingtransition).eInverseAdd(this, AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE, IncomingTransition.class, msgs);
			msgs = basicSetIncomingtransition(newIncomingtransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION, newIncomingtransition, newIncomingtransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingTransition getOutgoingtransition() {
		if (outgoingtransition != null && outgoingtransition.eIsProxy()) {
			InternalEObject oldOutgoingtransition = (InternalEObject)outgoingtransition;
			outgoingtransition = (OutgoingTransition)eResolveProxy(oldOutgoingtransition);
			if (outgoingtransition != oldOutgoingtransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION, oldOutgoingtransition, outgoingtransition));
			}
		}
		return outgoingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingTransition basicGetOutgoingtransition() {
		return outgoingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoingtransition(OutgoingTransition newOutgoingtransition, NotificationChain msgs) {
		OutgoingTransition oldOutgoingtransition = outgoingtransition;
		outgoingtransition = newOutgoingtransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION, oldOutgoingtransition, newOutgoingtransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoingtransition(OutgoingTransition newOutgoingtransition) {
		if (newOutgoingtransition != outgoingtransition) {
			NotificationChain msgs = null;
			if (outgoingtransition != null)
				msgs = ((InternalEObject)outgoingtransition).eInverseRemove(this, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE, OutgoingTransition.class, msgs);
			if (newOutgoingtransition != null)
				msgs = ((InternalEObject)newOutgoingtransition).eInverseAdd(this, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE, OutgoingTransition.class, msgs);
			msgs = basicSetOutgoingtransition(newOutgoingtransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION, newOutgoingtransition, newOutgoingtransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION:
				if (incomingtransition != null)
					msgs = ((InternalEObject)incomingtransition).eInverseRemove(this, AdaptiveSystemMMPackage.INCOMING_TRANSITION__STATE, IncomingTransition.class, msgs);
				return basicSetIncomingtransition((IncomingTransition)otherEnd, msgs);
			case AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION:
				if (outgoingtransition != null)
					msgs = ((InternalEObject)outgoingtransition).eInverseRemove(this, AdaptiveSystemMMPackage.OUTGOING_TRANSITION__STATE, OutgoingTransition.class, msgs);
				return basicSetOutgoingtransition((OutgoingTransition)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION:
				return basicSetIncomingtransition(null, msgs);
			case AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION:
				return basicSetOutgoingtransition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.STATE__NAME:
				return getName();
			case AdaptiveSystemMMPackage.STATE__IS_INITIAL:
				return isIsInitial();
			case AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION:
				if (resolve) return getIncomingtransition();
				return basicGetIncomingtransition();
			case AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION:
				if (resolve) return getOutgoingtransition();
				return basicGetOutgoingtransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.STATE__NAME:
				setName((String)newValue);
				return;
			case AdaptiveSystemMMPackage.STATE__IS_INITIAL:
				setIsInitial((Boolean)newValue);
				return;
			case AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION:
				setIncomingtransition((IncomingTransition)newValue);
				return;
			case AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION:
				setOutgoingtransition((OutgoingTransition)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.STATE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case AdaptiveSystemMMPackage.STATE__IS_INITIAL:
				setIsInitial(IS_INITIAL_EDEFAULT);
				return;
			case AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION:
				setIncomingtransition((IncomingTransition)null);
				return;
			case AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION:
				setOutgoingtransition((OutgoingTransition)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.STATE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case AdaptiveSystemMMPackage.STATE__IS_INITIAL:
				return isInitial != IS_INITIAL_EDEFAULT;
			case AdaptiveSystemMMPackage.STATE__INCOMINGTRANSITION:
				return incomingtransition != null;
			case AdaptiveSystemMMPackage.STATE__OUTGOINGTRANSITION:
				return outgoingtransition != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", isInitial: ");
		result.append(isInitial);
		result.append(')');
		return result.toString();
	}

} //StateImpl
