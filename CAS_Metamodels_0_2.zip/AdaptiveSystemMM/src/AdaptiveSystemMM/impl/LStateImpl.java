/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.IncomingLTransition;
import AdaptiveSystemMM.LState;
import AdaptiveSystemMM.OutgoingLTransition;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LState</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.LStateImpl#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.LStateImpl#getIncomingltransition <em>Incomingltransition</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.LStateImpl#getOutgoingltransition <em>Outgoingltransition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LStateImpl extends MinimalEObjectImpl.Container implements LState {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIncomingltransition() <em>Incomingltransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncomingltransition()
	 * @generated
	 * @ordered
	 */
	protected IncomingLTransition incomingltransition;

	/**
	 * The cached value of the '{@link #getOutgoingltransition() <em>Outgoingltransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoingltransition()
	 * @generated
	 * @ordered
	 */
	protected OutgoingLTransition outgoingltransition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LStateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.LSTATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.LSTATE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingLTransition getIncomingltransition() {
		if (incomingltransition != null && incomingltransition.eIsProxy()) {
			InternalEObject oldIncomingltransition = (InternalEObject)incomingltransition;
			incomingltransition = (IncomingLTransition)eResolveProxy(oldIncomingltransition);
			if (incomingltransition != oldIncomingltransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION, oldIncomingltransition, incomingltransition));
			}
		}
		return incomingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingLTransition basicGetIncomingltransition() {
		return incomingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIncomingltransition(IncomingLTransition newIncomingltransition, NotificationChain msgs) {
		IncomingLTransition oldIncomingltransition = incomingltransition;
		incomingltransition = newIncomingltransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION, oldIncomingltransition, newIncomingltransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncomingltransition(IncomingLTransition newIncomingltransition) {
		if (newIncomingltransition != incomingltransition) {
			NotificationChain msgs = null;
			if (incomingltransition != null)
				msgs = ((InternalEObject)incomingltransition).eInverseRemove(this, AdaptiveSystemMMPackage.INCOMING_LTRANSITION__LSTATE, IncomingLTransition.class, msgs);
			if (newIncomingltransition != null)
				msgs = ((InternalEObject)newIncomingltransition).eInverseAdd(this, AdaptiveSystemMMPackage.INCOMING_LTRANSITION__LSTATE, IncomingLTransition.class, msgs);
			msgs = basicSetIncomingltransition(newIncomingltransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION, newIncomingltransition, newIncomingltransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition getOutgoingltransition() {
		if (outgoingltransition != null && outgoingltransition.eIsProxy()) {
			InternalEObject oldOutgoingltransition = (InternalEObject)outgoingltransition;
			outgoingltransition = (OutgoingLTransition)eResolveProxy(oldOutgoingltransition);
			if (outgoingltransition != oldOutgoingltransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION, oldOutgoingltransition, outgoingltransition));
			}
		}
		return outgoingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition basicGetOutgoingltransition() {
		return outgoingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoingltransition(OutgoingLTransition newOutgoingltransition, NotificationChain msgs) {
		OutgoingLTransition oldOutgoingltransition = outgoingltransition;
		outgoingltransition = newOutgoingltransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION, oldOutgoingltransition, newOutgoingltransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoingltransition(OutgoingLTransition newOutgoingltransition) {
		if (newOutgoingltransition != outgoingltransition) {
			NotificationChain msgs = null;
			if (outgoingltransition != null)
				msgs = ((InternalEObject)outgoingltransition).eInverseRemove(this, AdaptiveSystemMMPackage.OUTGOING_LTRANSITION__LSTATE, OutgoingLTransition.class, msgs);
			if (newOutgoingltransition != null)
				msgs = ((InternalEObject)newOutgoingltransition).eInverseAdd(this, AdaptiveSystemMMPackage.OUTGOING_LTRANSITION__LSTATE, OutgoingLTransition.class, msgs);
			msgs = basicSetOutgoingltransition(newOutgoingltransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION, newOutgoingltransition, newOutgoingltransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION:
				if (incomingltransition != null)
					msgs = ((InternalEObject)incomingltransition).eInverseRemove(this, AdaptiveSystemMMPackage.INCOMING_LTRANSITION__LSTATE, IncomingLTransition.class, msgs);
				return basicSetIncomingltransition((IncomingLTransition)otherEnd, msgs);
			case AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION:
				if (outgoingltransition != null)
					msgs = ((InternalEObject)outgoingltransition).eInverseRemove(this, AdaptiveSystemMMPackage.OUTGOING_LTRANSITION__LSTATE, OutgoingLTransition.class, msgs);
				return basicSetOutgoingltransition((OutgoingLTransition)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION:
				return basicSetIncomingltransition(null, msgs);
			case AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION:
				return basicSetOutgoingltransition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.LSTATE__NAME:
				return getName();
			case AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION:
				if (resolve) return getIncomingltransition();
				return basicGetIncomingltransition();
			case AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION:
				if (resolve) return getOutgoingltransition();
				return basicGetOutgoingltransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.LSTATE__NAME:
				setName((String)newValue);
				return;
			case AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION:
				setIncomingltransition((IncomingLTransition)newValue);
				return;
			case AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION:
				setOutgoingltransition((OutgoingLTransition)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.LSTATE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION:
				setIncomingltransition((IncomingLTransition)null);
				return;
			case AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION:
				setOutgoingltransition((OutgoingLTransition)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.LSTATE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case AdaptiveSystemMMPackage.LSTATE__INCOMINGLTRANSITION:
				return incomingltransition != null;
			case AdaptiveSystemMMPackage.LSTATE__OUTGOINGLTRANSITION:
				return outgoingltransition != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //LStateImpl
