/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.AbstractActivity#getGoal <em>Goal</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getAbstractActivity()
 * @model
 * @generated
 */
public interface AbstractActivity extends Activity {
	/**
	 * Returns the value of the '<em><b>Goal</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.Goal#getAbstractactivity <em>Abstractactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal</em>' reference.
	 * @see #setGoal(Goal)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getAbstractActivity_Goal()
	 * @see AdaptiveSystemMM.Goal#getAbstractactivity
	 * @model opposite="abstractactivity"
	 * @generated
	 */
	Goal getGoal();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.AbstractActivity#getGoal <em>Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Goal</em>' reference.
	 * @see #getGoal()
	 * @generated
	 */
	void setGoal(Goal value);

} // AbstractActivity
