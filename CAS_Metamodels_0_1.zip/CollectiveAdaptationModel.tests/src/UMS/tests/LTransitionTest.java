/**
 */
package UMS.tests;

import UMS.LTransition;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>LTransition</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class LTransitionTest extends TestCase {

	/**
	 * The fixture for this LTransition test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LTransition fixture = null;

	/**
	 * Constructs a new LTransition test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LTransitionTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this LTransition test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(LTransition fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this LTransition test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LTransition getFixture() {
		return fixture;
	}

} //LTransitionTest
