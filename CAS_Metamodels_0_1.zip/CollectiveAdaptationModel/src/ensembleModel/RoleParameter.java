/**
 */
package ensembleModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ensembleModel.EnsembleModelPackage#getRoleParameter()
 * @model
 * @generated
 */
public interface RoleParameter extends NamedValue {
} // RoleParameter
