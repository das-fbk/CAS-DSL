/**
 */
package ensembleModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solver</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.Solver#getName <em>Name</em>}</li>
 *   <li>{@link ensembleModel.Solver#isActive <em>Active</em>}</li>
 *   <li>{@link ensembleModel.Solver#getSolverParameters <em>Solver Parameters</em>}</li>
 *   <li>{@link ensembleModel.Solver#getCompatibleIssueTypes <em>Compatible Issue Types</em>}</li>
 * </ul>
 *
 * @see ensembleModel.EnsembleModelPackage#getSolver()
 * @model
 * @generated
 */
public interface Solver extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ensembleModel.EnsembleModelPackage#getSolver_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ensembleModel.Solver#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Active</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Active</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Active</em>' attribute.
	 * @see #setActive(boolean)
	 * @see ensembleModel.EnsembleModelPackage#getSolver_Active()
	 * @model
	 * @generated
	 */
	boolean isActive();

	/**
	 * Sets the value of the '{@link ensembleModel.Solver#isActive <em>Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Active</em>' attribute.
	 * @see #isActive()
	 * @generated
	 */
	void setActive(boolean value);

	/**
	 * Returns the value of the '<em><b>Solver Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link ensembleModel.SolverParameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Solver Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Solver Parameters</em>' containment reference list.
	 * @see ensembleModel.EnsembleModelPackage#getSolver_SolverParameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<SolverParameter> getSolverParameters();

	/**
	 * Returns the value of the '<em><b>Compatible Issue Types</b></em>' reference list.
	 * The list contents are of type {@link ensembleModel.IssueType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Compatible Issue Types</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Compatible Issue Types</em>' reference list.
	 * @see ensembleModel.EnsembleModelPackage#getSolver_CompatibleIssueTypes()
	 * @model
	 * @generated
	 */
	EList<IssueType> getCompatibleIssueTypes();

} // Solver
