/**
 */
package ensembleModel.impl;

import ensembleModel.EnsembleModelPackage;
import ensembleModel.Preference;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Preference</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PreferenceImpl extends NamedValueImpl implements Preference {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreferenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.PREFERENCE;
	}

} //PreferenceImpl
