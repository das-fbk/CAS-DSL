/**
 */
package ensembleModel.impl;

import ensembleModel.EnsembleModelPackage;
import ensembleModel.IssueParameter;
import ensembleModel.IssueType;
import ensembleModel.Solver;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Issue Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.impl.IssueTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link ensembleModel.impl.IssueTypeImpl#getIssueParameters <em>Issue Parameters</em>}</li>
 *   <li>{@link ensembleModel.impl.IssueTypeImpl#getSolvers <em>Solvers</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IssueTypeImpl extends MinimalEObjectImpl.Container implements IssueType {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIssueParameters() <em>Issue Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIssueParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<IssueParameter> issueParameters;

	/**
	 * The cached value of the '{@link #getSolvers() <em>Solvers</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSolvers()
	 * @generated
	 * @ordered
	 */
	protected EList<Solver> solvers;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IssueTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.ISSUE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.ISSUE_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IssueParameter> getIssueParameters() {
		if (issueParameters == null) {
			issueParameters = new EObjectContainmentEList<IssueParameter>(IssueParameter.class, this, EnsembleModelPackage.ISSUE_TYPE__ISSUE_PARAMETERS);
		}
		return issueParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Solver> getSolvers() {
		if (solvers == null) {
			solvers = new EObjectResolvingEList<Solver>(Solver.class, this, EnsembleModelPackage.ISSUE_TYPE__SOLVERS);
		}
		return solvers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case EnsembleModelPackage.ISSUE_TYPE__ISSUE_PARAMETERS:
				return ((InternalEList<?>)getIssueParameters()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case EnsembleModelPackage.ISSUE_TYPE__NAME:
				return getName();
			case EnsembleModelPackage.ISSUE_TYPE__ISSUE_PARAMETERS:
				return getIssueParameters();
			case EnsembleModelPackage.ISSUE_TYPE__SOLVERS:
				return getSolvers();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case EnsembleModelPackage.ISSUE_TYPE__NAME:
				setName((String)newValue);
				return;
			case EnsembleModelPackage.ISSUE_TYPE__ISSUE_PARAMETERS:
				getIssueParameters().clear();
				getIssueParameters().addAll((Collection<? extends IssueParameter>)newValue);
				return;
			case EnsembleModelPackage.ISSUE_TYPE__SOLVERS:
				getSolvers().clear();
				getSolvers().addAll((Collection<? extends Solver>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.ISSUE_TYPE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case EnsembleModelPackage.ISSUE_TYPE__ISSUE_PARAMETERS:
				getIssueParameters().clear();
				return;
			case EnsembleModelPackage.ISSUE_TYPE__SOLVERS:
				getSolvers().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.ISSUE_TYPE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case EnsembleModelPackage.ISSUE_TYPE__ISSUE_PARAMETERS:
				return issueParameters != null && !issueParameters.isEmpty();
			case EnsembleModelPackage.ISSUE_TYPE__SOLVERS:
				return solvers != null && !solvers.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //IssueTypeImpl
