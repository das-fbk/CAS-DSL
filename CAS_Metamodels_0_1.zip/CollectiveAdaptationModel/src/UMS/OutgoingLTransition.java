/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Outgoing LTransition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}</li>
 *   <li>{@link UMS.OutgoingLTransition#getLevent <em>Levent</em>}</li>
 *   <li>{@link UMS.OutgoingLTransition#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getOutgoingLTransition()
 * @model
 * @generated
 */
public interface OutgoingLTransition extends LTransition {
	/**
	 * Returns the value of the '<em><b>Linitialstate</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.LInitialState#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Linitialstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Linitialstate</em>' reference.
	 * @see #setLinitialstate(LInitialState)
	 * @see UMS.UMSPackage#getOutgoingLTransition_Linitialstate()
	 * @see UMS.LInitialState#getOutgoingltransitionIS
	 * @model opposite="outgoingltransitionIS"
	 * @generated
	 */
	LInitialState getLinitialstate();

	/**
	 * Sets the value of the '{@link UMS.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Linitialstate</em>' reference.
	 * @see #getLinitialstate()
	 * @generated
	 */
	void setLinitialstate(LInitialState value);

	/**
	 * Returns the value of the '<em><b>Levent</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.LEvent#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Levent</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Levent</em>' reference.
	 * @see #setLevent(LEvent)
	 * @see UMS.UMSPackage#getOutgoingLTransition_Levent()
	 * @see UMS.LEvent#getOutgoingltransition
	 * @model opposite="outgoingltransition"
	 * @generated
	 */
	LEvent getLevent();

	/**
	 * Sets the value of the '{@link UMS.OutgoingLTransition#getLevent <em>Levent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Levent</em>' reference.
	 * @see #getLevent()
	 * @generated
	 */
	void setLevent(LEvent value);

	/**
	 * Returns the value of the '<em><b>Lstate</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.LState#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstate</em>' reference.
	 * @see #setLstate(LState)
	 * @see UMS.UMSPackage#getOutgoingLTransition_Lstate()
	 * @see UMS.LState#getOutgoingltransition
	 * @model opposite="outgoingltransition"
	 * @generated
	 */
	LState getLstate();

	/**
	 * Sets the value of the '{@link UMS.OutgoingLTransition#getLstate <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lstate</em>' reference.
	 * @see #getLstate()
	 * @generated
	 */
	void setLstate(LState value);

} // OutgoingLTransition
