/**
 */
package UMS;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LTransition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UMS.UMSPackage#getLTransition()
 * @model abstract="true"
 * @generated
 */
public interface LTransition extends EObject {
} // LTransition
