/**
 */
package UMS;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UMS.UMSPackage#getTransition()
 * @model abstract="true"
 * @generated
 */
public interface Transition extends EObject {
} // Transition
