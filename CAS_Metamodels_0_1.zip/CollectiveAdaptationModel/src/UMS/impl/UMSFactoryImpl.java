/**
 */
package UMS.impl;

import UMS.AbstractActivity;
import UMS.AdaptiveSystem;
import UMS.ConcreteActivity;
import UMS.DomainObject;
import UMS.DomainProperty;
import UMS.Effect;
import UMS.Goal;
import UMS.IncomingLTransition;
import UMS.IncomingTransition;
import UMS.InputActivity;
import UMS.LEvent;
import UMS.LInitialState;
import UMS.LState;
import UMS.OutgoingLTransition;
import UMS.OutgoingTransition;
import UMS.OutputActivity;
import UMS.Precondition;
import UMS.State;
import UMS.UMSFactory;
import UMS.UMSPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class UMSFactoryImpl extends EFactoryImpl implements UMSFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static UMSFactory init() {
		try {
			UMSFactory theUMSFactory = (UMSFactory)EPackage.Registry.INSTANCE.getEFactory(UMSPackage.eNS_URI);
			if (theUMSFactory != null) {
				return theUMSFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new UMSFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UMSFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case UMSPackage.DOMAIN_OBJECT: return createDomainObject();
			case UMSPackage.PROCESS: return createProcess();
			case UMSPackage.INPUT_ACTIVITY: return createInputActivity();
			case UMSPackage.OUTPUT_ACTIVITY: return createOutputActivity();
			case UMSPackage.ABSTRACT_ACTIVITY: return createAbstractActivity();
			case UMSPackage.CONCRETE_ACTIVITY: return createConcreteActivity();
			case UMSPackage.STATE: return createState();
			case UMSPackage.OUTGOING_TRANSITION: return createOutgoingTransition();
			case UMSPackage.INCOMING_TRANSITION: return createIncomingTransition();
			case UMSPackage.PRECONDITION: return createPrecondition();
			case UMSPackage.EFFECT: return createEffect();
			case UMSPackage.GOAL: return createGoal();
			case UMSPackage.DOMAIN_PROPERTY: return createDomainProperty();
			case UMSPackage.LSTATE: return createLState();
			case UMSPackage.LINITIAL_STATE: return createLInitialState();
			case UMSPackage.LEVENT: return createLEvent();
			case UMSPackage.INCOMING_LTRANSITION: return createIncomingLTransition();
			case UMSPackage.OUTGOING_LTRANSITION: return createOutgoingLTransition();
			case UMSPackage.ADAPTIVE_SYSTEM: return createAdaptiveSystem();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainObject createDomainObject() {
		DomainObjectImpl domainObject = new DomainObjectImpl();
		return domainObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UMS.Process createProcess() {
		ProcessImpl process = new ProcessImpl();
		return process;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputActivity createInputActivity() {
		InputActivityImpl inputActivity = new InputActivityImpl();
		return inputActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputActivity createOutputActivity() {
		OutputActivityImpl outputActivity = new OutputActivityImpl();
		return outputActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractActivity createAbstractActivity() {
		AbstractActivityImpl abstractActivity = new AbstractActivityImpl();
		return abstractActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConcreteActivity createConcreteActivity() {
		ConcreteActivityImpl concreteActivity = new ConcreteActivityImpl();
		return concreteActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingTransition createOutgoingTransition() {
		OutgoingTransitionImpl outgoingTransition = new OutgoingTransitionImpl();
		return outgoingTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingTransition createIncomingTransition() {
		IncomingTransitionImpl incomingTransition = new IncomingTransitionImpl();
		return incomingTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Precondition createPrecondition() {
		PreconditionImpl precondition = new PreconditionImpl();
		return precondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effect createEffect() {
		EffectImpl effect = new EffectImpl();
		return effect;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Goal createGoal() {
		GoalImpl goal = new GoalImpl();
		return goal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainProperty createDomainProperty() {
		DomainPropertyImpl domainProperty = new DomainPropertyImpl();
		return domainProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LState createLState() {
		LStateImpl lState = new LStateImpl();
		return lState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LInitialState createLInitialState() {
		LInitialStateImpl lInitialState = new LInitialStateImpl();
		return lInitialState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LEvent createLEvent() {
		LEventImpl lEvent = new LEventImpl();
		return lEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingLTransition createIncomingLTransition() {
		IncomingLTransitionImpl incomingLTransition = new IncomingLTransitionImpl();
		return incomingLTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition createOutgoingLTransition() {
		OutgoingLTransitionImpl outgoingLTransition = new OutgoingLTransitionImpl();
		return outgoingLTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptiveSystem createAdaptiveSystem() {
		AdaptiveSystemImpl adaptiveSystem = new AdaptiveSystemImpl();
		return adaptiveSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UMSPackage getUMSPackage() {
		return (UMSPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static UMSPackage getPackage() {
		return UMSPackage.eINSTANCE;
	}

} //UMSFactoryImpl
