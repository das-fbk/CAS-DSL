/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.Solver;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Solver</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.SolverImpl#getSolverSpecification <em>Solver Specification</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SolverImpl extends MinimalEObjectImpl.Container implements Solver {
	/**
	 * The cached value of the '{@link #getSolverSpecification() <em>Solver Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSolverSpecification()
	 * @generated
	 * @ordered
	 */
	protected ensembleModel.Solver solverSpecification;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SolverImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.SOLVER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ensembleModel.Solver getSolverSpecification() {
		if (solverSpecification != null && solverSpecification.eIsProxy()) {
			InternalEObject oldSolverSpecification = (InternalEObject)solverSpecification;
			solverSpecification = (ensembleModel.Solver)eResolveProxy(oldSolverSpecification);
			if (solverSpecification != oldSolverSpecification) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollectiveAdaptationModelPackage.SOLVER__SOLVER_SPECIFICATION, oldSolverSpecification, solverSpecification));
			}
		}
		return solverSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ensembleModel.Solver basicGetSolverSpecification() {
		return solverSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSolverSpecification(ensembleModel.Solver newSolverSpecification) {
		ensembleModel.Solver oldSolverSpecification = solverSpecification;
		solverSpecification = newSolverSpecification;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollectiveAdaptationModelPackage.SOLVER__SOLVER_SPECIFICATION, oldSolverSpecification, solverSpecification));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.SOLVER__SOLVER_SPECIFICATION:
				if (resolve) return getSolverSpecification();
				return basicGetSolverSpecification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.SOLVER__SOLVER_SPECIFICATION:
				setSolverSpecification((ensembleModel.Solver)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.SOLVER__SOLVER_SPECIFICATION:
				setSolverSpecification((ensembleModel.Solver)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.SOLVER__SOLVER_SPECIFICATION:
				return solverSpecification != null;
		}
		return super.eIsSet(featureID);
	}

} //SolverImpl
