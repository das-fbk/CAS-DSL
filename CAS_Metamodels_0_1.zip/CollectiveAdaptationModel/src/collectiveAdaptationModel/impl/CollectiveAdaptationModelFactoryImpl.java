/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollectiveAdaptationModelFactoryImpl extends EFactoryImpl implements CollectiveAdaptationModelFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CollectiveAdaptationModelFactory init() {
		try {
			CollectiveAdaptationModelFactory theCollectiveAdaptationModelFactory = (CollectiveAdaptationModelFactory)EPackage.Registry.INSTANCE.getEFactory(CollectiveAdaptationModelPackage.eNS_URI);
			if (theCollectiveAdaptationModelFactory != null) {
				return theCollectiveAdaptationModelFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CollectiveAdaptationModelFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollectiveAdaptationModelFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CollectiveAdaptationModelPackage.COLLECTIVE_ADAPTATION: return createCollectiveAdaptation();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER: return createEventHandler();
			case CollectiveAdaptationModelPackage.EVENT: return createEvent();
			case CollectiveAdaptationModelPackage.ADAPTATION: return createAdaptation();
			case CollectiveAdaptationModelPackage.ROLE_ACTIVITY: return createRoleActivity();
			case CollectiveAdaptationModelPackage.ISSUE_TYPE: return createIssueType();
			case CollectiveAdaptationModelPackage.SOLVER: return createSolver();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollectiveAdaptation createCollectiveAdaptation() {
		CollectiveAdaptationImpl collectiveAdaptation = new CollectiveAdaptationImpl();
		return collectiveAdaptation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventHandler createEventHandler() {
		EventHandlerImpl eventHandler = new EventHandlerImpl();
		return eventHandler;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Event createEvent() {
		EventImpl event = new EventImpl();
		return event;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Adaptation createAdaptation() {
		AdaptationImpl adaptation = new AdaptationImpl();
		return adaptation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleActivity createRoleActivity() {
		RoleActivityImpl roleActivity = new RoleActivityImpl();
		return roleActivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IssueType createIssueType() {
		IssueTypeImpl issueType = new IssueTypeImpl();
		return issueType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Solver createSolver() {
		SolverImpl solver = new SolverImpl();
		return solver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollectiveAdaptationModelPackage getCollectiveAdaptationModelPackage() {
		return (CollectiveAdaptationModelPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CollectiveAdaptationModelPackage getPackage() {
		return CollectiveAdaptationModelPackage.eINSTANCE;
	}

} //CollectiveAdaptationModelFactoryImpl
