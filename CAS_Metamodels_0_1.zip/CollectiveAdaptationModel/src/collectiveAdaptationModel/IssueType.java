/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.ecore.EObject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Issue Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.IssueType#getIssueSpecification <em>Issue Specification</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getIssueType()
 * @model
 * @generated
 */
public interface IssueType extends EObject {

	/**
	 * Returns the value of the '<em><b>Issue Specification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Issue Specification</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Issue Specification</em>' reference.
	 * @see #setIssueSpecification(ensembleModel.IssueType)
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getIssueType_IssueSpecification()
	 * @model required="true"
	 * @generated
	 */
	ensembleModel.IssueType getIssueSpecification();

	/**
	 * Sets the value of the '{@link collectiveAdaptationModel.IssueType#getIssueSpecification <em>Issue Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Issue Specification</em>' reference.
	 * @see #getIssueSpecification()
	 * @generated
	 */
	void setIssueSpecification(ensembleModel.IssueType value);
} // IssueType
