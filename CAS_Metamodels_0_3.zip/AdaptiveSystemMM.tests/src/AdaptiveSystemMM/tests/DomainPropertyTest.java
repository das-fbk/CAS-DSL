/**
 */
package AdaptiveSystemMM.tests;

import AdaptiveSystemMM.AdaptiveSystemMMFactory;
import AdaptiveSystemMM.DomainProperty;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Domain Property</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class DomainPropertyTest extends TestCase {

	/**
	 * The fixture for this Domain Property test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DomainProperty fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DomainPropertyTest.class);
	}

	/**
	 * Constructs a new Domain Property test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainPropertyTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Domain Property test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(DomainProperty fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Domain Property test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DomainProperty getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(AdaptiveSystemMMFactory.eINSTANCE.createDomainProperty());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //DomainPropertyTest
