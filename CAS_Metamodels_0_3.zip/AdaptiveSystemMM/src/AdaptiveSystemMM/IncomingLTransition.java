/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Incoming LTransition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.IncomingLTransition#getLevent <em>Levent</em>}</li>
 *   <li>{@link AdaptiveSystemMM.IncomingLTransition#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getIncomingLTransition()
 * @model
 * @generated
 */
public interface IncomingLTransition extends LTransition {
	/**
	 * Returns the value of the '<em><b>Levent</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.LEvent#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Levent</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Levent</em>' reference.
	 * @see #setLevent(LEvent)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getIncomingLTransition_Levent()
	 * @see AdaptiveSystemMM.LEvent#getIncomingltransition
	 * @model opposite="incomingltransition"
	 * @generated
	 */
	LEvent getLevent();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.IncomingLTransition#getLevent <em>Levent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Levent</em>' reference.
	 * @see #getLevent()
	 * @generated
	 */
	void setLevent(LEvent value);

	/**
	 * Returns the value of the '<em><b>Lstate</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.LState#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstate</em>' reference.
	 * @see #setLstate(LState)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getIncomingLTransition_Lstate()
	 * @see AdaptiveSystemMM.LState#getIncomingltransition
	 * @model opposite="incomingltransition"
	 * @generated
	 */
	LState getLstate();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.IncomingLTransition#getLstate <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lstate</em>' reference.
	 * @see #getLstate()
	 * @generated
	 */
	void setLstate(LState value);

} // IncomingLTransition
