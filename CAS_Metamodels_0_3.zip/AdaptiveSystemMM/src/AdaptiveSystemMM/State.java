/**
 */
package AdaptiveSystemMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.State#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.State#isIsInitial <em>Is Initial</em>}</li>
 *   <li>{@link AdaptiveSystemMM.State#getIncomingtransition <em>Incomingtransition</em>}</li>
 *   <li>{@link AdaptiveSystemMM.State#getOutgoingtransition <em>Outgoingtransition</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getState()
 * @model
 * @generated
 */
public interface State extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getState_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.State#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Is Initial</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Initial</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Initial</em>' attribute.
	 * @see #setIsInitial(boolean)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getState_IsInitial()
	 * @model
	 * @generated
	 */
	boolean isIsInitial();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.State#isIsInitial <em>Is Initial</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Initial</em>' attribute.
	 * @see #isIsInitial()
	 * @generated
	 */
	void setIsInitial(boolean value);

	/**
	 * Returns the value of the '<em><b>Incomingtransition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.IncomingTransition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incomingtransition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incomingtransition</em>' reference.
	 * @see #setIncomingtransition(IncomingTransition)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getState_Incomingtransition()
	 * @see AdaptiveSystemMM.IncomingTransition#getState
	 * @model opposite="state"
	 * @generated
	 */
	IncomingTransition getIncomingtransition();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.State#getIncomingtransition <em>Incomingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Incomingtransition</em>' reference.
	 * @see #getIncomingtransition()
	 * @generated
	 */
	void setIncomingtransition(IncomingTransition value);

	/**
	 * Returns the value of the '<em><b>Outgoingtransition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.OutgoingTransition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoingtransition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoingtransition</em>' reference.
	 * @see #setOutgoingtransition(OutgoingTransition)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getState_Outgoingtransition()
	 * @see AdaptiveSystemMM.OutgoingTransition#getState
	 * @model opposite="state"
	 * @generated
	 */
	OutgoingTransition getOutgoingtransition();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.State#getOutgoingtransition <em>Outgoingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outgoingtransition</em>' reference.
	 * @see #getOutgoingtransition()
	 * @generated
	 */
	void setOutgoingtransition(OutgoingTransition value);

} // State
