/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Precondition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.Precondition#getActivity <em>Activity</em>}</li>
 *   <li>{@link AdaptiveSystemMM.Precondition#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getPrecondition()
 * @model
 * @generated
 */
public interface Precondition extends Annotation {
	/**
	 * Returns the value of the '<em><b>Activity</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.Activity#getPrecondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activity</em>' reference.
	 * @see #setActivity(Activity)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getPrecondition_Activity()
	 * @see AdaptiveSystemMM.Activity#getPrecondition
	 * @model opposite="precondition"
	 * @generated
	 */
	Activity getActivity();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.Precondition#getActivity <em>Activity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activity</em>' reference.
	 * @see #getActivity()
	 * @generated
	 */
	void setActivity(Activity value);

	/**
	 * Returns the value of the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstate</em>' reference.
	 * @see #setLstate(LState)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getPrecondition_Lstate()
	 * @model
	 * @generated
	 */
	LState getLstate();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.Precondition#getLstate <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lstate</em>' reference.
	 * @see #getLstate()
	 * @generated
	 */
	void setLstate(LState value);

} // Precondition
