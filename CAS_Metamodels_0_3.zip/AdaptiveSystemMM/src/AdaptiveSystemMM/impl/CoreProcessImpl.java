/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.CoreProcess;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Core Process</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CoreProcessImpl extends ProcessImpl implements CoreProcess {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CoreProcessImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.CORE_PROCESS;
	}

} //CoreProcessImpl
