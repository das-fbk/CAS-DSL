/**
 */
package AdaptiveSystemMM.impl;

import AdaptiveSystemMM.AbstractActivity;
import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.Goal;
import AdaptiveSystemMM.LState;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Goal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.impl.GoalImpl#getAbstractactivity <em>Abstractactivity</em>}</li>
 *   <li>{@link AdaptiveSystemMM.impl.GoalImpl#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GoalImpl extends AnnotationImpl implements Goal {
	/**
	 * The cached value of the '{@link #getAbstractactivity() <em>Abstractactivity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstractactivity()
	 * @generated
	 * @ordered
	 */
	protected AbstractActivity abstractactivity;

	/**
	 * The cached value of the '{@link #getLstate() <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLstate()
	 * @generated
	 * @ordered
	 */
	protected LState lstate;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GoalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AdaptiveSystemMMPackage.Literals.GOAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractActivity getAbstractactivity() {
		if (abstractactivity != null && abstractactivity.eIsProxy()) {
			InternalEObject oldAbstractactivity = (InternalEObject)abstractactivity;
			abstractactivity = (AbstractActivity)eResolveProxy(oldAbstractactivity);
			if (abstractactivity != oldAbstractactivity) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY, oldAbstractactivity, abstractactivity));
			}
		}
		return abstractactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractActivity basicGetAbstractactivity() {
		return abstractactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAbstractactivity(AbstractActivity newAbstractactivity, NotificationChain msgs) {
		AbstractActivity oldAbstractactivity = abstractactivity;
		abstractactivity = newAbstractactivity;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY, oldAbstractactivity, newAbstractactivity);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAbstractactivity(AbstractActivity newAbstractactivity) {
		if (newAbstractactivity != abstractactivity) {
			NotificationChain msgs = null;
			if (abstractactivity != null)
				msgs = ((InternalEObject)abstractactivity).eInverseRemove(this, AdaptiveSystemMMPackage.ABSTRACT_ACTIVITY__GOAL, AbstractActivity.class, msgs);
			if (newAbstractactivity != null)
				msgs = ((InternalEObject)newAbstractactivity).eInverseAdd(this, AdaptiveSystemMMPackage.ABSTRACT_ACTIVITY__GOAL, AbstractActivity.class, msgs);
			msgs = basicSetAbstractactivity(newAbstractactivity, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY, newAbstractactivity, newAbstractactivity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LState getLstate() {
		if (lstate != null && lstate.eIsProxy()) {
			InternalEObject oldLstate = (InternalEObject)lstate;
			lstate = (LState)eResolveProxy(oldLstate);
			if (lstate != oldLstate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AdaptiveSystemMMPackage.GOAL__LSTATE, oldLstate, lstate));
			}
		}
		return lstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LState basicGetLstate() {
		return lstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLstate(LState newLstate) {
		LState oldLstate = lstate;
		lstate = newLstate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AdaptiveSystemMMPackage.GOAL__LSTATE, oldLstate, lstate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY:
				if (abstractactivity != null)
					msgs = ((InternalEObject)abstractactivity).eInverseRemove(this, AdaptiveSystemMMPackage.ABSTRACT_ACTIVITY__GOAL, AbstractActivity.class, msgs);
				return basicSetAbstractactivity((AbstractActivity)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY:
				return basicSetAbstractactivity(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY:
				if (resolve) return getAbstractactivity();
				return basicGetAbstractactivity();
			case AdaptiveSystemMMPackage.GOAL__LSTATE:
				if (resolve) return getLstate();
				return basicGetLstate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY:
				setAbstractactivity((AbstractActivity)newValue);
				return;
			case AdaptiveSystemMMPackage.GOAL__LSTATE:
				setLstate((LState)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY:
				setAbstractactivity((AbstractActivity)null);
				return;
			case AdaptiveSystemMMPackage.GOAL__LSTATE:
				setLstate((LState)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AdaptiveSystemMMPackage.GOAL__ABSTRACTACTIVITY:
				return abstractactivity != null;
			case AdaptiveSystemMMPackage.GOAL__LSTATE:
				return lstate != null;
		}
		return super.eIsSet(featureID);
	}

} //GoalImpl
