/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Incoming Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.IncomingTransition#getState <em>State</em>}</li>
 *   <li>{@link AdaptiveSystemMM.IncomingTransition#getInputactivity <em>Inputactivity</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getIncomingTransition()
 * @model
 * @generated
 */
public interface IncomingTransition extends Transition {
	/**
	 * Returns the value of the '<em><b>State</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.State#getIncomingtransition <em>Incomingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' reference.
	 * @see #setState(State)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getIncomingTransition_State()
	 * @see AdaptiveSystemMM.State#getIncomingtransition
	 * @model opposite="incomingtransition"
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.IncomingTransition#getState <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

	/**
	 * Returns the value of the '<em><b>Inputactivity</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.InputActivity#getIncomingtransition <em>Incomingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Inputactivity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inputactivity</em>' reference.
	 * @see #setInputactivity(InputActivity)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getIncomingTransition_Inputactivity()
	 * @see AdaptiveSystemMM.InputActivity#getIncomingtransition
	 * @model opposite="incomingtransition"
	 * @generated
	 */
	InputActivity getInputactivity();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.IncomingTransition#getInputactivity <em>Inputactivity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Inputactivity</em>' reference.
	 * @see #getInputactivity()
	 * @generated
	 */
	void setInputactivity(InputActivity value);

} // IncomingTransition
