/**
 */
package AdaptiveSystemMM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage
 * @generated
 */
public interface AdaptiveSystemMMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AdaptiveSystemMMFactory eINSTANCE = AdaptiveSystemMM.impl.AdaptiveSystemMMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Domain Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Domain Object</em>'.
	 * @generated
	 */
	DomainObject createDomainObject();

	/**
	 * Returns a new object of class '<em>Input Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Activity</em>'.
	 * @generated
	 */
	InputActivity createInputActivity();

	/**
	 * Returns a new object of class '<em>Output Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Output Activity</em>'.
	 * @generated
	 */
	OutputActivity createOutputActivity();

	/**
	 * Returns a new object of class '<em>Abstract Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Activity</em>'.
	 * @generated
	 */
	AbstractActivity createAbstractActivity();

	/**
	 * Returns a new object of class '<em>Concrete Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Concrete Activity</em>'.
	 * @generated
	 */
	ConcreteActivity createConcreteActivity();

	/**
	 * Returns a new object of class '<em>State</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State</em>'.
	 * @generated
	 */
	State createState();

	/**
	 * Returns a new object of class '<em>Outgoing Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Outgoing Transition</em>'.
	 * @generated
	 */
	OutgoingTransition createOutgoingTransition();

	/**
	 * Returns a new object of class '<em>Incoming Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Incoming Transition</em>'.
	 * @generated
	 */
	IncomingTransition createIncomingTransition();

	/**
	 * Returns a new object of class '<em>Precondition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Precondition</em>'.
	 * @generated
	 */
	Precondition createPrecondition();

	/**
	 * Returns a new object of class '<em>Effect</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Effect</em>'.
	 * @generated
	 */
	Effect createEffect();

	/**
	 * Returns a new object of class '<em>Goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Goal</em>'.
	 * @generated
	 */
	Goal createGoal();

	/**
	 * Returns a new object of class '<em>Domain Property</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Domain Property</em>'.
	 * @generated
	 */
	DomainProperty createDomainProperty();

	/**
	 * Returns a new object of class '<em>LState</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>LState</em>'.
	 * @generated
	 */
	LState createLState();

	/**
	 * Returns a new object of class '<em>LInitial State</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>LInitial State</em>'.
	 * @generated
	 */
	LInitialState createLInitialState();

	/**
	 * Returns a new object of class '<em>LEvent</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>LEvent</em>'.
	 * @generated
	 */
	LEvent createLEvent();

	/**
	 * Returns a new object of class '<em>Incoming LTransition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Incoming LTransition</em>'.
	 * @generated
	 */
	IncomingLTransition createIncomingLTransition();

	/**
	 * Returns a new object of class '<em>Outgoing LTransition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Outgoing LTransition</em>'.
	 * @generated
	 */
	OutgoingLTransition createOutgoingLTransition();

	/**
	 * Returns a new object of class '<em>Adaptive System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Adaptive System</em>'.
	 * @generated
	 */
	AdaptiveSystem createAdaptiveSystem();

	/**
	 * Returns a new object of class '<em>Core Process</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Core Process</em>'.
	 * @generated
	 */
	CoreProcess createCoreProcess();

	/**
	 * Returns a new object of class '<em>Fragment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fragment</em>'.
	 * @generated
	 */
	Fragment createFragment();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	AdaptiveSystemMMPackage getAdaptiveSystemMMPackage();

} //AdaptiveSystemMMFactory
