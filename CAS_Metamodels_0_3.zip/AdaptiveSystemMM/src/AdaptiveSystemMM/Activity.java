/**
 */
package AdaptiveSystemMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link AdaptiveSystemMM.Activity#getName <em>Name</em>}</li>
 *   <li>{@link AdaptiveSystemMM.Activity#getPrecondition <em>Precondition</em>}</li>
 *   <li>{@link AdaptiveSystemMM.Activity#getEffect <em>Effect</em>}</li>
 * </ul>
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getActivity()
 * @model abstract="true"
 * @generated
 */
public interface Activity extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getActivity_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.Activity#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Precondition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.Precondition#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Precondition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Precondition</em>' reference.
	 * @see #setPrecondition(Precondition)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getActivity_Precondition()
	 * @see AdaptiveSystemMM.Precondition#getActivity
	 * @model opposite="activity"
	 * @generated
	 */
	Precondition getPrecondition();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.Activity#getPrecondition <em>Precondition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Precondition</em>' reference.
	 * @see #getPrecondition()
	 * @generated
	 */
	void setPrecondition(Precondition value);

	/**
	 * Returns the value of the '<em><b>Effect</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link AdaptiveSystemMM.Effect#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Effect</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effect</em>' reference.
	 * @see #setEffect(Effect)
	 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getActivity_Effect()
	 * @see AdaptiveSystemMM.Effect#getActivity
	 * @model opposite="activity"
	 * @generated
	 */
	Effect getEffect();

	/**
	 * Sets the value of the '{@link AdaptiveSystemMM.Activity#getEffect <em>Effect</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effect</em>' reference.
	 * @see #getEffect()
	 * @generated
	 */
	void setEffect(Effect value);

} // Activity
