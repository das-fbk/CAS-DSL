/**
 */
package AdaptiveSystemMM.util;

import AdaptiveSystemMM.AbstractActivity;
import AdaptiveSystemMM.Activity;
import AdaptiveSystemMM.AdaptiveSystem;
import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.Annotation;
import AdaptiveSystemMM.ConcreteActivity;
import AdaptiveSystemMM.CoreProcess;
import AdaptiveSystemMM.DomainObject;
import AdaptiveSystemMM.DomainProperty;
import AdaptiveSystemMM.Effect;
import AdaptiveSystemMM.Fragment;
import AdaptiveSystemMM.Goal;
import AdaptiveSystemMM.IncomingLTransition;
import AdaptiveSystemMM.IncomingTransition;
import AdaptiveSystemMM.InputActivity;
import AdaptiveSystemMM.LEvent;
import AdaptiveSystemMM.LInitialState;
import AdaptiveSystemMM.LState;
import AdaptiveSystemMM.LTransition;
import AdaptiveSystemMM.OutgoingLTransition;
import AdaptiveSystemMM.OutgoingTransition;
import AdaptiveSystemMM.OutputActivity;
import AdaptiveSystemMM.Precondition;
import AdaptiveSystemMM.State;
import AdaptiveSystemMM.Transition;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage
 * @generated
 */
public class AdaptiveSystemMMAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AdaptiveSystemMMPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptiveSystemMMAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = AdaptiveSystemMMPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AdaptiveSystemMMSwitch<Adapter> modelSwitch =
		new AdaptiveSystemMMSwitch<Adapter>() {
			@Override
			public Adapter caseDomainObject(DomainObject object) {
				return createDomainObjectAdapter();
			}
			@Override
			public Adapter caseProcess(AdaptiveSystemMM.Process object) {
				return createProcessAdapter();
			}
			@Override
			public Adapter caseActivity(Activity object) {
				return createActivityAdapter();
			}
			@Override
			public Adapter caseInputActivity(InputActivity object) {
				return createInputActivityAdapter();
			}
			@Override
			public Adapter caseOutputActivity(OutputActivity object) {
				return createOutputActivityAdapter();
			}
			@Override
			public Adapter caseAbstractActivity(AbstractActivity object) {
				return createAbstractActivityAdapter();
			}
			@Override
			public Adapter caseConcreteActivity(ConcreteActivity object) {
				return createConcreteActivityAdapter();
			}
			@Override
			public Adapter caseState(State object) {
				return createStateAdapter();
			}
			@Override
			public Adapter caseTransition(Transition object) {
				return createTransitionAdapter();
			}
			@Override
			public Adapter caseOutgoingTransition(OutgoingTransition object) {
				return createOutgoingTransitionAdapter();
			}
			@Override
			public Adapter caseIncomingTransition(IncomingTransition object) {
				return createIncomingTransitionAdapter();
			}
			@Override
			public Adapter caseAnnotation(Annotation object) {
				return createAnnotationAdapter();
			}
			@Override
			public Adapter casePrecondition(Precondition object) {
				return createPreconditionAdapter();
			}
			@Override
			public Adapter caseEffect(Effect object) {
				return createEffectAdapter();
			}
			@Override
			public Adapter caseGoal(Goal object) {
				return createGoalAdapter();
			}
			@Override
			public Adapter caseDomainProperty(DomainProperty object) {
				return createDomainPropertyAdapter();
			}
			@Override
			public Adapter caseLState(LState object) {
				return createLStateAdapter();
			}
			@Override
			public Adapter caseLInitialState(LInitialState object) {
				return createLInitialStateAdapter();
			}
			@Override
			public Adapter caseLEvent(LEvent object) {
				return createLEventAdapter();
			}
			@Override
			public Adapter caseLTransition(LTransition object) {
				return createLTransitionAdapter();
			}
			@Override
			public Adapter caseIncomingLTransition(IncomingLTransition object) {
				return createIncomingLTransitionAdapter();
			}
			@Override
			public Adapter caseOutgoingLTransition(OutgoingLTransition object) {
				return createOutgoingLTransitionAdapter();
			}
			@Override
			public Adapter caseAdaptiveSystem(AdaptiveSystem object) {
				return createAdaptiveSystemAdapter();
			}
			@Override
			public Adapter caseCoreProcess(CoreProcess object) {
				return createCoreProcessAdapter();
			}
			@Override
			public Adapter caseFragment(Fragment object) {
				return createFragmentAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.DomainObject <em>Domain Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.DomainObject
	 * @generated
	 */
	public Adapter createDomainObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Process <em>Process</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Process
	 * @generated
	 */
	public Adapter createProcessAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Activity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Activity
	 * @generated
	 */
	public Adapter createActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.InputActivity <em>Input Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.InputActivity
	 * @generated
	 */
	public Adapter createInputActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.OutputActivity <em>Output Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.OutputActivity
	 * @generated
	 */
	public Adapter createOutputActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.AbstractActivity <em>Abstract Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.AbstractActivity
	 * @generated
	 */
	public Adapter createAbstractActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.ConcreteActivity <em>Concrete Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.ConcreteActivity
	 * @generated
	 */
	public Adapter createConcreteActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.State
	 * @generated
	 */
	public Adapter createStateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Transition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Transition
	 * @generated
	 */
	public Adapter createTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.OutgoingTransition <em>Outgoing Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.OutgoingTransition
	 * @generated
	 */
	public Adapter createOutgoingTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.IncomingTransition <em>Incoming Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.IncomingTransition
	 * @generated
	 */
	public Adapter createIncomingTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Annotation <em>Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Annotation
	 * @generated
	 */
	public Adapter createAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Precondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Precondition
	 * @generated
	 */
	public Adapter createPreconditionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Effect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Effect
	 * @generated
	 */
	public Adapter createEffectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Goal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Goal
	 * @generated
	 */
	public Adapter createGoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.DomainProperty <em>Domain Property</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.DomainProperty
	 * @generated
	 */
	public Adapter createDomainPropertyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.LState <em>LState</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.LState
	 * @generated
	 */
	public Adapter createLStateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.LInitialState <em>LInitial State</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.LInitialState
	 * @generated
	 */
	public Adapter createLInitialStateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.LEvent <em>LEvent</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.LEvent
	 * @generated
	 */
	public Adapter createLEventAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.LTransition <em>LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.LTransition
	 * @generated
	 */
	public Adapter createLTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.IncomingLTransition <em>Incoming LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.IncomingLTransition
	 * @generated
	 */
	public Adapter createIncomingLTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.OutgoingLTransition <em>Outgoing LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.OutgoingLTransition
	 * @generated
	 */
	public Adapter createOutgoingLTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.AdaptiveSystem <em>Adaptive System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.AdaptiveSystem
	 * @generated
	 */
	public Adapter createAdaptiveSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.CoreProcess <em>Core Process</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.CoreProcess
	 * @generated
	 */
	public Adapter createCoreProcessAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link AdaptiveSystemMM.Fragment <em>Fragment</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see AdaptiveSystemMM.Fragment
	 * @generated
	 */
	public Adapter createFragmentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //AdaptiveSystemMMAdapterFactory
