/**
 */
package AdaptiveSystemMM.util;

import AdaptiveSystemMM.AbstractActivity;
import AdaptiveSystemMM.Activity;
import AdaptiveSystemMM.AdaptiveSystem;
import AdaptiveSystemMM.AdaptiveSystemMMPackage;
import AdaptiveSystemMM.Annotation;
import AdaptiveSystemMM.ConcreteActivity;
import AdaptiveSystemMM.CoreProcess;
import AdaptiveSystemMM.DomainObject;
import AdaptiveSystemMM.DomainProperty;
import AdaptiveSystemMM.Effect;
import AdaptiveSystemMM.Fragment;
import AdaptiveSystemMM.Goal;
import AdaptiveSystemMM.IncomingLTransition;
import AdaptiveSystemMM.IncomingTransition;
import AdaptiveSystemMM.InputActivity;
import AdaptiveSystemMM.LEvent;
import AdaptiveSystemMM.LInitialState;
import AdaptiveSystemMM.LState;
import AdaptiveSystemMM.LTransition;
import AdaptiveSystemMM.OutgoingLTransition;
import AdaptiveSystemMM.OutgoingTransition;
import AdaptiveSystemMM.OutputActivity;
import AdaptiveSystemMM.Precondition;
import AdaptiveSystemMM.State;
import AdaptiveSystemMM.Transition;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage
 * @generated
 */
public class AdaptiveSystemMMSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AdaptiveSystemMMPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdaptiveSystemMMSwitch() {
		if (modelPackage == null) {
			modelPackage = AdaptiveSystemMMPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case AdaptiveSystemMMPackage.DOMAIN_OBJECT: {
				DomainObject domainObject = (DomainObject)theEObject;
				T result = caseDomainObject(domainObject);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.PROCESS: {
				AdaptiveSystemMM.Process process = (AdaptiveSystemMM.Process)theEObject;
				T result = caseProcess(process);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.ACTIVITY: {
				Activity activity = (Activity)theEObject;
				T result = caseActivity(activity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.INPUT_ACTIVITY: {
				InputActivity inputActivity = (InputActivity)theEObject;
				T result = caseInputActivity(inputActivity);
				if (result == null) result = caseActivity(inputActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.OUTPUT_ACTIVITY: {
				OutputActivity outputActivity = (OutputActivity)theEObject;
				T result = caseOutputActivity(outputActivity);
				if (result == null) result = caseActivity(outputActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.ABSTRACT_ACTIVITY: {
				AbstractActivity abstractActivity = (AbstractActivity)theEObject;
				T result = caseAbstractActivity(abstractActivity);
				if (result == null) result = caseActivity(abstractActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.CONCRETE_ACTIVITY: {
				ConcreteActivity concreteActivity = (ConcreteActivity)theEObject;
				T result = caseConcreteActivity(concreteActivity);
				if (result == null) result = caseActivity(concreteActivity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.STATE: {
				State state = (State)theEObject;
				T result = caseState(state);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.TRANSITION: {
				Transition transition = (Transition)theEObject;
				T result = caseTransition(transition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.OUTGOING_TRANSITION: {
				OutgoingTransition outgoingTransition = (OutgoingTransition)theEObject;
				T result = caseOutgoingTransition(outgoingTransition);
				if (result == null) result = caseTransition(outgoingTransition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.INCOMING_TRANSITION: {
				IncomingTransition incomingTransition = (IncomingTransition)theEObject;
				T result = caseIncomingTransition(incomingTransition);
				if (result == null) result = caseTransition(incomingTransition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.ANNOTATION: {
				Annotation annotation = (Annotation)theEObject;
				T result = caseAnnotation(annotation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.PRECONDITION: {
				Precondition precondition = (Precondition)theEObject;
				T result = casePrecondition(precondition);
				if (result == null) result = caseAnnotation(precondition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.EFFECT: {
				Effect effect = (Effect)theEObject;
				T result = caseEffect(effect);
				if (result == null) result = caseAnnotation(effect);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.GOAL: {
				Goal goal = (Goal)theEObject;
				T result = caseGoal(goal);
				if (result == null) result = caseAnnotation(goal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.DOMAIN_PROPERTY: {
				DomainProperty domainProperty = (DomainProperty)theEObject;
				T result = caseDomainProperty(domainProperty);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.LSTATE: {
				LState lState = (LState)theEObject;
				T result = caseLState(lState);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.LINITIAL_STATE: {
				LInitialState lInitialState = (LInitialState)theEObject;
				T result = caseLInitialState(lInitialState);
				if (result == null) result = caseLState(lInitialState);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.LEVENT: {
				LEvent lEvent = (LEvent)theEObject;
				T result = caseLEvent(lEvent);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.LTRANSITION: {
				LTransition lTransition = (LTransition)theEObject;
				T result = caseLTransition(lTransition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.INCOMING_LTRANSITION: {
				IncomingLTransition incomingLTransition = (IncomingLTransition)theEObject;
				T result = caseIncomingLTransition(incomingLTransition);
				if (result == null) result = caseLTransition(incomingLTransition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.OUTGOING_LTRANSITION: {
				OutgoingLTransition outgoingLTransition = (OutgoingLTransition)theEObject;
				T result = caseOutgoingLTransition(outgoingLTransition);
				if (result == null) result = caseLTransition(outgoingLTransition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.ADAPTIVE_SYSTEM: {
				AdaptiveSystem adaptiveSystem = (AdaptiveSystem)theEObject;
				T result = caseAdaptiveSystem(adaptiveSystem);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.CORE_PROCESS: {
				CoreProcess coreProcess = (CoreProcess)theEObject;
				T result = caseCoreProcess(coreProcess);
				if (result == null) result = caseProcess(coreProcess);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AdaptiveSystemMMPackage.FRAGMENT: {
				Fragment fragment = (Fragment)theEObject;
				T result = caseFragment(fragment);
				if (result == null) result = caseProcess(fragment);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Domain Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Domain Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDomainObject(DomainObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Process</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Process</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseProcess(AdaptiveSystemMM.Process object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActivity(Activity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputActivity(InputActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Output Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Output Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOutputActivity(OutputActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Abstract Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Abstract Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAbstractActivity(AbstractActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Concrete Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Concrete Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConcreteActivity(ConcreteActivity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>State</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>State</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseState(State object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransition(Transition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Outgoing Transition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Outgoing Transition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOutgoingTransition(OutgoingTransition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Incoming Transition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Incoming Transition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIncomingTransition(IncomingTransition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAnnotation(Annotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Precondition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Precondition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePrecondition(Precondition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Effect</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Effect</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEffect(Effect object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Goal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Goal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGoal(Goal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Domain Property</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Domain Property</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDomainProperty(DomainProperty object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>LState</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>LState</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLState(LState object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>LInitial State</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>LInitial State</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLInitialState(LInitialState object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>LEvent</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>LEvent</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLEvent(LEvent object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>LTransition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>LTransition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLTransition(LTransition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Incoming LTransition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Incoming LTransition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIncomingLTransition(IncomingLTransition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Outgoing LTransition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Outgoing LTransition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOutgoingLTransition(OutgoingLTransition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Adaptive System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Adaptive System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAdaptiveSystem(AdaptiveSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Core Process</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Core Process</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCoreProcess(CoreProcess object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fragment</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fragment</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFragment(Fragment object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //AdaptiveSystemMMSwitch
