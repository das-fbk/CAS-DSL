/**
 */
package AdaptiveSystemMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Concrete Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see AdaptiveSystemMM.AdaptiveSystemMMPackage#getConcreteActivity()
 * @model
 * @generated
 */
public interface ConcreteActivity extends Activity {
} // ConcreteActivity
