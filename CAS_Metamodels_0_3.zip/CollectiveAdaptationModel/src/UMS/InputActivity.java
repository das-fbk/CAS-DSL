/**
 */
package UMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.InputActivity#getIncomingtransition <em>Incomingtransition</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getInputActivity()
 * @model
 * @generated
 */
public interface InputActivity extends Activity {
	/**
	 * Returns the value of the '<em><b>Incomingtransition</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link UMS.IncomingTransition#getInputactivity <em>Inputactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incomingtransition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incomingtransition</em>' reference.
	 * @see #setIncomingtransition(IncomingTransition)
	 * @see UMS.UMSPackage#getInputActivity_Incomingtransition()
	 * @see UMS.IncomingTransition#getInputactivity
	 * @model opposite="inputactivity"
	 * @generated
	 */
	IncomingTransition getIncomingtransition();

	/**
	 * Sets the value of the '{@link UMS.InputActivity#getIncomingtransition <em>Incomingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Incomingtransition</em>' reference.
	 * @see #getIncomingtransition()
	 * @generated
	 */
	void setIncomingtransition(IncomingTransition value);

} // InputActivity
