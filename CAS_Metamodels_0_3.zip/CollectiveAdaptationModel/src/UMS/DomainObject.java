/**
 */
package UMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Domain Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.DomainObject#getName <em>Name</em>}</li>
 *   <li>{@link UMS.DomainObject#getCore_process <em>Core process</em>}</li>
 *   <li>{@link UMS.DomainObject#getFragment <em>Fragment</em>}</li>
 *   <li>{@link UMS.DomainObject#getInternaldomainknowledge <em>Internaldomainknowledge</em>}</li>
 *   <li>{@link UMS.DomainObject#getExternaldomainknowledge <em>Externaldomainknowledge</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getDomainObject()
 * @model
 * @generated
 */
public interface DomainObject extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see UMS.UMSPackage#getDomainObject_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link UMS.DomainObject#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Core process</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Core process</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Core process</em>' containment reference.
	 * @see #setCore_process(UMS.Process)
	 * @see UMS.UMSPackage#getDomainObject_Core_process()
	 * @model containment="true" required="true"
	 * @generated
	 */
	UMS.Process getCore_process();

	/**
	 * Sets the value of the '{@link UMS.DomainObject#getCore_process <em>Core process</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Core process</em>' containment reference.
	 * @see #getCore_process()
	 * @generated
	 */
	void setCore_process(UMS.Process value);

	/**
	 * Returns the value of the '<em><b>Fragment</b></em>' containment reference list.
	 * The list contents are of type {@link UMS.Process}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fragment</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fragment</em>' containment reference list.
	 * @see UMS.UMSPackage#getDomainObject_Fragment()
	 * @model containment="true"
	 * @generated
	 */
	EList<UMS.Process> getFragment();

	/**
	 * Returns the value of the '<em><b>Internaldomainknowledge</b></em>' containment reference list.
	 * The list contents are of type {@link UMS.DomainProperty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Internaldomainknowledge</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internaldomainknowledge</em>' containment reference list.
	 * @see UMS.UMSPackage#getDomainObject_Internaldomainknowledge()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<DomainProperty> getInternaldomainknowledge();

	/**
	 * Returns the value of the '<em><b>Externaldomainknowledge</b></em>' reference list.
	 * The list contents are of type {@link UMS.DomainProperty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Externaldomainknowledge</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Externaldomainknowledge</em>' reference list.
	 * @see UMS.UMSPackage#getDomainObject_Externaldomainknowledge()
	 * @model required="true"
	 * @generated
	 */
	EList<DomainProperty> getExternaldomainknowledge();

} // DomainObject
