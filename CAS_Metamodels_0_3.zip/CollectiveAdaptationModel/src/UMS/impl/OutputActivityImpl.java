/**
 */
package UMS.impl;

import UMS.OutgoingTransition;
import UMS.OutputActivity;
import UMS.UMSPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Activity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link UMS.impl.OutputActivityImpl#getOutgoingtransition <em>Outgoingtransition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputActivityImpl extends ActivityImpl implements OutputActivity {
	/**
	 * The cached value of the '{@link #getOutgoingtransition() <em>Outgoingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoingtransition()
	 * @generated
	 * @ordered
	 */
	protected OutgoingTransition outgoingtransition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputActivityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UMSPackage.Literals.OUTPUT_ACTIVITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingTransition getOutgoingtransition() {
		if (outgoingtransition != null && outgoingtransition.eIsProxy()) {
			InternalEObject oldOutgoingtransition = (InternalEObject)outgoingtransition;
			outgoingtransition = (OutgoingTransition)eResolveProxy(oldOutgoingtransition);
			if (outgoingtransition != oldOutgoingtransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION, oldOutgoingtransition, outgoingtransition));
			}
		}
		return outgoingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingTransition basicGetOutgoingtransition() {
		return outgoingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoingtransition(OutgoingTransition newOutgoingtransition, NotificationChain msgs) {
		OutgoingTransition oldOutgoingtransition = outgoingtransition;
		outgoingtransition = newOutgoingtransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION, oldOutgoingtransition, newOutgoingtransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoingtransition(OutgoingTransition newOutgoingtransition) {
		if (newOutgoingtransition != outgoingtransition) {
			NotificationChain msgs = null;
			if (outgoingtransition != null)
				msgs = ((InternalEObject)outgoingtransition).eInverseRemove(this, UMSPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY, OutgoingTransition.class, msgs);
			if (newOutgoingtransition != null)
				msgs = ((InternalEObject)newOutgoingtransition).eInverseAdd(this, UMSPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY, OutgoingTransition.class, msgs);
			msgs = basicSetOutgoingtransition(newOutgoingtransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION, newOutgoingtransition, newOutgoingtransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION:
				if (outgoingtransition != null)
					msgs = ((InternalEObject)outgoingtransition).eInverseRemove(this, UMSPackage.OUTGOING_TRANSITION__OUTPUTACTIVITY, OutgoingTransition.class, msgs);
				return basicSetOutgoingtransition((OutgoingTransition)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION:
				return basicSetOutgoingtransition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION:
				if (resolve) return getOutgoingtransition();
				return basicGetOutgoingtransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION:
				setOutgoingtransition((OutgoingTransition)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION:
				setOutgoingtransition((OutgoingTransition)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UMSPackage.OUTPUT_ACTIVITY__OUTGOINGTRANSITION:
				return outgoingtransition != null;
		}
		return super.eIsSet(featureID);
	}

} //OutputActivityImpl
