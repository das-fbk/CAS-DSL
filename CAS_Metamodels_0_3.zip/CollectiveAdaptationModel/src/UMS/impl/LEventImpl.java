/**
 */
package UMS.impl;

import UMS.IncomingLTransition;
import UMS.LEvent;
import UMS.OutgoingLTransition;
import UMS.UMSPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LEvent</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link UMS.impl.LEventImpl#getName <em>Name</em>}</li>
 *   <li>{@link UMS.impl.LEventImpl#getOutgoingltransition <em>Outgoingltransition</em>}</li>
 *   <li>{@link UMS.impl.LEventImpl#getIncomingltransition <em>Incomingltransition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LEventImpl extends MinimalEObjectImpl.Container implements LEvent {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOutgoingltransition() <em>Outgoingltransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoingltransition()
	 * @generated
	 * @ordered
	 */
	protected OutgoingLTransition outgoingltransition;

	/**
	 * The cached value of the '{@link #getIncomingltransition() <em>Incomingltransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncomingltransition()
	 * @generated
	 * @ordered
	 */
	protected IncomingLTransition incomingltransition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UMSPackage.Literals.LEVENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.LEVENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition getOutgoingltransition() {
		if (outgoingltransition != null && outgoingltransition.eIsProxy()) {
			InternalEObject oldOutgoingltransition = (InternalEObject)outgoingltransition;
			outgoingltransition = (OutgoingLTransition)eResolveProxy(oldOutgoingltransition);
			if (outgoingltransition != oldOutgoingltransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.LEVENT__OUTGOINGLTRANSITION, oldOutgoingltransition, outgoingltransition));
			}
		}
		return outgoingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition basicGetOutgoingltransition() {
		return outgoingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoingltransition(OutgoingLTransition newOutgoingltransition, NotificationChain msgs) {
		OutgoingLTransition oldOutgoingltransition = outgoingltransition;
		outgoingltransition = newOutgoingltransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.LEVENT__OUTGOINGLTRANSITION, oldOutgoingltransition, newOutgoingltransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoingltransition(OutgoingLTransition newOutgoingltransition) {
		if (newOutgoingltransition != outgoingltransition) {
			NotificationChain msgs = null;
			if (outgoingltransition != null)
				msgs = ((InternalEObject)outgoingltransition).eInverseRemove(this, UMSPackage.OUTGOING_LTRANSITION__LEVENT, OutgoingLTransition.class, msgs);
			if (newOutgoingltransition != null)
				msgs = ((InternalEObject)newOutgoingltransition).eInverseAdd(this, UMSPackage.OUTGOING_LTRANSITION__LEVENT, OutgoingLTransition.class, msgs);
			msgs = basicSetOutgoingltransition(newOutgoingltransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.LEVENT__OUTGOINGLTRANSITION, newOutgoingltransition, newOutgoingltransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingLTransition getIncomingltransition() {
		if (incomingltransition != null && incomingltransition.eIsProxy()) {
			InternalEObject oldIncomingltransition = (InternalEObject)incomingltransition;
			incomingltransition = (IncomingLTransition)eResolveProxy(oldIncomingltransition);
			if (incomingltransition != oldIncomingltransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.LEVENT__INCOMINGLTRANSITION, oldIncomingltransition, incomingltransition));
			}
		}
		return incomingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingLTransition basicGetIncomingltransition() {
		return incomingltransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIncomingltransition(IncomingLTransition newIncomingltransition, NotificationChain msgs) {
		IncomingLTransition oldIncomingltransition = incomingltransition;
		incomingltransition = newIncomingltransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.LEVENT__INCOMINGLTRANSITION, oldIncomingltransition, newIncomingltransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncomingltransition(IncomingLTransition newIncomingltransition) {
		if (newIncomingltransition != incomingltransition) {
			NotificationChain msgs = null;
			if (incomingltransition != null)
				msgs = ((InternalEObject)incomingltransition).eInverseRemove(this, UMSPackage.INCOMING_LTRANSITION__LEVENT, IncomingLTransition.class, msgs);
			if (newIncomingltransition != null)
				msgs = ((InternalEObject)newIncomingltransition).eInverseAdd(this, UMSPackage.INCOMING_LTRANSITION__LEVENT, IncomingLTransition.class, msgs);
			msgs = basicSetIncomingltransition(newIncomingltransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.LEVENT__INCOMINGLTRANSITION, newIncomingltransition, newIncomingltransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.LEVENT__OUTGOINGLTRANSITION:
				if (outgoingltransition != null)
					msgs = ((InternalEObject)outgoingltransition).eInverseRemove(this, UMSPackage.OUTGOING_LTRANSITION__LEVENT, OutgoingLTransition.class, msgs);
				return basicSetOutgoingltransition((OutgoingLTransition)otherEnd, msgs);
			case UMSPackage.LEVENT__INCOMINGLTRANSITION:
				if (incomingltransition != null)
					msgs = ((InternalEObject)incomingltransition).eInverseRemove(this, UMSPackage.INCOMING_LTRANSITION__LEVENT, IncomingLTransition.class, msgs);
				return basicSetIncomingltransition((IncomingLTransition)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.LEVENT__OUTGOINGLTRANSITION:
				return basicSetOutgoingltransition(null, msgs);
			case UMSPackage.LEVENT__INCOMINGLTRANSITION:
				return basicSetIncomingltransition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UMSPackage.LEVENT__NAME:
				return getName();
			case UMSPackage.LEVENT__OUTGOINGLTRANSITION:
				if (resolve) return getOutgoingltransition();
				return basicGetOutgoingltransition();
			case UMSPackage.LEVENT__INCOMINGLTRANSITION:
				if (resolve) return getIncomingltransition();
				return basicGetIncomingltransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UMSPackage.LEVENT__NAME:
				setName((String)newValue);
				return;
			case UMSPackage.LEVENT__OUTGOINGLTRANSITION:
				setOutgoingltransition((OutgoingLTransition)newValue);
				return;
			case UMSPackage.LEVENT__INCOMINGLTRANSITION:
				setIncomingltransition((IncomingLTransition)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UMSPackage.LEVENT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case UMSPackage.LEVENT__OUTGOINGLTRANSITION:
				setOutgoingltransition((OutgoingLTransition)null);
				return;
			case UMSPackage.LEVENT__INCOMINGLTRANSITION:
				setIncomingltransition((IncomingLTransition)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UMSPackage.LEVENT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case UMSPackage.LEVENT__OUTGOINGLTRANSITION:
				return outgoingltransition != null;
			case UMSPackage.LEVENT__INCOMINGLTRANSITION:
				return incomingltransition != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //LEventImpl
