/**
 */
package UMS.impl;

import UMS.ConcreteActivity;
import UMS.UMSPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Concrete Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ConcreteActivityImpl extends ActivityImpl implements ConcreteActivity {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConcreteActivityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UMSPackage.Literals.CONCRETE_ACTIVITY;
	}

} //ConcreteActivityImpl
