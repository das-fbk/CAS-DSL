/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.Adaptation;
import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.Event;
import collectiveAdaptationModel.EventHandler;
import collectiveAdaptationModel.IssueType;
import collectiveAdaptationModel.RoleActivity;

import collectiveAdaptationModel.Solver;
import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Handler</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.EventHandlerImpl#getEvent <em>Event</em>}</li>
 *   <li>{@link collectiveAdaptationModel.impl.EventHandlerImpl#getTriggeredAdaptations <em>Triggered Adaptations</em>}</li>
 *   <li>{@link collectiveAdaptationModel.impl.EventHandlerImpl#getScope <em>Scope</em>}</li>
 *   <li>{@link collectiveAdaptationModel.impl.EventHandlerImpl#getIssuetype <em>Issuetype</em>}</li>
 *   <li>{@link collectiveAdaptationModel.impl.EventHandlerImpl#getSolver <em>Solver</em>}</li>
 *   <li>{@link collectiveAdaptationModel.impl.EventHandlerImpl#getRoleactivity <em>Roleactivity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EventHandlerImpl extends NamedElementImpl implements EventHandler {
	/**
	 * The cached value of the '{@link #getEvent() <em>Event</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEvent()
	 * @generated
	 * @ordered
	 */
	protected EList<Event> event;

	/**
	 * The cached value of the '{@link #getTriggeredAdaptations() <em>Triggered Adaptations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTriggeredAdaptations()
	 * @generated
	 * @ordered
	 */
	protected EList<Adaptation> triggeredAdaptations;

	/**
	 * The cached value of the '{@link #getScope() <em>Scope</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScope()
	 * @generated
	 * @ordered
	 */
	protected EList<RoleActivity> scope;

	/**
	 * The cached value of the '{@link #getIssuetype() <em>Issuetype</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIssuetype()
	 * @generated
	 * @ordered
	 */
	protected EList<IssueType> issuetype;

	/**
	 * The cached value of the '{@link #getSolver() <em>Solver</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSolver()
	 * @generated
	 * @ordered
	 */
	protected EList<Solver> solver;

	/**
	 * The cached value of the '{@link #getRoleactivity() <em>Roleactivity</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleactivity()
	 * @generated
	 * @ordered
	 */
	protected EList<RoleActivity> roleactivity;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventHandlerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.EVENT_HANDLER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Event> getEvent() {
		if (event == null) {
			event = new EObjectContainmentEList<Event>(Event.class, this, CollectiveAdaptationModelPackage.EVENT_HANDLER__EVENT);
		}
		return event;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Adaptation> getTriggeredAdaptations() {
		if (triggeredAdaptations == null) {
			triggeredAdaptations = new EObjectContainmentEList<Adaptation>(Adaptation.class, this, CollectiveAdaptationModelPackage.EVENT_HANDLER__TRIGGERED_ADAPTATIONS);
		}
		return triggeredAdaptations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RoleActivity> getScope() {
		if (scope == null) {
			scope = new EObjectResolvingEList<RoleActivity>(RoleActivity.class, this, CollectiveAdaptationModelPackage.EVENT_HANDLER__SCOPE);
		}
		return scope;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IssueType> getIssuetype() {
		if (issuetype == null) {
			issuetype = new EObjectContainmentEList<IssueType>(IssueType.class, this, CollectiveAdaptationModelPackage.EVENT_HANDLER__ISSUETYPE);
		}
		return issuetype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Solver> getSolver() {
		if (solver == null) {
			solver = new EObjectContainmentEList<Solver>(Solver.class, this, CollectiveAdaptationModelPackage.EVENT_HANDLER__SOLVER);
		}
		return solver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RoleActivity> getRoleactivity() {
		if (roleactivity == null) {
			roleactivity = new EObjectContainmentEList<RoleActivity>(RoleActivity.class, this, CollectiveAdaptationModelPackage.EVENT_HANDLER__ROLEACTIVITY);
		}
		return roleactivity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__EVENT:
				return ((InternalEList<?>)getEvent()).basicRemove(otherEnd, msgs);
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__TRIGGERED_ADAPTATIONS:
				return ((InternalEList<?>)getTriggeredAdaptations()).basicRemove(otherEnd, msgs);
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ISSUETYPE:
				return ((InternalEList<?>)getIssuetype()).basicRemove(otherEnd, msgs);
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SOLVER:
				return ((InternalEList<?>)getSolver()).basicRemove(otherEnd, msgs);
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ROLEACTIVITY:
				return ((InternalEList<?>)getRoleactivity()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__EVENT:
				return getEvent();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__TRIGGERED_ADAPTATIONS:
				return getTriggeredAdaptations();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SCOPE:
				return getScope();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ISSUETYPE:
				return getIssuetype();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SOLVER:
				return getSolver();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ROLEACTIVITY:
				return getRoleactivity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__EVENT:
				getEvent().clear();
				getEvent().addAll((Collection<? extends Event>)newValue);
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__TRIGGERED_ADAPTATIONS:
				getTriggeredAdaptations().clear();
				getTriggeredAdaptations().addAll((Collection<? extends Adaptation>)newValue);
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SCOPE:
				getScope().clear();
				getScope().addAll((Collection<? extends RoleActivity>)newValue);
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ISSUETYPE:
				getIssuetype().clear();
				getIssuetype().addAll((Collection<? extends IssueType>)newValue);
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SOLVER:
				getSolver().clear();
				getSolver().addAll((Collection<? extends Solver>)newValue);
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ROLEACTIVITY:
				getRoleactivity().clear();
				getRoleactivity().addAll((Collection<? extends RoleActivity>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__EVENT:
				getEvent().clear();
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__TRIGGERED_ADAPTATIONS:
				getTriggeredAdaptations().clear();
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SCOPE:
				getScope().clear();
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ISSUETYPE:
				getIssuetype().clear();
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SOLVER:
				getSolver().clear();
				return;
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ROLEACTIVITY:
				getRoleactivity().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__EVENT:
				return event != null && !event.isEmpty();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__TRIGGERED_ADAPTATIONS:
				return triggeredAdaptations != null && !triggeredAdaptations.isEmpty();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SCOPE:
				return scope != null && !scope.isEmpty();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ISSUETYPE:
				return issuetype != null && !issuetype.isEmpty();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__SOLVER:
				return solver != null && !solver.isEmpty();
			case CollectiveAdaptationModelPackage.EVENT_HANDLER__ROLEACTIVITY:
				return roleactivity != null && !roleactivity.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EventHandlerImpl
