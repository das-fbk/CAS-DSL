/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.IssueType;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Issue Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.IssueTypeImpl#getIssueSpecification <em>Issue Specification</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IssueTypeImpl extends MinimalEObjectImpl.Container implements IssueType {
	/**
	 * The cached value of the '{@link #getIssueSpecification() <em>Issue Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIssueSpecification()
	 * @generated
	 * @ordered
	 */
	protected ensembleModel.IssueType issueSpecification;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IssueTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.ISSUE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ensembleModel.IssueType getIssueSpecification() {
		if (issueSpecification != null && issueSpecification.eIsProxy()) {
			InternalEObject oldIssueSpecification = (InternalEObject)issueSpecification;
			issueSpecification = (ensembleModel.IssueType)eResolveProxy(oldIssueSpecification);
			if (issueSpecification != oldIssueSpecification) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollectiveAdaptationModelPackage.ISSUE_TYPE__ISSUE_SPECIFICATION, oldIssueSpecification, issueSpecification));
			}
		}
		return issueSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ensembleModel.IssueType basicGetIssueSpecification() {
		return issueSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIssueSpecification(ensembleModel.IssueType newIssueSpecification) {
		ensembleModel.IssueType oldIssueSpecification = issueSpecification;
		issueSpecification = newIssueSpecification;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollectiveAdaptationModelPackage.ISSUE_TYPE__ISSUE_SPECIFICATION, oldIssueSpecification, issueSpecification));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ISSUE_TYPE__ISSUE_SPECIFICATION:
				if (resolve) return getIssueSpecification();
				return basicGetIssueSpecification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ISSUE_TYPE__ISSUE_SPECIFICATION:
				setIssueSpecification((ensembleModel.IssueType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ISSUE_TYPE__ISSUE_SPECIFICATION:
				setIssueSpecification((ensembleModel.IssueType)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ISSUE_TYPE__ISSUE_SPECIFICATION:
				return issueSpecification != null;
		}
		return super.eIsSet(featureID);
	}

} //IssueTypeImpl
