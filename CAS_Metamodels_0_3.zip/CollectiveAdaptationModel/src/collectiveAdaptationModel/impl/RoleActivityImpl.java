/**
 */
package collectiveAdaptationModel.impl;

import AdaptiveSystemMM.Activity;
import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.RoleActivity;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Activity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.RoleActivityImpl#getActivitySpecification <em>Activity Specification</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoleActivityImpl extends MinimalEObjectImpl.Container implements RoleActivity {
	/**
	 * The cached value of the '{@link #getActivitySpecification() <em>Activity Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivitySpecification()
	 * @generated
	 * @ordered
	 */
	protected Activity activitySpecification;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleActivityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.ROLE_ACTIVITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Activity getActivitySpecification() {
		if (activitySpecification != null && activitySpecification.eIsProxy()) {
			InternalEObject oldActivitySpecification = (InternalEObject)activitySpecification;
			activitySpecification = (Activity)eResolveProxy(oldActivitySpecification);
			if (activitySpecification != oldActivitySpecification) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollectiveAdaptationModelPackage.ROLE_ACTIVITY__ACTIVITY_SPECIFICATION, oldActivitySpecification, activitySpecification));
			}
		}
		return activitySpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Activity basicGetActivitySpecification() {
		return activitySpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActivitySpecification(Activity newActivitySpecification) {
		Activity oldActivitySpecification = activitySpecification;
		activitySpecification = newActivitySpecification;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollectiveAdaptationModelPackage.ROLE_ACTIVITY__ACTIVITY_SPECIFICATION, oldActivitySpecification, activitySpecification));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ROLE_ACTIVITY__ACTIVITY_SPECIFICATION:
				if (resolve) return getActivitySpecification();
				return basicGetActivitySpecification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ROLE_ACTIVITY__ACTIVITY_SPECIFICATION:
				setActivitySpecification((Activity)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ROLE_ACTIVITY__ACTIVITY_SPECIFICATION:
				setActivitySpecification((Activity)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ROLE_ACTIVITY__ACTIVITY_SPECIFICATION:
				return activitySpecification != null;
		}
		return super.eIsSet(featureID);
	}

} //RoleActivityImpl
