/**
 */
package collectiveAdaptationModel;

import AdaptiveSystemMM.Activity;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.RoleActivity#getActivitySpecification <em>Activity Specification</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getRoleActivity()
 * @model
 * @generated
 */
public interface RoleActivity extends EObject {

	/**
	 * Returns the value of the '<em><b>Activity Specification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activity Specification</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activity Specification</em>' reference.
	 * @see #setActivitySpecification(Activity)
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getRoleActivity_ActivitySpecification()
	 * @model required="true"
	 * @generated
	 */
	Activity getActivitySpecification();

	/**
	 * Sets the value of the '{@link collectiveAdaptationModel.RoleActivity#getActivitySpecification <em>Activity Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activity Specification</em>' reference.
	 * @see #getActivitySpecification()
	 * @generated
	 */
	void setActivitySpecification(Activity value);
} // RoleActivity
