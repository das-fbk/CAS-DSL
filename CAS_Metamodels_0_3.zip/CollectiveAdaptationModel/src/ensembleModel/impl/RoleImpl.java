/**
 */
package ensembleModel.impl;

import ensembleModel.DomainObject;
import ensembleModel.EnsembleModelPackage;
import ensembleModel.IssueType;
import ensembleModel.Preference;
import ensembleModel.Role;
import ensembleModel.RoleParameter;
import ensembleModel.Solver;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.impl.RoleImpl#getDORoleName <em>DO Role Name</em>}</li>
 *   <li>{@link ensembleModel.impl.RoleImpl#getTriggeredIssues <em>Triggered Issues</em>}</li>
 *   <li>{@link ensembleModel.impl.RoleImpl#getRoleSolvers <em>Role Solvers</em>}</li>
 *   <li>{@link ensembleModel.impl.RoleImpl#getRoleParameters <em>Role Parameters</em>}</li>
 *   <li>{@link ensembleModel.impl.RoleImpl#getPreferences <em>Preferences</em>}</li>
 *   <li>{@link ensembleModel.impl.RoleImpl#getDomainobject <em>Domainobject</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoleImpl extends MinimalEObjectImpl.Container implements Role {
	/**
	 * The default value of the '{@link #getDORoleName() <em>DO Role Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDORoleName()
	 * @generated
	 * @ordered
	 */
	protected static final String DO_ROLE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDORoleName() <em>DO Role Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDORoleName()
	 * @generated
	 * @ordered
	 */
	protected String doRoleName = DO_ROLE_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTriggeredIssues() <em>Triggered Issues</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTriggeredIssues()
	 * @generated
	 * @ordered
	 */
	protected EList<IssueType> triggeredIssues;

	/**
	 * The cached value of the '{@link #getRoleSolvers() <em>Role Solvers</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleSolvers()
	 * @generated
	 * @ordered
	 */
	protected EList<Solver> roleSolvers;

	/**
	 * The cached value of the '{@link #getRoleParameters() <em>Role Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<RoleParameter> roleParameters;

	/**
	 * The cached value of the '{@link #getPreferences() <em>Preferences</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreferences()
	 * @generated
	 * @ordered
	 */
	protected EList<Preference> preferences;

	/**
	 * The cached value of the '{@link #getDomainobject() <em>Domainobject</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomainobject()
	 * @generated
	 * @ordered
	 */
	protected DomainObject domainobject;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.ROLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDORoleName() {
		return doRoleName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDORoleName(String newDORoleName) {
		String oldDORoleName = doRoleName;
		doRoleName = newDORoleName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.ROLE__DO_ROLE_NAME, oldDORoleName, doRoleName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IssueType> getTriggeredIssues() {
		if (triggeredIssues == null) {
			triggeredIssues = new EObjectResolvingEList<IssueType>(IssueType.class, this, EnsembleModelPackage.ROLE__TRIGGERED_ISSUES);
		}
		return triggeredIssues;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Solver> getRoleSolvers() {
		if (roleSolvers == null) {
			roleSolvers = new EObjectContainmentEList<Solver>(Solver.class, this, EnsembleModelPackage.ROLE__ROLE_SOLVERS);
		}
		return roleSolvers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RoleParameter> getRoleParameters() {
		if (roleParameters == null) {
			roleParameters = new EObjectContainmentEList<RoleParameter>(RoleParameter.class, this, EnsembleModelPackage.ROLE__ROLE_PARAMETERS);
		}
		return roleParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Preference> getPreferences() {
		if (preferences == null) {
			preferences = new EObjectContainmentEList<Preference>(Preference.class, this, EnsembleModelPackage.ROLE__PREFERENCES);
		}
		return preferences;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainObject getDomainobject() {
		if (domainobject != null && domainobject.eIsProxy()) {
			InternalEObject oldDomainobject = (InternalEObject)domainobject;
			domainobject = (DomainObject)eResolveProxy(oldDomainobject);
			if (domainobject != oldDomainobject) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, EnsembleModelPackage.ROLE__DOMAINOBJECT, oldDomainobject, domainobject));
			}
		}
		return domainobject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DomainObject basicGetDomainobject() {
		return domainobject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDomainobject(DomainObject newDomainobject, NotificationChain msgs) {
		DomainObject oldDomainobject = domainobject;
		domainobject = newDomainobject;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.ROLE__DOMAINOBJECT, oldDomainobject, newDomainobject);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDomainobject(DomainObject newDomainobject) {
		if (newDomainobject != domainobject) {
			NotificationChain msgs = null;
			if (domainobject != null)
				msgs = ((InternalEObject)domainobject).eInverseRemove(this, EnsembleModelPackage.DOMAIN_OBJECT__ROLES, DomainObject.class, msgs);
			if (newDomainobject != null)
				msgs = ((InternalEObject)newDomainobject).eInverseAdd(this, EnsembleModelPackage.DOMAIN_OBJECT__ROLES, DomainObject.class, msgs);
			msgs = basicSetDomainobject(newDomainobject, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.ROLE__DOMAINOBJECT, newDomainobject, newDomainobject));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case EnsembleModelPackage.ROLE__DOMAINOBJECT:
				if (domainobject != null)
					msgs = ((InternalEObject)domainobject).eInverseRemove(this, EnsembleModelPackage.DOMAIN_OBJECT__ROLES, DomainObject.class, msgs);
				return basicSetDomainobject((DomainObject)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case EnsembleModelPackage.ROLE__ROLE_SOLVERS:
				return ((InternalEList<?>)getRoleSolvers()).basicRemove(otherEnd, msgs);
			case EnsembleModelPackage.ROLE__ROLE_PARAMETERS:
				return ((InternalEList<?>)getRoleParameters()).basicRemove(otherEnd, msgs);
			case EnsembleModelPackage.ROLE__PREFERENCES:
				return ((InternalEList<?>)getPreferences()).basicRemove(otherEnd, msgs);
			case EnsembleModelPackage.ROLE__DOMAINOBJECT:
				return basicSetDomainobject(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case EnsembleModelPackage.ROLE__DO_ROLE_NAME:
				return getDORoleName();
			case EnsembleModelPackage.ROLE__TRIGGERED_ISSUES:
				return getTriggeredIssues();
			case EnsembleModelPackage.ROLE__ROLE_SOLVERS:
				return getRoleSolvers();
			case EnsembleModelPackage.ROLE__ROLE_PARAMETERS:
				return getRoleParameters();
			case EnsembleModelPackage.ROLE__PREFERENCES:
				return getPreferences();
			case EnsembleModelPackage.ROLE__DOMAINOBJECT:
				if (resolve) return getDomainobject();
				return basicGetDomainobject();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case EnsembleModelPackage.ROLE__DO_ROLE_NAME:
				setDORoleName((String)newValue);
				return;
			case EnsembleModelPackage.ROLE__TRIGGERED_ISSUES:
				getTriggeredIssues().clear();
				getTriggeredIssues().addAll((Collection<? extends IssueType>)newValue);
				return;
			case EnsembleModelPackage.ROLE__ROLE_SOLVERS:
				getRoleSolvers().clear();
				getRoleSolvers().addAll((Collection<? extends Solver>)newValue);
				return;
			case EnsembleModelPackage.ROLE__ROLE_PARAMETERS:
				getRoleParameters().clear();
				getRoleParameters().addAll((Collection<? extends RoleParameter>)newValue);
				return;
			case EnsembleModelPackage.ROLE__PREFERENCES:
				getPreferences().clear();
				getPreferences().addAll((Collection<? extends Preference>)newValue);
				return;
			case EnsembleModelPackage.ROLE__DOMAINOBJECT:
				setDomainobject((DomainObject)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.ROLE__DO_ROLE_NAME:
				setDORoleName(DO_ROLE_NAME_EDEFAULT);
				return;
			case EnsembleModelPackage.ROLE__TRIGGERED_ISSUES:
				getTriggeredIssues().clear();
				return;
			case EnsembleModelPackage.ROLE__ROLE_SOLVERS:
				getRoleSolvers().clear();
				return;
			case EnsembleModelPackage.ROLE__ROLE_PARAMETERS:
				getRoleParameters().clear();
				return;
			case EnsembleModelPackage.ROLE__PREFERENCES:
				getPreferences().clear();
				return;
			case EnsembleModelPackage.ROLE__DOMAINOBJECT:
				setDomainobject((DomainObject)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.ROLE__DO_ROLE_NAME:
				return DO_ROLE_NAME_EDEFAULT == null ? doRoleName != null : !DO_ROLE_NAME_EDEFAULT.equals(doRoleName);
			case EnsembleModelPackage.ROLE__TRIGGERED_ISSUES:
				return triggeredIssues != null && !triggeredIssues.isEmpty();
			case EnsembleModelPackage.ROLE__ROLE_SOLVERS:
				return roleSolvers != null && !roleSolvers.isEmpty();
			case EnsembleModelPackage.ROLE__ROLE_PARAMETERS:
				return roleParameters != null && !roleParameters.isEmpty();
			case EnsembleModelPackage.ROLE__PREFERENCES:
				return preferences != null && !preferences.isEmpty();
			case EnsembleModelPackage.ROLE__DOMAINOBJECT:
				return domainobject != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (DORoleName: ");
		result.append(doRoleName);
		result.append(')');
		return result.toString();
	}

} //RoleImpl
