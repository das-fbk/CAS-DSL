/**
 */
package ensembleModel.impl;

import ensembleModel.EnsembleModelPackage;
import ensembleModel.IssueType;
import ensembleModel.Solver;
import ensembleModel.SolverParameter;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Solver</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.impl.SolverImpl#getName <em>Name</em>}</li>
 *   <li>{@link ensembleModel.impl.SolverImpl#isActive <em>Active</em>}</li>
 *   <li>{@link ensembleModel.impl.SolverImpl#getSolverParameters <em>Solver Parameters</em>}</li>
 *   <li>{@link ensembleModel.impl.SolverImpl#getCompatibleIssueTypes <em>Compatible Issue Types</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SolverImpl extends MinimalEObjectImpl.Container implements Solver {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #isActive() <em>Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isActive()
	 * @generated
	 * @ordered
	 */
	protected static final boolean ACTIVE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isActive() <em>Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isActive()
	 * @generated
	 * @ordered
	 */
	protected boolean active = ACTIVE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSolverParameters() <em>Solver Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSolverParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<SolverParameter> solverParameters;

	/**
	 * The cached value of the '{@link #getCompatibleIssueTypes() <em>Compatible Issue Types</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompatibleIssueTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<IssueType> compatibleIssueTypes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SolverImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.SOLVER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.SOLVER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActive(boolean newActive) {
		boolean oldActive = active;
		active = newActive;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.SOLVER__ACTIVE, oldActive, active));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SolverParameter> getSolverParameters() {
		if (solverParameters == null) {
			solverParameters = new EObjectContainmentEList<SolverParameter>(SolverParameter.class, this, EnsembleModelPackage.SOLVER__SOLVER_PARAMETERS);
		}
		return solverParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IssueType> getCompatibleIssueTypes() {
		if (compatibleIssueTypes == null) {
			compatibleIssueTypes = new EObjectResolvingEList<IssueType>(IssueType.class, this, EnsembleModelPackage.SOLVER__COMPATIBLE_ISSUE_TYPES);
		}
		return compatibleIssueTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case EnsembleModelPackage.SOLVER__SOLVER_PARAMETERS:
				return ((InternalEList<?>)getSolverParameters()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case EnsembleModelPackage.SOLVER__NAME:
				return getName();
			case EnsembleModelPackage.SOLVER__ACTIVE:
				return isActive();
			case EnsembleModelPackage.SOLVER__SOLVER_PARAMETERS:
				return getSolverParameters();
			case EnsembleModelPackage.SOLVER__COMPATIBLE_ISSUE_TYPES:
				return getCompatibleIssueTypes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case EnsembleModelPackage.SOLVER__NAME:
				setName((String)newValue);
				return;
			case EnsembleModelPackage.SOLVER__ACTIVE:
				setActive((Boolean)newValue);
				return;
			case EnsembleModelPackage.SOLVER__SOLVER_PARAMETERS:
				getSolverParameters().clear();
				getSolverParameters().addAll((Collection<? extends SolverParameter>)newValue);
				return;
			case EnsembleModelPackage.SOLVER__COMPATIBLE_ISSUE_TYPES:
				getCompatibleIssueTypes().clear();
				getCompatibleIssueTypes().addAll((Collection<? extends IssueType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.SOLVER__NAME:
				setName(NAME_EDEFAULT);
				return;
			case EnsembleModelPackage.SOLVER__ACTIVE:
				setActive(ACTIVE_EDEFAULT);
				return;
			case EnsembleModelPackage.SOLVER__SOLVER_PARAMETERS:
				getSolverParameters().clear();
				return;
			case EnsembleModelPackage.SOLVER__COMPATIBLE_ISSUE_TYPES:
				getCompatibleIssueTypes().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.SOLVER__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case EnsembleModelPackage.SOLVER__ACTIVE:
				return active != ACTIVE_EDEFAULT;
			case EnsembleModelPackage.SOLVER__SOLVER_PARAMETERS:
				return solverParameters != null && !solverParameters.isEmpty();
			case EnsembleModelPackage.SOLVER__COMPATIBLE_ISSUE_TYPES:
				return compatibleIssueTypes != null && !compatibleIssueTypes.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", active: ");
		result.append(active);
		result.append(')');
		return result.toString();
	}

} //SolverImpl
