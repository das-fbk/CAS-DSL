/**
 */
package ensembleModel.impl;

import ensembleModel.DomainObject;
import ensembleModel.EnsembleModelPackage;
import ensembleModel.Role;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Domain Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ensembleModel.impl.DomainObjectImpl#getRoles <em>Roles</em>}</li>
 *   <li>{@link ensembleModel.impl.DomainObjectImpl#getDomainObjectSpecification <em>Domain Object Specification</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DomainObjectImpl extends MinimalEObjectImpl.Container implements DomainObject {
	/**
	 * The cached value of the '{@link #getRoles() <em>Roles</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoles()
	 * @generated
	 * @ordered
	 */
	protected EList<Role> roles;

	/**
	 * The cached value of the '{@link #getDomainObjectSpecification() <em>Domain Object Specification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomainObjectSpecification()
	 * @generated
	 * @ordered
	 */
	protected UMS.DomainObject domainObjectSpecification;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DomainObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.DOMAIN_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Role> getRoles() {
		if (roles == null) {
			roles = new EObjectWithInverseResolvingEList<Role>(Role.class, this, EnsembleModelPackage.DOMAIN_OBJECT__ROLES, EnsembleModelPackage.ROLE__DOMAINOBJECT);
		}
		return roles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UMS.DomainObject getDomainObjectSpecification() {
		if (domainObjectSpecification != null && domainObjectSpecification.eIsProxy()) {
			InternalEObject oldDomainObjectSpecification = (InternalEObject)domainObjectSpecification;
			domainObjectSpecification = (UMS.DomainObject)eResolveProxy(oldDomainObjectSpecification);
			if (domainObjectSpecification != oldDomainObjectSpecification) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, EnsembleModelPackage.DOMAIN_OBJECT__DOMAIN_OBJECT_SPECIFICATION, oldDomainObjectSpecification, domainObjectSpecification));
			}
		}
		return domainObjectSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UMS.DomainObject basicGetDomainObjectSpecification() {
		return domainObjectSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDomainObjectSpecification(UMS.DomainObject newDomainObjectSpecification) {
		UMS.DomainObject oldDomainObjectSpecification = domainObjectSpecification;
		domainObjectSpecification = newDomainObjectSpecification;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EnsembleModelPackage.DOMAIN_OBJECT__DOMAIN_OBJECT_SPECIFICATION, oldDomainObjectSpecification, domainObjectSpecification));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case EnsembleModelPackage.DOMAIN_OBJECT__ROLES:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getRoles()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case EnsembleModelPackage.DOMAIN_OBJECT__ROLES:
				return ((InternalEList<?>)getRoles()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case EnsembleModelPackage.DOMAIN_OBJECT__ROLES:
				return getRoles();
			case EnsembleModelPackage.DOMAIN_OBJECT__DOMAIN_OBJECT_SPECIFICATION:
				if (resolve) return getDomainObjectSpecification();
				return basicGetDomainObjectSpecification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case EnsembleModelPackage.DOMAIN_OBJECT__ROLES:
				getRoles().clear();
				getRoles().addAll((Collection<? extends Role>)newValue);
				return;
			case EnsembleModelPackage.DOMAIN_OBJECT__DOMAIN_OBJECT_SPECIFICATION:
				setDomainObjectSpecification((UMS.DomainObject)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.DOMAIN_OBJECT__ROLES:
				getRoles().clear();
				return;
			case EnsembleModelPackage.DOMAIN_OBJECT__DOMAIN_OBJECT_SPECIFICATION:
				setDomainObjectSpecification((UMS.DomainObject)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case EnsembleModelPackage.DOMAIN_OBJECT__ROLES:
				return roles != null && !roles.isEmpty();
			case EnsembleModelPackage.DOMAIN_OBJECT__DOMAIN_OBJECT_SPECIFICATION:
				return domainObjectSpecification != null;
		}
		return super.eIsSet(featureID);
	}

} //DomainObjectImpl
