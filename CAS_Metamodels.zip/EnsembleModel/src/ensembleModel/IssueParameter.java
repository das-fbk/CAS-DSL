/**
 */
package ensembleModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Issue Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ensembleModel.EnsembleModelPackage#getIssueParameter()
 * @model
 * @generated
 */
public interface IssueParameter extends NamedValue {
} // IssueParameter
