/**
 */
package ensembleModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Preference</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ensembleModel.EnsembleModelPackage#getPreference()
 * @model
 * @generated
 */
public interface Preference extends NamedValue {
} // Preference
