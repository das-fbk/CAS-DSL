/**
 */
package ensembleModel.impl;

import ensembleModel.EnsembleModelPackage;
import ensembleModel.RoleParameter;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RoleParameterImpl extends NamedValueImpl implements RoleParameter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleParameterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EnsembleModelPackage.Literals.ROLE_PARAMETER;
	}

} //RoleParameterImpl
