/**
 */
package ensembleModel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see ensembleModel.EnsembleModelFactory
 * @model kind="package"
 * @generated
 */
public interface EnsembleModelPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "ensembleModel";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/ensembleModel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "ensembleModel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	EnsembleModelPackage eINSTANCE = ensembleModel.impl.EnsembleModelPackageImpl.init();

	/**
	 * The meta object id for the '{@link ensembleModel.impl.EnsembleImpl <em>Ensemble</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.EnsembleImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getEnsemble()
	 * @generated
	 */
	int ENSEMBLE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENSEMBLE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Roles</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENSEMBLE__ROLES = 1;

	/**
	 * The feature id for the '<em><b>Issuetypes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENSEMBLE__ISSUETYPES = 2;

	/**
	 * The number of structural features of the '<em>Ensemble</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENSEMBLE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Ensemble</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENSEMBLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.RoleImpl <em>Role</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.RoleImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getRole()
	 * @generated
	 */
	int ROLE = 1;

	/**
	 * The feature id for the '<em><b>DO Role Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__DO_ROLE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Triggered Issues</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__TRIGGERED_ISSUES = 1;

	/**
	 * The feature id for the '<em><b>Role Solvers</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ROLE_SOLVERS = 2;

	/**
	 * The feature id for the '<em><b>Role Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ROLE_PARAMETERS = 3;

	/**
	 * The feature id for the '<em><b>Preferences</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__PREFERENCES = 4;

	/**
	 * The feature id for the '<em><b>Domainobject</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__DOMAINOBJECT = 5;

	/**
	 * The number of structural features of the '<em>Role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.IssueTypeImpl <em>Issue Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.IssueTypeImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getIssueType()
	 * @generated
	 */
	int ISSUE_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Issue Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE__ISSUE_PARAMETERS = 1;

	/**
	 * The feature id for the '<em><b>Solvers</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE__SOLVERS = 2;

	/**
	 * The number of structural features of the '<em>Issue Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Issue Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.SolverImpl <em>Solver</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.SolverImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getSolver()
	 * @generated
	 */
	int SOLVER = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Active</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER__ACTIVE = 1;

	/**
	 * The feature id for the '<em><b>Solver Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER__SOLVER_PARAMETERS = 2;

	/**
	 * The feature id for the '<em><b>Compatible Issue Types</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER__COMPATIBLE_ISSUE_TYPES = 3;

	/**
	 * The number of structural features of the '<em>Solver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Solver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.NamedValueImpl <em>Named Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.NamedValueImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getNamedValue()
	 * @generated
	 */
	int NAMED_VALUE = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_VALUE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_VALUE__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Named Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_VALUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Named Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.RoleParameterImpl <em>Role Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.RoleParameterImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getRoleParameter()
	 * @generated
	 */
	int ROLE_PARAMETER = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_PARAMETER__NAME = NAMED_VALUE__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_PARAMETER__VALUE = NAMED_VALUE__VALUE;

	/**
	 * The number of structural features of the '<em>Role Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_PARAMETER_FEATURE_COUNT = NAMED_VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Role Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_PARAMETER_OPERATION_COUNT = NAMED_VALUE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.PreferenceImpl <em>Preference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.PreferenceImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getPreference()
	 * @generated
	 */
	int PREFERENCE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREFERENCE__NAME = NAMED_VALUE__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREFERENCE__VALUE = NAMED_VALUE__VALUE;

	/**
	 * The number of structural features of the '<em>Preference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREFERENCE_FEATURE_COUNT = NAMED_VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Preference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREFERENCE_OPERATION_COUNT = NAMED_VALUE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.IssueParameterImpl <em>Issue Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.IssueParameterImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getIssueParameter()
	 * @generated
	 */
	int ISSUE_PARAMETER = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_PARAMETER__NAME = NAMED_VALUE__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_PARAMETER__VALUE = NAMED_VALUE__VALUE;

	/**
	 * The number of structural features of the '<em>Issue Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_PARAMETER_FEATURE_COUNT = NAMED_VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Issue Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_PARAMETER_OPERATION_COUNT = NAMED_VALUE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.SolverParameterImpl <em>Solver Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.SolverParameterImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getSolverParameter()
	 * @generated
	 */
	int SOLVER_PARAMETER = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_PARAMETER__NAME = NAMED_VALUE__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_PARAMETER__VALUE = NAMED_VALUE__VALUE;

	/**
	 * The number of structural features of the '<em>Solver Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_PARAMETER_FEATURE_COUNT = NAMED_VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Solver Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_PARAMETER_OPERATION_COUNT = NAMED_VALUE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ensembleModel.impl.DomainObjectImpl <em>Domain Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ensembleModel.impl.DomainObjectImpl
	 * @see ensembleModel.impl.EnsembleModelPackageImpl#getDomainObject()
	 * @generated
	 */
	int DOMAIN_OBJECT = 9;

	/**
	 * The feature id for the '<em><b>Roles</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__ROLES = 0;

	/**
	 * The number of structural features of the '<em>Domain Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Domain Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link ensembleModel.Ensemble <em>Ensemble</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ensemble</em>'.
	 * @see ensembleModel.Ensemble
	 * @generated
	 */
	EClass getEnsemble();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.Ensemble#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ensembleModel.Ensemble#getName()
	 * @see #getEnsemble()
	 * @generated
	 */
	EAttribute getEnsemble_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.Ensemble#getRoles <em>Roles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Roles</em>'.
	 * @see ensembleModel.Ensemble#getRoles()
	 * @see #getEnsemble()
	 * @generated
	 */
	EReference getEnsemble_Roles();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.Ensemble#getIssuetypes <em>Issuetypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Issuetypes</em>'.
	 * @see ensembleModel.Ensemble#getIssuetypes()
	 * @see #getEnsemble()
	 * @generated
	 */
	EReference getEnsemble_Issuetypes();

	/**
	 * Returns the meta object for class '{@link ensembleModel.Role <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role</em>'.
	 * @see ensembleModel.Role
	 * @generated
	 */
	EClass getRole();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.Role#getDORoleName <em>DO Role Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>DO Role Name</em>'.
	 * @see ensembleModel.Role#getDORoleName()
	 * @see #getRole()
	 * @generated
	 */
	EAttribute getRole_DORoleName();

	/**
	 * Returns the meta object for the reference list '{@link ensembleModel.Role#getTriggeredIssues <em>Triggered Issues</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Triggered Issues</em>'.
	 * @see ensembleModel.Role#getTriggeredIssues()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_TriggeredIssues();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.Role#getRoleSolvers <em>Role Solvers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role Solvers</em>'.
	 * @see ensembleModel.Role#getRoleSolvers()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_RoleSolvers();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.Role#getRoleParameters <em>Role Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role Parameters</em>'.
	 * @see ensembleModel.Role#getRoleParameters()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_RoleParameters();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.Role#getPreferences <em>Preferences</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Preferences</em>'.
	 * @see ensembleModel.Role#getPreferences()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_Preferences();

	/**
	 * Returns the meta object for the reference '{@link ensembleModel.Role#getDomainobject <em>Domainobject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Domainobject</em>'.
	 * @see ensembleModel.Role#getDomainobject()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_Domainobject();

	/**
	 * Returns the meta object for class '{@link ensembleModel.IssueType <em>Issue Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Issue Type</em>'.
	 * @see ensembleModel.IssueType
	 * @generated
	 */
	EClass getIssueType();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.IssueType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ensembleModel.IssueType#getName()
	 * @see #getIssueType()
	 * @generated
	 */
	EAttribute getIssueType_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.IssueType#getIssueParameters <em>Issue Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Issue Parameters</em>'.
	 * @see ensembleModel.IssueType#getIssueParameters()
	 * @see #getIssueType()
	 * @generated
	 */
	EReference getIssueType_IssueParameters();

	/**
	 * Returns the meta object for the reference list '{@link ensembleModel.IssueType#getSolvers <em>Solvers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Solvers</em>'.
	 * @see ensembleModel.IssueType#getSolvers()
	 * @see #getIssueType()
	 * @generated
	 */
	EReference getIssueType_Solvers();

	/**
	 * Returns the meta object for class '{@link ensembleModel.Solver <em>Solver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solver</em>'.
	 * @see ensembleModel.Solver
	 * @generated
	 */
	EClass getSolver();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.Solver#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ensembleModel.Solver#getName()
	 * @see #getSolver()
	 * @generated
	 */
	EAttribute getSolver_Name();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.Solver#isActive <em>Active</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Active</em>'.
	 * @see ensembleModel.Solver#isActive()
	 * @see #getSolver()
	 * @generated
	 */
	EAttribute getSolver_Active();

	/**
	 * Returns the meta object for the containment reference list '{@link ensembleModel.Solver#getSolverParameters <em>Solver Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Solver Parameters</em>'.
	 * @see ensembleModel.Solver#getSolverParameters()
	 * @see #getSolver()
	 * @generated
	 */
	EReference getSolver_SolverParameters();

	/**
	 * Returns the meta object for the reference list '{@link ensembleModel.Solver#getCompatibleIssueTypes <em>Compatible Issue Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Compatible Issue Types</em>'.
	 * @see ensembleModel.Solver#getCompatibleIssueTypes()
	 * @see #getSolver()
	 * @generated
	 */
	EReference getSolver_CompatibleIssueTypes();

	/**
	 * Returns the meta object for class '{@link ensembleModel.RoleParameter <em>Role Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Parameter</em>'.
	 * @see ensembleModel.RoleParameter
	 * @generated
	 */
	EClass getRoleParameter();

	/**
	 * Returns the meta object for class '{@link ensembleModel.Preference <em>Preference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Preference</em>'.
	 * @see ensembleModel.Preference
	 * @generated
	 */
	EClass getPreference();

	/**
	 * Returns the meta object for class '{@link ensembleModel.IssueParameter <em>Issue Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Issue Parameter</em>'.
	 * @see ensembleModel.IssueParameter
	 * @generated
	 */
	EClass getIssueParameter();

	/**
	 * Returns the meta object for class '{@link ensembleModel.SolverParameter <em>Solver Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solver Parameter</em>'.
	 * @see ensembleModel.SolverParameter
	 * @generated
	 */
	EClass getSolverParameter();

	/**
	 * Returns the meta object for class '{@link ensembleModel.NamedValue <em>Named Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Named Value</em>'.
	 * @see ensembleModel.NamedValue
	 * @generated
	 */
	EClass getNamedValue();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.NamedValue#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ensembleModel.NamedValue#getName()
	 * @see #getNamedValue()
	 * @generated
	 */
	EAttribute getNamedValue_Name();

	/**
	 * Returns the meta object for the attribute '{@link ensembleModel.NamedValue#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see ensembleModel.NamedValue#getValue()
	 * @see #getNamedValue()
	 * @generated
	 */
	EAttribute getNamedValue_Value();

	/**
	 * Returns the meta object for class '{@link ensembleModel.DomainObject <em>Domain Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Domain Object</em>'.
	 * @see ensembleModel.DomainObject
	 * @generated
	 */
	EClass getDomainObject();

	/**
	 * Returns the meta object for the reference list '{@link ensembleModel.DomainObject#getRoles <em>Roles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Roles</em>'.
	 * @see ensembleModel.DomainObject#getRoles()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Roles();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	EnsembleModelFactory getEnsembleModelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link ensembleModel.impl.EnsembleImpl <em>Ensemble</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.EnsembleImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getEnsemble()
		 * @generated
		 */
		EClass ENSEMBLE = eINSTANCE.getEnsemble();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENSEMBLE__NAME = eINSTANCE.getEnsemble_Name();

		/**
		 * The meta object literal for the '<em><b>Roles</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENSEMBLE__ROLES = eINSTANCE.getEnsemble_Roles();

		/**
		 * The meta object literal for the '<em><b>Issuetypes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENSEMBLE__ISSUETYPES = eINSTANCE.getEnsemble_Issuetypes();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.RoleImpl <em>Role</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.RoleImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getRole()
		 * @generated
		 */
		EClass ROLE = eINSTANCE.getRole();

		/**
		 * The meta object literal for the '<em><b>DO Role Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROLE__DO_ROLE_NAME = eINSTANCE.getRole_DORoleName();

		/**
		 * The meta object literal for the '<em><b>Triggered Issues</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__TRIGGERED_ISSUES = eINSTANCE.getRole_TriggeredIssues();

		/**
		 * The meta object literal for the '<em><b>Role Solvers</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__ROLE_SOLVERS = eINSTANCE.getRole_RoleSolvers();

		/**
		 * The meta object literal for the '<em><b>Role Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__ROLE_PARAMETERS = eINSTANCE.getRole_RoleParameters();

		/**
		 * The meta object literal for the '<em><b>Preferences</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__PREFERENCES = eINSTANCE.getRole_Preferences();

		/**
		 * The meta object literal for the '<em><b>Domainobject</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__DOMAINOBJECT = eINSTANCE.getRole_Domainobject();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.IssueTypeImpl <em>Issue Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.IssueTypeImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getIssueType()
		 * @generated
		 */
		EClass ISSUE_TYPE = eINSTANCE.getIssueType();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ISSUE_TYPE__NAME = eINSTANCE.getIssueType_Name();

		/**
		 * The meta object literal for the '<em><b>Issue Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ISSUE_TYPE__ISSUE_PARAMETERS = eINSTANCE.getIssueType_IssueParameters();

		/**
		 * The meta object literal for the '<em><b>Solvers</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ISSUE_TYPE__SOLVERS = eINSTANCE.getIssueType_Solvers();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.SolverImpl <em>Solver</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.SolverImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getSolver()
		 * @generated
		 */
		EClass SOLVER = eINSTANCE.getSolver();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOLVER__NAME = eINSTANCE.getSolver_Name();

		/**
		 * The meta object literal for the '<em><b>Active</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOLVER__ACTIVE = eINSTANCE.getSolver_Active();

		/**
		 * The meta object literal for the '<em><b>Solver Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOLVER__SOLVER_PARAMETERS = eINSTANCE.getSolver_SolverParameters();

		/**
		 * The meta object literal for the '<em><b>Compatible Issue Types</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOLVER__COMPATIBLE_ISSUE_TYPES = eINSTANCE.getSolver_CompatibleIssueTypes();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.RoleParameterImpl <em>Role Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.RoleParameterImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getRoleParameter()
		 * @generated
		 */
		EClass ROLE_PARAMETER = eINSTANCE.getRoleParameter();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.PreferenceImpl <em>Preference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.PreferenceImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getPreference()
		 * @generated
		 */
		EClass PREFERENCE = eINSTANCE.getPreference();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.IssueParameterImpl <em>Issue Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.IssueParameterImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getIssueParameter()
		 * @generated
		 */
		EClass ISSUE_PARAMETER = eINSTANCE.getIssueParameter();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.SolverParameterImpl <em>Solver Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.SolverParameterImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getSolverParameter()
		 * @generated
		 */
		EClass SOLVER_PARAMETER = eINSTANCE.getSolverParameter();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.NamedValueImpl <em>Named Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.NamedValueImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getNamedValue()
		 * @generated
		 */
		EClass NAMED_VALUE = eINSTANCE.getNamedValue();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAMED_VALUE__NAME = eINSTANCE.getNamedValue_Name();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAMED_VALUE__VALUE = eINSTANCE.getNamedValue_Value();

		/**
		 * The meta object literal for the '{@link ensembleModel.impl.DomainObjectImpl <em>Domain Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ensembleModel.impl.DomainObjectImpl
		 * @see ensembleModel.impl.EnsembleModelPackageImpl#getDomainObject()
		 * @generated
		 */
		EClass DOMAIN_OBJECT = eINSTANCE.getDomainObject();

		/**
		 * The meta object literal for the '<em><b>Roles</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__ROLES = eINSTANCE.getDomainObject_Roles();

	}

} //EnsembleModelPackage
