/**
 */
package UMS.impl;

import UMS.LInitialState;
import UMS.OutgoingLTransition;
import UMS.UMSPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LInitial State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link UMS.impl.LInitialStateImpl#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LInitialStateImpl extends LStateImpl implements LInitialState {
	/**
	 * The cached value of the '{@link #getOutgoingltransitionIS() <em>Outgoingltransition IS</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoingltransitionIS()
	 * @generated
	 * @ordered
	 */
	protected OutgoingLTransition outgoingltransitionIS;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LInitialStateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UMSPackage.Literals.LINITIAL_STATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition getOutgoingltransitionIS() {
		if (outgoingltransitionIS != null && outgoingltransitionIS.eIsProxy()) {
			InternalEObject oldOutgoingltransitionIS = (InternalEObject)outgoingltransitionIS;
			outgoingltransitionIS = (OutgoingLTransition)eResolveProxy(oldOutgoingltransitionIS);
			if (outgoingltransitionIS != oldOutgoingltransitionIS) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS, oldOutgoingltransitionIS, outgoingltransitionIS));
			}
		}
		return outgoingltransitionIS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutgoingLTransition basicGetOutgoingltransitionIS() {
		return outgoingltransitionIS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoingltransitionIS(OutgoingLTransition newOutgoingltransitionIS, NotificationChain msgs) {
		OutgoingLTransition oldOutgoingltransitionIS = outgoingltransitionIS;
		outgoingltransitionIS = newOutgoingltransitionIS;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS, oldOutgoingltransitionIS, newOutgoingltransitionIS);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoingltransitionIS(OutgoingLTransition newOutgoingltransitionIS) {
		if (newOutgoingltransitionIS != outgoingltransitionIS) {
			NotificationChain msgs = null;
			if (outgoingltransitionIS != null)
				msgs = ((InternalEObject)outgoingltransitionIS).eInverseRemove(this, UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE, OutgoingLTransition.class, msgs);
			if (newOutgoingltransitionIS != null)
				msgs = ((InternalEObject)newOutgoingltransitionIS).eInverseAdd(this, UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE, OutgoingLTransition.class, msgs);
			msgs = basicSetOutgoingltransitionIS(newOutgoingltransitionIS, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS, newOutgoingltransitionIS, newOutgoingltransitionIS));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS:
				if (outgoingltransitionIS != null)
					msgs = ((InternalEObject)outgoingltransitionIS).eInverseRemove(this, UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE, OutgoingLTransition.class, msgs);
				return basicSetOutgoingltransitionIS((OutgoingLTransition)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS:
				return basicSetOutgoingltransitionIS(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS:
				if (resolve) return getOutgoingltransitionIS();
				return basicGetOutgoingltransitionIS();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS:
				setOutgoingltransitionIS((OutgoingLTransition)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS:
				setOutgoingltransitionIS((OutgoingLTransition)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS:
				return outgoingltransitionIS != null;
		}
		return super.eIsSet(featureID);
	}

} //LInitialStateImpl
