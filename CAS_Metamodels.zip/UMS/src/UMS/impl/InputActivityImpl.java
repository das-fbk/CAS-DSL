/**
 */
package UMS.impl;

import UMS.IncomingTransition;
import UMS.InputActivity;
import UMS.UMSPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Activity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link UMS.impl.InputActivityImpl#getIncomingtransition <em>Incomingtransition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputActivityImpl extends ActivityImpl implements InputActivity {
	/**
	 * The cached value of the '{@link #getIncomingtransition() <em>Incomingtransition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncomingtransition()
	 * @generated
	 * @ordered
	 */
	protected IncomingTransition incomingtransition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputActivityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UMSPackage.Literals.INPUT_ACTIVITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingTransition getIncomingtransition() {
		if (incomingtransition != null && incomingtransition.eIsProxy()) {
			InternalEObject oldIncomingtransition = (InternalEObject)incomingtransition;
			incomingtransition = (IncomingTransition)eResolveProxy(oldIncomingtransition);
			if (incomingtransition != oldIncomingtransition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION, oldIncomingtransition, incomingtransition));
			}
		}
		return incomingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IncomingTransition basicGetIncomingtransition() {
		return incomingtransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIncomingtransition(IncomingTransition newIncomingtransition, NotificationChain msgs) {
		IncomingTransition oldIncomingtransition = incomingtransition;
		incomingtransition = newIncomingtransition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION, oldIncomingtransition, newIncomingtransition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncomingtransition(IncomingTransition newIncomingtransition) {
		if (newIncomingtransition != incomingtransition) {
			NotificationChain msgs = null;
			if (incomingtransition != null)
				msgs = ((InternalEObject)incomingtransition).eInverseRemove(this, UMSPackage.INCOMING_TRANSITION__INPUTACTIVITY, IncomingTransition.class, msgs);
			if (newIncomingtransition != null)
				msgs = ((InternalEObject)newIncomingtransition).eInverseAdd(this, UMSPackage.INCOMING_TRANSITION__INPUTACTIVITY, IncomingTransition.class, msgs);
			msgs = basicSetIncomingtransition(newIncomingtransition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION, newIncomingtransition, newIncomingtransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION:
				if (incomingtransition != null)
					msgs = ((InternalEObject)incomingtransition).eInverseRemove(this, UMSPackage.INCOMING_TRANSITION__INPUTACTIVITY, IncomingTransition.class, msgs);
				return basicSetIncomingtransition((IncomingTransition)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION:
				return basicSetIncomingtransition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION:
				if (resolve) return getIncomingtransition();
				return basicGetIncomingtransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION:
				setIncomingtransition((IncomingTransition)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION:
				setIncomingtransition((IncomingTransition)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UMSPackage.INPUT_ACTIVITY__INCOMINGTRANSITION:
				return incomingtransition != null;
		}
		return super.eIsSet(featureID);
	}

} //InputActivityImpl
