/**
 */
package UMS.impl;

import UMS.LEvent;
import UMS.LInitialState;
import UMS.LState;
import UMS.OutgoingLTransition;
import UMS.UMSPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Outgoing LTransition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link UMS.impl.OutgoingLTransitionImpl#getLinitialstate <em>Linitialstate</em>}</li>
 *   <li>{@link UMS.impl.OutgoingLTransitionImpl#getLevent <em>Levent</em>}</li>
 *   <li>{@link UMS.impl.OutgoingLTransitionImpl#getLstate <em>Lstate</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutgoingLTransitionImpl extends LTransitionImpl implements OutgoingLTransition {
	/**
	 * The cached value of the '{@link #getLinitialstate() <em>Linitialstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinitialstate()
	 * @generated
	 * @ordered
	 */
	protected LInitialState linitialstate;

	/**
	 * The cached value of the '{@link #getLevent() <em>Levent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLevent()
	 * @generated
	 * @ordered
	 */
	protected LEvent levent;

	/**
	 * The cached value of the '{@link #getLstate() <em>Lstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLstate()
	 * @generated
	 * @ordered
	 */
	protected LState lstate;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutgoingLTransitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UMSPackage.Literals.OUTGOING_LTRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LInitialState getLinitialstate() {
		if (linitialstate != null && linitialstate.eIsProxy()) {
			InternalEObject oldLinitialstate = (InternalEObject)linitialstate;
			linitialstate = (LInitialState)eResolveProxy(oldLinitialstate);
			if (linitialstate != oldLinitialstate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE, oldLinitialstate, linitialstate));
			}
		}
		return linitialstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LInitialState basicGetLinitialstate() {
		return linitialstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLinitialstate(LInitialState newLinitialstate, NotificationChain msgs) {
		LInitialState oldLinitialstate = linitialstate;
		linitialstate = newLinitialstate;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE, oldLinitialstate, newLinitialstate);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLinitialstate(LInitialState newLinitialstate) {
		if (newLinitialstate != linitialstate) {
			NotificationChain msgs = null;
			if (linitialstate != null)
				msgs = ((InternalEObject)linitialstate).eInverseRemove(this, UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS, LInitialState.class, msgs);
			if (newLinitialstate != null)
				msgs = ((InternalEObject)newLinitialstate).eInverseAdd(this, UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS, LInitialState.class, msgs);
			msgs = basicSetLinitialstate(newLinitialstate, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE, newLinitialstate, newLinitialstate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LEvent getLevent() {
		if (levent != null && levent.eIsProxy()) {
			InternalEObject oldLevent = (InternalEObject)levent;
			levent = (LEvent)eResolveProxy(oldLevent);
			if (levent != oldLevent) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.OUTGOING_LTRANSITION__LEVENT, oldLevent, levent));
			}
		}
		return levent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LEvent basicGetLevent() {
		return levent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLevent(LEvent newLevent, NotificationChain msgs) {
		LEvent oldLevent = levent;
		levent = newLevent;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.OUTGOING_LTRANSITION__LEVENT, oldLevent, newLevent);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLevent(LEvent newLevent) {
		if (newLevent != levent) {
			NotificationChain msgs = null;
			if (levent != null)
				msgs = ((InternalEObject)levent).eInverseRemove(this, UMSPackage.LEVENT__OUTGOINGLTRANSITION, LEvent.class, msgs);
			if (newLevent != null)
				msgs = ((InternalEObject)newLevent).eInverseAdd(this, UMSPackage.LEVENT__OUTGOINGLTRANSITION, LEvent.class, msgs);
			msgs = basicSetLevent(newLevent, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.OUTGOING_LTRANSITION__LEVENT, newLevent, newLevent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LState getLstate() {
		if (lstate != null && lstate.eIsProxy()) {
			InternalEObject oldLstate = (InternalEObject)lstate;
			lstate = (LState)eResolveProxy(oldLstate);
			if (lstate != oldLstate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UMSPackage.OUTGOING_LTRANSITION__LSTATE, oldLstate, lstate));
			}
		}
		return lstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LState basicGetLstate() {
		return lstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLstate(LState newLstate, NotificationChain msgs) {
		LState oldLstate = lstate;
		lstate = newLstate;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UMSPackage.OUTGOING_LTRANSITION__LSTATE, oldLstate, newLstate);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLstate(LState newLstate) {
		if (newLstate != lstate) {
			NotificationChain msgs = null;
			if (lstate != null)
				msgs = ((InternalEObject)lstate).eInverseRemove(this, UMSPackage.LSTATE__OUTGOINGLTRANSITION, LState.class, msgs);
			if (newLstate != null)
				msgs = ((InternalEObject)newLstate).eInverseAdd(this, UMSPackage.LSTATE__OUTGOINGLTRANSITION, LState.class, msgs);
			msgs = basicSetLstate(newLstate, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UMSPackage.OUTGOING_LTRANSITION__LSTATE, newLstate, newLstate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE:
				if (linitialstate != null)
					msgs = ((InternalEObject)linitialstate).eInverseRemove(this, UMSPackage.LINITIAL_STATE__OUTGOINGLTRANSITION_IS, LInitialState.class, msgs);
				return basicSetLinitialstate((LInitialState)otherEnd, msgs);
			case UMSPackage.OUTGOING_LTRANSITION__LEVENT:
				if (levent != null)
					msgs = ((InternalEObject)levent).eInverseRemove(this, UMSPackage.LEVENT__OUTGOINGLTRANSITION, LEvent.class, msgs);
				return basicSetLevent((LEvent)otherEnd, msgs);
			case UMSPackage.OUTGOING_LTRANSITION__LSTATE:
				if (lstate != null)
					msgs = ((InternalEObject)lstate).eInverseRemove(this, UMSPackage.LSTATE__OUTGOINGLTRANSITION, LState.class, msgs);
				return basicSetLstate((LState)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE:
				return basicSetLinitialstate(null, msgs);
			case UMSPackage.OUTGOING_LTRANSITION__LEVENT:
				return basicSetLevent(null, msgs);
			case UMSPackage.OUTGOING_LTRANSITION__LSTATE:
				return basicSetLstate(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE:
				if (resolve) return getLinitialstate();
				return basicGetLinitialstate();
			case UMSPackage.OUTGOING_LTRANSITION__LEVENT:
				if (resolve) return getLevent();
				return basicGetLevent();
			case UMSPackage.OUTGOING_LTRANSITION__LSTATE:
				if (resolve) return getLstate();
				return basicGetLstate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE:
				setLinitialstate((LInitialState)newValue);
				return;
			case UMSPackage.OUTGOING_LTRANSITION__LEVENT:
				setLevent((LEvent)newValue);
				return;
			case UMSPackage.OUTGOING_LTRANSITION__LSTATE:
				setLstate((LState)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE:
				setLinitialstate((LInitialState)null);
				return;
			case UMSPackage.OUTGOING_LTRANSITION__LEVENT:
				setLevent((LEvent)null);
				return;
			case UMSPackage.OUTGOING_LTRANSITION__LSTATE:
				setLstate((LState)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UMSPackage.OUTGOING_LTRANSITION__LINITIALSTATE:
				return linitialstate != null;
			case UMSPackage.OUTGOING_LTRANSITION__LEVENT:
				return levent != null;
			case UMSPackage.OUTGOING_LTRANSITION__LSTATE:
				return lstate != null;
		}
		return super.eIsSet(featureID);
	}

} //OutgoingLTransitionImpl
