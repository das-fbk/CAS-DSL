/**
 */
package UMS;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see UMS.UMSFactory
 * @model kind="package"
 * @generated
 */
public interface UMSPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "UMS";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/UMS";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "UMS";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UMSPackage eINSTANCE = UMS.impl.UMSPackageImpl.init();

	/**
	 * The meta object id for the '{@link UMS.impl.DomainObjectImpl <em>Domain Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.DomainObjectImpl
	 * @see UMS.impl.UMSPackageImpl#getDomainObject()
	 * @generated
	 */
	int DOMAIN_OBJECT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Core process</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__CORE_PROCESS = 1;

	/**
	 * The feature id for the '<em><b>Fragment</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__FRAGMENT = 2;

	/**
	 * The feature id for the '<em><b>Internaldomainknowledge</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE = 3;

	/**
	 * The feature id for the '<em><b>Externaldomainknowledge</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE = 4;

	/**
	 * The number of structural features of the '<em>Domain Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Domain Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OBJECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.ProcessImpl <em>Process</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.ProcessImpl
	 * @see UMS.impl.UMSPackageImpl#getProcess()
	 * @generated
	 */
	int PROCESS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Activities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__ACTIVITIES = 1;

	/**
	 * The feature id for the '<em><b>States</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__STATES = 2;

	/**
	 * The feature id for the '<em><b>Transitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__TRANSITIONS = 3;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__ANNOTATIONS = 4;

	/**
	 * The number of structural features of the '<em>Process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.ActivityImpl <em>Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.ActivityImpl
	 * @see UMS.impl.UMSPackageImpl#getActivity()
	 * @generated
	 */
	int ACTIVITY = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__PRECONDITION = 1;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__EFFECT = 2;

	/**
	 * The number of structural features of the '<em>Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.InputActivityImpl <em>Input Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.InputActivityImpl
	 * @see UMS.impl.UMSPackageImpl#getInputActivity()
	 * @generated
	 */
	int INPUT_ACTIVITY = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The feature id for the '<em><b>Incomingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY__INCOMINGTRANSITION = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Input Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Input Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.OutputActivityImpl <em>Output Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.OutputActivityImpl
	 * @see UMS.impl.UMSPackageImpl#getOutputActivity()
	 * @generated
	 */
	int OUTPUT_ACTIVITY = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The feature id for the '<em><b>Outgoingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY__OUTGOINGTRANSITION = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Output Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Output Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.AbstractActivityImpl <em>Abstract Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.AbstractActivityImpl
	 * @see UMS.impl.UMSPackageImpl#getAbstractActivity()
	 * @generated
	 */
	int ABSTRACT_ACTIVITY = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The feature id for the '<em><b>Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY__GOAL = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Abstract Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Abstract Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.ConcreteActivityImpl <em>Concrete Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.ConcreteActivityImpl
	 * @see UMS.impl.UMSPackageImpl#getConcreteActivity()
	 * @generated
	 */
	int CONCRETE_ACTIVITY = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY__NAME = ACTIVITY__NAME;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY__PRECONDITION = ACTIVITY__PRECONDITION;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY__EFFECT = ACTIVITY__EFFECT;

	/**
	 * The number of structural features of the '<em>Concrete Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY_FEATURE_COUNT = ACTIVITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Concrete Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRETE_ACTIVITY_OPERATION_COUNT = ACTIVITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.StateImpl <em>State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.StateImpl
	 * @see UMS.impl.UMSPackageImpl#getState()
	 * @generated
	 */
	int STATE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Is Initial</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__IS_INITIAL = 1;

	/**
	 * The feature id for the '<em><b>Incomingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__INCOMINGTRANSITION = 2;

	/**
	 * The feature id for the '<em><b>Outgoingtransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__OUTGOINGTRANSITION = 3;

	/**
	 * The number of structural features of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.TransitionImpl <em>Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.TransitionImpl
	 * @see UMS.impl.UMSPackageImpl#getTransition()
	 * @generated
	 */
	int TRANSITION = 8;

	/**
	 * The number of structural features of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.OutgoingTransitionImpl <em>Outgoing Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.OutgoingTransitionImpl
	 * @see UMS.impl.UMSPackageImpl#getOutgoingTransition()
	 * @generated
	 */
	int OUTGOING_TRANSITION = 9;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION__STATE = TRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Outputactivity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION__OUTPUTACTIVITY = TRANSITION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Outgoing Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION_FEATURE_COUNT = TRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Outgoing Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_TRANSITION_OPERATION_COUNT = TRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.IncomingTransitionImpl <em>Incoming Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.IncomingTransitionImpl
	 * @see UMS.impl.UMSPackageImpl#getIncomingTransition()
	 * @generated
	 */
	int INCOMING_TRANSITION = 10;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION__STATE = TRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Inputactivity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION__INPUTACTIVITY = TRANSITION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Incoming Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION_FEATURE_COUNT = TRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Incoming Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_TRANSITION_OPERATION_COUNT = TRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.AnnotationImpl <em>Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.AnnotationImpl
	 * @see UMS.impl.UMSPackageImpl#getAnnotation()
	 * @generated
	 */
	int ANNOTATION = 11;

	/**
	 * The number of structural features of the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.PreconditionImpl <em>Precondition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.PreconditionImpl
	 * @see UMS.impl.UMSPackageImpl#getPrecondition()
	 * @generated
	 */
	int PRECONDITION = 12;

	/**
	 * The feature id for the '<em><b>Activity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION__ACTIVITY = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION__LSTATE = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Precondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Precondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.EffectImpl <em>Effect</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.EffectImpl
	 * @see UMS.impl.UMSPackageImpl#getEffect()
	 * @generated
	 */
	int EFFECT = 13;

	/**
	 * The feature id for the '<em><b>Activity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__ACTIVITY = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__LEVENT = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Effect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Effect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.GoalImpl <em>Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.GoalImpl
	 * @see UMS.impl.UMSPackageImpl#getGoal()
	 * @generated
	 */
	int GOAL = 14;

	/**
	 * The feature id for the '<em><b>Abstractactivity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__ABSTRACTACTIVITY = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__LSTATE = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.DomainPropertyImpl <em>Domain Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.DomainPropertyImpl
	 * @see UMS.impl.UMSPackageImpl#getDomainProperty()
	 * @generated
	 */
	int DOMAIN_PROPERTY = 15;

	/**
	 * The feature id for the '<em><b>Lstates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LSTATES = 0;

	/**
	 * The feature id for the '<em><b>Linitialstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LINITIALSTATE = 1;

	/**
	 * The feature id for the '<em><b>Levents</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LEVENTS = 2;

	/**
	 * The feature id for the '<em><b>Ltransitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY__LTRANSITIONS = 3;

	/**
	 * The number of structural features of the '<em>Domain Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Domain Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_PROPERTY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.LStateImpl <em>LState</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.LStateImpl
	 * @see UMS.impl.UMSPackageImpl#getLState()
	 * @generated
	 */
	int LSTATE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Incomingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE__INCOMINGLTRANSITION = 1;

	/**
	 * The feature id for the '<em><b>Outgoingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE__OUTGOINGLTRANSITION = 2;

	/**
	 * The number of structural features of the '<em>LState</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>LState</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LSTATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.LInitialStateImpl <em>LInitial State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.LInitialStateImpl
	 * @see UMS.impl.UMSPackageImpl#getLInitialState()
	 * @generated
	 */
	int LINITIAL_STATE = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__NAME = LSTATE__NAME;

	/**
	 * The feature id for the '<em><b>Incomingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__INCOMINGLTRANSITION = LSTATE__INCOMINGLTRANSITION;

	/**
	 * The feature id for the '<em><b>Outgoingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__OUTGOINGLTRANSITION = LSTATE__OUTGOINGLTRANSITION;

	/**
	 * The feature id for the '<em><b>Outgoingltransition IS</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE__OUTGOINGLTRANSITION_IS = LSTATE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>LInitial State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE_FEATURE_COUNT = LSTATE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>LInitial State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINITIAL_STATE_OPERATION_COUNT = LSTATE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.LEventImpl <em>LEvent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.LEventImpl
	 * @see UMS.impl.UMSPackageImpl#getLEvent()
	 * @generated
	 */
	int LEVENT = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Outgoingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT__OUTGOINGLTRANSITION = 1;

	/**
	 * The feature id for the '<em><b>Incomingltransition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT__INCOMINGLTRANSITION = 2;

	/**
	 * The number of structural features of the '<em>LEvent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>LEvent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LEVENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.LTransitionImpl <em>LTransition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.LTransitionImpl
	 * @see UMS.impl.UMSPackageImpl#getLTransition()
	 * @generated
	 */
	int LTRANSITION = 19;

	/**
	 * The number of structural features of the '<em>LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LTRANSITION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LTRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UMS.impl.IncomingLTransitionImpl <em>Incoming LTransition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.IncomingLTransitionImpl
	 * @see UMS.impl.UMSPackageImpl#getIncomingLTransition()
	 * @generated
	 */
	int INCOMING_LTRANSITION = 20;

	/**
	 * The feature id for the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION__LEVENT = LTRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION__LSTATE = LTRANSITION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Incoming LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION_FEATURE_COUNT = LTRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Incoming LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCOMING_LTRANSITION_OPERATION_COUNT = LTRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.OutgoingLTransitionImpl <em>Outgoing LTransition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.OutgoingLTransitionImpl
	 * @see UMS.impl.UMSPackageImpl#getOutgoingLTransition()
	 * @generated
	 */
	int OUTGOING_LTRANSITION = 21;

	/**
	 * The feature id for the '<em><b>Linitialstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION__LINITIALSTATE = LTRANSITION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Levent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION__LEVENT = LTRANSITION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Lstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION__LSTATE = LTRANSITION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Outgoing LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION_FEATURE_COUNT = LTRANSITION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Outgoing LTransition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTGOING_LTRANSITION_OPERATION_COUNT = LTRANSITION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UMS.impl.AdaptiveSystemImpl <em>Adaptive System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UMS.impl.AdaptiveSystemImpl
	 * @see UMS.impl.UMSPackageImpl#getAdaptiveSystem()
	 * @generated
	 */
	int ADAPTIVE_SYSTEM = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Domainobjects</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM__DOMAINOBJECTS = 1;

	/**
	 * The number of structural features of the '<em>Adaptive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Adaptive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTIVE_SYSTEM_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link UMS.DomainObject <em>Domain Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Domain Object</em>'.
	 * @see UMS.DomainObject
	 * @generated
	 */
	EClass getDomainObject();

	/**
	 * Returns the meta object for the attribute '{@link UMS.DomainObject#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.DomainObject#getName()
	 * @see #getDomainObject()
	 * @generated
	 */
	EAttribute getDomainObject_Name();

	/**
	 * Returns the meta object for the containment reference '{@link UMS.DomainObject#getCore_process <em>Core process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Core process</em>'.
	 * @see UMS.DomainObject#getCore_process()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Core_process();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.DomainObject#getFragment <em>Fragment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fragment</em>'.
	 * @see UMS.DomainObject#getFragment()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Fragment();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.DomainObject#getInternaldomainknowledge <em>Internaldomainknowledge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Internaldomainknowledge</em>'.
	 * @see UMS.DomainObject#getInternaldomainknowledge()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Internaldomainknowledge();

	/**
	 * Returns the meta object for the reference list '{@link UMS.DomainObject#getExternaldomainknowledge <em>Externaldomainknowledge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Externaldomainknowledge</em>'.
	 * @see UMS.DomainObject#getExternaldomainknowledge()
	 * @see #getDomainObject()
	 * @generated
	 */
	EReference getDomainObject_Externaldomainknowledge();

	/**
	 * Returns the meta object for class '{@link UMS.Process <em>Process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Process</em>'.
	 * @see UMS.Process
	 * @generated
	 */
	EClass getProcess();

	/**
	 * Returns the meta object for the attribute '{@link UMS.Process#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.Process#getName()
	 * @see #getProcess()
	 * @generated
	 */
	EAttribute getProcess_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.Process#getActivities <em>Activities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Activities</em>'.
	 * @see UMS.Process#getActivities()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_Activities();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.Process#getStates <em>States</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>States</em>'.
	 * @see UMS.Process#getStates()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_States();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.Process#getTransitions <em>Transitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transitions</em>'.
	 * @see UMS.Process#getTransitions()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_Transitions();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.Process#getAnnotations <em>Annotations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Annotations</em>'.
	 * @see UMS.Process#getAnnotations()
	 * @see #getProcess()
	 * @generated
	 */
	EReference getProcess_Annotations();

	/**
	 * Returns the meta object for class '{@link UMS.Activity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Activity</em>'.
	 * @see UMS.Activity
	 * @generated
	 */
	EClass getActivity();

	/**
	 * Returns the meta object for the attribute '{@link UMS.Activity#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.Activity#getName()
	 * @see #getActivity()
	 * @generated
	 */
	EAttribute getActivity_Name();

	/**
	 * Returns the meta object for the reference '{@link UMS.Activity#getPrecondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Precondition</em>'.
	 * @see UMS.Activity#getPrecondition()
	 * @see #getActivity()
	 * @generated
	 */
	EReference getActivity_Precondition();

	/**
	 * Returns the meta object for the reference '{@link UMS.Activity#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Effect</em>'.
	 * @see UMS.Activity#getEffect()
	 * @see #getActivity()
	 * @generated
	 */
	EReference getActivity_Effect();

	/**
	 * Returns the meta object for class '{@link UMS.InputActivity <em>Input Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Activity</em>'.
	 * @see UMS.InputActivity
	 * @generated
	 */
	EClass getInputActivity();

	/**
	 * Returns the meta object for the reference '{@link UMS.InputActivity#getIncomingtransition <em>Incomingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingtransition</em>'.
	 * @see UMS.InputActivity#getIncomingtransition()
	 * @see #getInputActivity()
	 * @generated
	 */
	EReference getInputActivity_Incomingtransition();

	/**
	 * Returns the meta object for class '{@link UMS.OutputActivity <em>Output Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output Activity</em>'.
	 * @see UMS.OutputActivity
	 * @generated
	 */
	EClass getOutputActivity();

	/**
	 * Returns the meta object for the reference '{@link UMS.OutputActivity#getOutgoingtransition <em>Outgoingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingtransition</em>'.
	 * @see UMS.OutputActivity#getOutgoingtransition()
	 * @see #getOutputActivity()
	 * @generated
	 */
	EReference getOutputActivity_Outgoingtransition();

	/**
	 * Returns the meta object for class '{@link UMS.AbstractActivity <em>Abstract Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Activity</em>'.
	 * @see UMS.AbstractActivity
	 * @generated
	 */
	EClass getAbstractActivity();

	/**
	 * Returns the meta object for the reference '{@link UMS.AbstractActivity#getGoal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Goal</em>'.
	 * @see UMS.AbstractActivity#getGoal()
	 * @see #getAbstractActivity()
	 * @generated
	 */
	EReference getAbstractActivity_Goal();

	/**
	 * Returns the meta object for class '{@link UMS.ConcreteActivity <em>Concrete Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Concrete Activity</em>'.
	 * @see UMS.ConcreteActivity
	 * @generated
	 */
	EClass getConcreteActivity();

	/**
	 * Returns the meta object for class '{@link UMS.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State</em>'.
	 * @see UMS.State
	 * @generated
	 */
	EClass getState();

	/**
	 * Returns the meta object for the attribute '{@link UMS.State#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.State#getName()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_Name();

	/**
	 * Returns the meta object for the attribute '{@link UMS.State#isIsInitial <em>Is Initial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Initial</em>'.
	 * @see UMS.State#isIsInitial()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_IsInitial();

	/**
	 * Returns the meta object for the reference '{@link UMS.State#getIncomingtransition <em>Incomingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingtransition</em>'.
	 * @see UMS.State#getIncomingtransition()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Incomingtransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.State#getOutgoingtransition <em>Outgoingtransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingtransition</em>'.
	 * @see UMS.State#getOutgoingtransition()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Outgoingtransition();

	/**
	 * Returns the meta object for class '{@link UMS.Transition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition</em>'.
	 * @see UMS.Transition
	 * @generated
	 */
	EClass getTransition();

	/**
	 * Returns the meta object for class '{@link UMS.OutgoingTransition <em>Outgoing Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Outgoing Transition</em>'.
	 * @see UMS.OutgoingTransition
	 * @generated
	 */
	EClass getOutgoingTransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.OutgoingTransition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see UMS.OutgoingTransition#getState()
	 * @see #getOutgoingTransition()
	 * @generated
	 */
	EReference getOutgoingTransition_State();

	/**
	 * Returns the meta object for the reference '{@link UMS.OutgoingTransition#getOutputactivity <em>Outputactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outputactivity</em>'.
	 * @see UMS.OutgoingTransition#getOutputactivity()
	 * @see #getOutgoingTransition()
	 * @generated
	 */
	EReference getOutgoingTransition_Outputactivity();

	/**
	 * Returns the meta object for class '{@link UMS.IncomingTransition <em>Incoming Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Incoming Transition</em>'.
	 * @see UMS.IncomingTransition
	 * @generated
	 */
	EClass getIncomingTransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.IncomingTransition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see UMS.IncomingTransition#getState()
	 * @see #getIncomingTransition()
	 * @generated
	 */
	EReference getIncomingTransition_State();

	/**
	 * Returns the meta object for the reference '{@link UMS.IncomingTransition#getInputactivity <em>Inputactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Inputactivity</em>'.
	 * @see UMS.IncomingTransition#getInputactivity()
	 * @see #getIncomingTransition()
	 * @generated
	 */
	EReference getIncomingTransition_Inputactivity();

	/**
	 * Returns the meta object for class '{@link UMS.Annotation <em>Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Annotation</em>'.
	 * @see UMS.Annotation
	 * @generated
	 */
	EClass getAnnotation();

	/**
	 * Returns the meta object for class '{@link UMS.Precondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Precondition</em>'.
	 * @see UMS.Precondition
	 * @generated
	 */
	EClass getPrecondition();

	/**
	 * Returns the meta object for the reference '{@link UMS.Precondition#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Activity</em>'.
	 * @see UMS.Precondition#getActivity()
	 * @see #getPrecondition()
	 * @generated
	 */
	EReference getPrecondition_Activity();

	/**
	 * Returns the meta object for the reference '{@link UMS.Precondition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see UMS.Precondition#getLstate()
	 * @see #getPrecondition()
	 * @generated
	 */
	EReference getPrecondition_Lstate();

	/**
	 * Returns the meta object for class '{@link UMS.Effect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Effect</em>'.
	 * @see UMS.Effect
	 * @generated
	 */
	EClass getEffect();

	/**
	 * Returns the meta object for the reference '{@link UMS.Effect#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Activity</em>'.
	 * @see UMS.Effect#getActivity()
	 * @see #getEffect()
	 * @generated
	 */
	EReference getEffect_Activity();

	/**
	 * Returns the meta object for the reference '{@link UMS.Effect#getLevent <em>Levent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Levent</em>'.
	 * @see UMS.Effect#getLevent()
	 * @see #getEffect()
	 * @generated
	 */
	EReference getEffect_Levent();

	/**
	 * Returns the meta object for class '{@link UMS.Goal <em>Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Goal</em>'.
	 * @see UMS.Goal
	 * @generated
	 */
	EClass getGoal();

	/**
	 * Returns the meta object for the reference '{@link UMS.Goal#getAbstractactivity <em>Abstractactivity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Abstractactivity</em>'.
	 * @see UMS.Goal#getAbstractactivity()
	 * @see #getGoal()
	 * @generated
	 */
	EReference getGoal_Abstractactivity();

	/**
	 * Returns the meta object for the reference '{@link UMS.Goal#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see UMS.Goal#getLstate()
	 * @see #getGoal()
	 * @generated
	 */
	EReference getGoal_Lstate();

	/**
	 * Returns the meta object for class '{@link UMS.DomainProperty <em>Domain Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Domain Property</em>'.
	 * @see UMS.DomainProperty
	 * @generated
	 */
	EClass getDomainProperty();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.DomainProperty#getLstates <em>Lstates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Lstates</em>'.
	 * @see UMS.DomainProperty#getLstates()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Lstates();

	/**
	 * Returns the meta object for the reference '{@link UMS.DomainProperty#getLinitialstate <em>Linitialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Linitialstate</em>'.
	 * @see UMS.DomainProperty#getLinitialstate()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Linitialstate();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.DomainProperty#getLevents <em>Levents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Levents</em>'.
	 * @see UMS.DomainProperty#getLevents()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Levents();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.DomainProperty#getLtransitions <em>Ltransitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ltransitions</em>'.
	 * @see UMS.DomainProperty#getLtransitions()
	 * @see #getDomainProperty()
	 * @generated
	 */
	EReference getDomainProperty_Ltransitions();

	/**
	 * Returns the meta object for class '{@link UMS.LState <em>LState</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LState</em>'.
	 * @see UMS.LState
	 * @generated
	 */
	EClass getLState();

	/**
	 * Returns the meta object for the attribute '{@link UMS.LState#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.LState#getName()
	 * @see #getLState()
	 * @generated
	 */
	EAttribute getLState_Name();

	/**
	 * Returns the meta object for the reference '{@link UMS.LState#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingltransition</em>'.
	 * @see UMS.LState#getIncomingltransition()
	 * @see #getLState()
	 * @generated
	 */
	EReference getLState_Incomingltransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.LState#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingltransition</em>'.
	 * @see UMS.LState#getOutgoingltransition()
	 * @see #getLState()
	 * @generated
	 */
	EReference getLState_Outgoingltransition();

	/**
	 * Returns the meta object for class '{@link UMS.LInitialState <em>LInitial State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LInitial State</em>'.
	 * @see UMS.LInitialState
	 * @generated
	 */
	EClass getLInitialState();

	/**
	 * Returns the meta object for the reference '{@link UMS.LInitialState#getOutgoingltransitionIS <em>Outgoingltransition IS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingltransition IS</em>'.
	 * @see UMS.LInitialState#getOutgoingltransitionIS()
	 * @see #getLInitialState()
	 * @generated
	 */
	EReference getLInitialState_OutgoingltransitionIS();

	/**
	 * Returns the meta object for class '{@link UMS.LEvent <em>LEvent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LEvent</em>'.
	 * @see UMS.LEvent
	 * @generated
	 */
	EClass getLEvent();

	/**
	 * Returns the meta object for the attribute '{@link UMS.LEvent#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.LEvent#getName()
	 * @see #getLEvent()
	 * @generated
	 */
	EAttribute getLEvent_Name();

	/**
	 * Returns the meta object for the reference '{@link UMS.LEvent#getOutgoingltransition <em>Outgoingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Outgoingltransition</em>'.
	 * @see UMS.LEvent#getOutgoingltransition()
	 * @see #getLEvent()
	 * @generated
	 */
	EReference getLEvent_Outgoingltransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.LEvent#getIncomingltransition <em>Incomingltransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Incomingltransition</em>'.
	 * @see UMS.LEvent#getIncomingltransition()
	 * @see #getLEvent()
	 * @generated
	 */
	EReference getLEvent_Incomingltransition();

	/**
	 * Returns the meta object for class '{@link UMS.LTransition <em>LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LTransition</em>'.
	 * @see UMS.LTransition
	 * @generated
	 */
	EClass getLTransition();

	/**
	 * Returns the meta object for class '{@link UMS.IncomingLTransition <em>Incoming LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Incoming LTransition</em>'.
	 * @see UMS.IncomingLTransition
	 * @generated
	 */
	EClass getIncomingLTransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.IncomingLTransition#getLevent <em>Levent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Levent</em>'.
	 * @see UMS.IncomingLTransition#getLevent()
	 * @see #getIncomingLTransition()
	 * @generated
	 */
	EReference getIncomingLTransition_Levent();

	/**
	 * Returns the meta object for the reference '{@link UMS.IncomingLTransition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see UMS.IncomingLTransition#getLstate()
	 * @see #getIncomingLTransition()
	 * @generated
	 */
	EReference getIncomingLTransition_Lstate();

	/**
	 * Returns the meta object for class '{@link UMS.OutgoingLTransition <em>Outgoing LTransition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Outgoing LTransition</em>'.
	 * @see UMS.OutgoingLTransition
	 * @generated
	 */
	EClass getOutgoingLTransition();

	/**
	 * Returns the meta object for the reference '{@link UMS.OutgoingLTransition#getLinitialstate <em>Linitialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Linitialstate</em>'.
	 * @see UMS.OutgoingLTransition#getLinitialstate()
	 * @see #getOutgoingLTransition()
	 * @generated
	 */
	EReference getOutgoingLTransition_Linitialstate();

	/**
	 * Returns the meta object for the reference '{@link UMS.OutgoingLTransition#getLevent <em>Levent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Levent</em>'.
	 * @see UMS.OutgoingLTransition#getLevent()
	 * @see #getOutgoingLTransition()
	 * @generated
	 */
	EReference getOutgoingLTransition_Levent();

	/**
	 * Returns the meta object for the reference '{@link UMS.OutgoingLTransition#getLstate <em>Lstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lstate</em>'.
	 * @see UMS.OutgoingLTransition#getLstate()
	 * @see #getOutgoingLTransition()
	 * @generated
	 */
	EReference getOutgoingLTransition_Lstate();

	/**
	 * Returns the meta object for class '{@link UMS.AdaptiveSystem <em>Adaptive System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Adaptive System</em>'.
	 * @see UMS.AdaptiveSystem
	 * @generated
	 */
	EClass getAdaptiveSystem();

	/**
	 * Returns the meta object for the attribute '{@link UMS.AdaptiveSystem#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UMS.AdaptiveSystem#getName()
	 * @see #getAdaptiveSystem()
	 * @generated
	 */
	EAttribute getAdaptiveSystem_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link UMS.AdaptiveSystem#getDomainobjects <em>Domainobjects</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Domainobjects</em>'.
	 * @see UMS.AdaptiveSystem#getDomainobjects()
	 * @see #getAdaptiveSystem()
	 * @generated
	 */
	EReference getAdaptiveSystem_Domainobjects();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	UMSFactory getUMSFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link UMS.impl.DomainObjectImpl <em>Domain Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.DomainObjectImpl
		 * @see UMS.impl.UMSPackageImpl#getDomainObject()
		 * @generated
		 */
		EClass DOMAIN_OBJECT = eINSTANCE.getDomainObject();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN_OBJECT__NAME = eINSTANCE.getDomainObject_Name();

		/**
		 * The meta object literal for the '<em><b>Core process</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__CORE_PROCESS = eINSTANCE.getDomainObject_Core_process();

		/**
		 * The meta object literal for the '<em><b>Fragment</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__FRAGMENT = eINSTANCE.getDomainObject_Fragment();

		/**
		 * The meta object literal for the '<em><b>Internaldomainknowledge</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__INTERNALDOMAINKNOWLEDGE = eINSTANCE.getDomainObject_Internaldomainknowledge();

		/**
		 * The meta object literal for the '<em><b>Externaldomainknowledge</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_OBJECT__EXTERNALDOMAINKNOWLEDGE = eINSTANCE.getDomainObject_Externaldomainknowledge();

		/**
		 * The meta object literal for the '{@link UMS.impl.ProcessImpl <em>Process</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.ProcessImpl
		 * @see UMS.impl.UMSPackageImpl#getProcess()
		 * @generated
		 */
		EClass PROCESS = eINSTANCE.getProcess();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS__NAME = eINSTANCE.getProcess_Name();

		/**
		 * The meta object literal for the '<em><b>Activities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__ACTIVITIES = eINSTANCE.getProcess_Activities();

		/**
		 * The meta object literal for the '<em><b>States</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__STATES = eINSTANCE.getProcess_States();

		/**
		 * The meta object literal for the '<em><b>Transitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__TRANSITIONS = eINSTANCE.getProcess_Transitions();

		/**
		 * The meta object literal for the '<em><b>Annotations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__ANNOTATIONS = eINSTANCE.getProcess_Annotations();

		/**
		 * The meta object literal for the '{@link UMS.impl.ActivityImpl <em>Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.ActivityImpl
		 * @see UMS.impl.UMSPackageImpl#getActivity()
		 * @generated
		 */
		EClass ACTIVITY = eINSTANCE.getActivity();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTIVITY__NAME = eINSTANCE.getActivity_Name();

		/**
		 * The meta object literal for the '<em><b>Precondition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTIVITY__PRECONDITION = eINSTANCE.getActivity_Precondition();

		/**
		 * The meta object literal for the '<em><b>Effect</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTIVITY__EFFECT = eINSTANCE.getActivity_Effect();

		/**
		 * The meta object literal for the '{@link UMS.impl.InputActivityImpl <em>Input Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.InputActivityImpl
		 * @see UMS.impl.UMSPackageImpl#getInputActivity()
		 * @generated
		 */
		EClass INPUT_ACTIVITY = eINSTANCE.getInputActivity();

		/**
		 * The meta object literal for the '<em><b>Incomingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_ACTIVITY__INCOMINGTRANSITION = eINSTANCE.getInputActivity_Incomingtransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.OutputActivityImpl <em>Output Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.OutputActivityImpl
		 * @see UMS.impl.UMSPackageImpl#getOutputActivity()
		 * @generated
		 */
		EClass OUTPUT_ACTIVITY = eINSTANCE.getOutputActivity();

		/**
		 * The meta object literal for the '<em><b>Outgoingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTPUT_ACTIVITY__OUTGOINGTRANSITION = eINSTANCE.getOutputActivity_Outgoingtransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.AbstractActivityImpl <em>Abstract Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.AbstractActivityImpl
		 * @see UMS.impl.UMSPackageImpl#getAbstractActivity()
		 * @generated
		 */
		EClass ABSTRACT_ACTIVITY = eINSTANCE.getAbstractActivity();

		/**
		 * The meta object literal for the '<em><b>Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_ACTIVITY__GOAL = eINSTANCE.getAbstractActivity_Goal();

		/**
		 * The meta object literal for the '{@link UMS.impl.ConcreteActivityImpl <em>Concrete Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.ConcreteActivityImpl
		 * @see UMS.impl.UMSPackageImpl#getConcreteActivity()
		 * @generated
		 */
		EClass CONCRETE_ACTIVITY = eINSTANCE.getConcreteActivity();

		/**
		 * The meta object literal for the '{@link UMS.impl.StateImpl <em>State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.StateImpl
		 * @see UMS.impl.UMSPackageImpl#getState()
		 * @generated
		 */
		EClass STATE = eINSTANCE.getState();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__NAME = eINSTANCE.getState_Name();

		/**
		 * The meta object literal for the '<em><b>Is Initial</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__IS_INITIAL = eINSTANCE.getState_IsInitial();

		/**
		 * The meta object literal for the '<em><b>Incomingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__INCOMINGTRANSITION = eINSTANCE.getState_Incomingtransition();

		/**
		 * The meta object literal for the '<em><b>Outgoingtransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__OUTGOINGTRANSITION = eINSTANCE.getState_Outgoingtransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.TransitionImpl <em>Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.TransitionImpl
		 * @see UMS.impl.UMSPackageImpl#getTransition()
		 * @generated
		 */
		EClass TRANSITION = eINSTANCE.getTransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.OutgoingTransitionImpl <em>Outgoing Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.OutgoingTransitionImpl
		 * @see UMS.impl.UMSPackageImpl#getOutgoingTransition()
		 * @generated
		 */
		EClass OUTGOING_TRANSITION = eINSTANCE.getOutgoingTransition();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_TRANSITION__STATE = eINSTANCE.getOutgoingTransition_State();

		/**
		 * The meta object literal for the '<em><b>Outputactivity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_TRANSITION__OUTPUTACTIVITY = eINSTANCE.getOutgoingTransition_Outputactivity();

		/**
		 * The meta object literal for the '{@link UMS.impl.IncomingTransitionImpl <em>Incoming Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.IncomingTransitionImpl
		 * @see UMS.impl.UMSPackageImpl#getIncomingTransition()
		 * @generated
		 */
		EClass INCOMING_TRANSITION = eINSTANCE.getIncomingTransition();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_TRANSITION__STATE = eINSTANCE.getIncomingTransition_State();

		/**
		 * The meta object literal for the '<em><b>Inputactivity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_TRANSITION__INPUTACTIVITY = eINSTANCE.getIncomingTransition_Inputactivity();

		/**
		 * The meta object literal for the '{@link UMS.impl.AnnotationImpl <em>Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.AnnotationImpl
		 * @see UMS.impl.UMSPackageImpl#getAnnotation()
		 * @generated
		 */
		EClass ANNOTATION = eINSTANCE.getAnnotation();

		/**
		 * The meta object literal for the '{@link UMS.impl.PreconditionImpl <em>Precondition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.PreconditionImpl
		 * @see UMS.impl.UMSPackageImpl#getPrecondition()
		 * @generated
		 */
		EClass PRECONDITION = eINSTANCE.getPrecondition();

		/**
		 * The meta object literal for the '<em><b>Activity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRECONDITION__ACTIVITY = eINSTANCE.getPrecondition_Activity();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRECONDITION__LSTATE = eINSTANCE.getPrecondition_Lstate();

		/**
		 * The meta object literal for the '{@link UMS.impl.EffectImpl <em>Effect</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.EffectImpl
		 * @see UMS.impl.UMSPackageImpl#getEffect()
		 * @generated
		 */
		EClass EFFECT = eINSTANCE.getEffect();

		/**
		 * The meta object literal for the '<em><b>Activity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EFFECT__ACTIVITY = eINSTANCE.getEffect_Activity();

		/**
		 * The meta object literal for the '<em><b>Levent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EFFECT__LEVENT = eINSTANCE.getEffect_Levent();

		/**
		 * The meta object literal for the '{@link UMS.impl.GoalImpl <em>Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.GoalImpl
		 * @see UMS.impl.UMSPackageImpl#getGoal()
		 * @generated
		 */
		EClass GOAL = eINSTANCE.getGoal();

		/**
		 * The meta object literal for the '<em><b>Abstractactivity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__ABSTRACTACTIVITY = eINSTANCE.getGoal_Abstractactivity();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__LSTATE = eINSTANCE.getGoal_Lstate();

		/**
		 * The meta object literal for the '{@link UMS.impl.DomainPropertyImpl <em>Domain Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.DomainPropertyImpl
		 * @see UMS.impl.UMSPackageImpl#getDomainProperty()
		 * @generated
		 */
		EClass DOMAIN_PROPERTY = eINSTANCE.getDomainProperty();

		/**
		 * The meta object literal for the '<em><b>Lstates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LSTATES = eINSTANCE.getDomainProperty_Lstates();

		/**
		 * The meta object literal for the '<em><b>Linitialstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LINITIALSTATE = eINSTANCE.getDomainProperty_Linitialstate();

		/**
		 * The meta object literal for the '<em><b>Levents</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LEVENTS = eINSTANCE.getDomainProperty_Levents();

		/**
		 * The meta object literal for the '<em><b>Ltransitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN_PROPERTY__LTRANSITIONS = eINSTANCE.getDomainProperty_Ltransitions();

		/**
		 * The meta object literal for the '{@link UMS.impl.LStateImpl <em>LState</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.LStateImpl
		 * @see UMS.impl.UMSPackageImpl#getLState()
		 * @generated
		 */
		EClass LSTATE = eINSTANCE.getLState();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LSTATE__NAME = eINSTANCE.getLState_Name();

		/**
		 * The meta object literal for the '<em><b>Incomingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LSTATE__INCOMINGLTRANSITION = eINSTANCE.getLState_Incomingltransition();

		/**
		 * The meta object literal for the '<em><b>Outgoingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LSTATE__OUTGOINGLTRANSITION = eINSTANCE.getLState_Outgoingltransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.LInitialStateImpl <em>LInitial State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.LInitialStateImpl
		 * @see UMS.impl.UMSPackageImpl#getLInitialState()
		 * @generated
		 */
		EClass LINITIAL_STATE = eINSTANCE.getLInitialState();

		/**
		 * The meta object literal for the '<em><b>Outgoingltransition IS</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LINITIAL_STATE__OUTGOINGLTRANSITION_IS = eINSTANCE.getLInitialState_OutgoingltransitionIS();

		/**
		 * The meta object literal for the '{@link UMS.impl.LEventImpl <em>LEvent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.LEventImpl
		 * @see UMS.impl.UMSPackageImpl#getLEvent()
		 * @generated
		 */
		EClass LEVENT = eINSTANCE.getLEvent();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LEVENT__NAME = eINSTANCE.getLEvent_Name();

		/**
		 * The meta object literal for the '<em><b>Outgoingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LEVENT__OUTGOINGLTRANSITION = eINSTANCE.getLEvent_Outgoingltransition();

		/**
		 * The meta object literal for the '<em><b>Incomingltransition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LEVENT__INCOMINGLTRANSITION = eINSTANCE.getLEvent_Incomingltransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.LTransitionImpl <em>LTransition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.LTransitionImpl
		 * @see UMS.impl.UMSPackageImpl#getLTransition()
		 * @generated
		 */
		EClass LTRANSITION = eINSTANCE.getLTransition();

		/**
		 * The meta object literal for the '{@link UMS.impl.IncomingLTransitionImpl <em>Incoming LTransition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.IncomingLTransitionImpl
		 * @see UMS.impl.UMSPackageImpl#getIncomingLTransition()
		 * @generated
		 */
		EClass INCOMING_LTRANSITION = eINSTANCE.getIncomingLTransition();

		/**
		 * The meta object literal for the '<em><b>Levent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_LTRANSITION__LEVENT = eINSTANCE.getIncomingLTransition_Levent();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCOMING_LTRANSITION__LSTATE = eINSTANCE.getIncomingLTransition_Lstate();

		/**
		 * The meta object literal for the '{@link UMS.impl.OutgoingLTransitionImpl <em>Outgoing LTransition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.OutgoingLTransitionImpl
		 * @see UMS.impl.UMSPackageImpl#getOutgoingLTransition()
		 * @generated
		 */
		EClass OUTGOING_LTRANSITION = eINSTANCE.getOutgoingLTransition();

		/**
		 * The meta object literal for the '<em><b>Linitialstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_LTRANSITION__LINITIALSTATE = eINSTANCE.getOutgoingLTransition_Linitialstate();

		/**
		 * The meta object literal for the '<em><b>Levent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_LTRANSITION__LEVENT = eINSTANCE.getOutgoingLTransition_Levent();

		/**
		 * The meta object literal for the '<em><b>Lstate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTGOING_LTRANSITION__LSTATE = eINSTANCE.getOutgoingLTransition_Lstate();

		/**
		 * The meta object literal for the '{@link UMS.impl.AdaptiveSystemImpl <em>Adaptive System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UMS.impl.AdaptiveSystemImpl
		 * @see UMS.impl.UMSPackageImpl#getAdaptiveSystem()
		 * @generated
		 */
		EClass ADAPTIVE_SYSTEM = eINSTANCE.getAdaptiveSystem();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADAPTIVE_SYSTEM__NAME = eINSTANCE.getAdaptiveSystem_Name();

		/**
		 * The meta object literal for the '<em><b>Domainobjects</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADAPTIVE_SYSTEM__DOMAINOBJECTS = eINSTANCE.getAdaptiveSystem_Domainobjects();

	}

} //UMSPackage
