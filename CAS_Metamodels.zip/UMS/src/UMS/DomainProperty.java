/**
 */
package UMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Domain Property</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link UMS.DomainProperty#getLstates <em>Lstates</em>}</li>
 *   <li>{@link UMS.DomainProperty#getLinitialstate <em>Linitialstate</em>}</li>
 *   <li>{@link UMS.DomainProperty#getLevents <em>Levents</em>}</li>
 *   <li>{@link UMS.DomainProperty#getLtransitions <em>Ltransitions</em>}</li>
 * </ul>
 *
 * @see UMS.UMSPackage#getDomainProperty()
 * @model
 * @generated
 */
public interface DomainProperty extends EObject {
	/**
	 * Returns the value of the '<em><b>Lstates</b></em>' containment reference list.
	 * The list contents are of type {@link UMS.LState}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lstates</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lstates</em>' containment reference list.
	 * @see UMS.UMSPackage#getDomainProperty_Lstates()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<LState> getLstates();

	/**
	 * Returns the value of the '<em><b>Linitialstate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Linitialstate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Linitialstate</em>' reference.
	 * @see #setLinitialstate(LInitialState)
	 * @see UMS.UMSPackage#getDomainProperty_Linitialstate()
	 * @model required="true"
	 * @generated
	 */
	LInitialState getLinitialstate();

	/**
	 * Sets the value of the '{@link UMS.DomainProperty#getLinitialstate <em>Linitialstate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Linitialstate</em>' reference.
	 * @see #getLinitialstate()
	 * @generated
	 */
	void setLinitialstate(LInitialState value);

	/**
	 * Returns the value of the '<em><b>Levents</b></em>' containment reference list.
	 * The list contents are of type {@link UMS.LEvent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Levents</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Levents</em>' containment reference list.
	 * @see UMS.UMSPackage#getDomainProperty_Levents()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<LEvent> getLevents();

	/**
	 * Returns the value of the '<em><b>Ltransitions</b></em>' containment reference list.
	 * The list contents are of type {@link UMS.LTransition}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ltransitions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ltransitions</em>' containment reference list.
	 * @see UMS.UMSPackage#getDomainProperty_Ltransitions()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<LTransition> getLtransitions();

} // DomainProperty
