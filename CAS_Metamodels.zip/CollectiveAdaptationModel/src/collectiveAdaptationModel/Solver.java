/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.ecore.EObject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solver</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getSolver()
 * @model
 * @generated
 */
public interface Solver extends EObject {
} // Solver
