/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.Event#getAdaptation <em>Adaptation</em>}</li>
 *   <li>{@link collectiveAdaptationModel.Event#getIssue <em>Issue</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEvent()
 * @model
 * @generated
 */
public interface Event extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Adaptation</b></em>' reference list.
	 * The list contents are of type {@link collectiveAdaptationModel.Adaptation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adaptation</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adaptation</em>' reference list.
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEvent_Adaptation()
	 * @model
	 * @generated
	 */
	EList<Adaptation> getAdaptation();

	/**
	 * Returns the value of the '<em><b>Issue</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Issue</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Issue</em>' reference.
	 * @see #setIssue(IssueType)
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEvent_Issue()
	 * @model required="true"
	 * @generated
	 */
	IssueType getIssue();

	/**
	 * Sets the value of the '{@link collectiveAdaptationModel.Event#getIssue <em>Issue</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Issue</em>' reference.
	 * @see #getIssue()
	 * @generated
	 */
	void setIssue(IssueType value);

} // Event
