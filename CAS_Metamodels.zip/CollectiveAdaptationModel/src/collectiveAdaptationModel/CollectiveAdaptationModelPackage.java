/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see collectiveAdaptationModel.CollectiveAdaptationModelFactory
 * @model kind="package"
 * @generated
 */
public interface CollectiveAdaptationModelPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "collectiveAdaptationModel";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/collectiveAdaptationModel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "collectiveAdaptationModel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CollectiveAdaptationModelPackage eINSTANCE = collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl.init();

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.CollectiveAdaptationImpl <em>Collective Adaptation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getCollectiveAdaptation()
	 * @generated
	 */
	int COLLECTIVE_ADAPTATION = 0;

	/**
	 * The feature id for the '<em><b>Eventhandlers</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLECTIVE_ADAPTATION__EVENTHANDLERS = 0;

	/**
	 * The number of structural features of the '<em>Collective Adaptation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLECTIVE_ADAPTATION_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Collective Adaptation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLECTIVE_ADAPTATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.NamedElementImpl <em>Named Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.NamedElementImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getNamedElement()
	 * @generated
	 */
	int NAMED_ELEMENT = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT__NAME = 0;

	/**
	 * The number of structural features of the '<em>Named Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Named Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.EventHandlerImpl <em>Event Handler</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.EventHandlerImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getEventHandler()
	 * @generated
	 */
	int EVENT_HANDLER = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_HANDLER__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Event</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_HANDLER__EVENT = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Triggered Adaptations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_HANDLER__TRIGGERED_ADAPTATIONS = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Scope</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_HANDLER__SCOPE = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Event Handler</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_HANDLER_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Event Handler</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_HANDLER_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.EventImpl <em>Event</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.EventImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getEvent()
	 * @generated
	 */
	int EVENT = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Adaptation</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__ADAPTATION = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Issue</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__ISSUE = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.AdaptationImpl <em>Adaptation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.AdaptationImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getAdaptation()
	 * @generated
	 */
	int ADAPTATION = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Solver</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION__SOLVER = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Adaptation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Adaptation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAPTATION_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.RoleActivityImpl <em>Role Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.RoleActivityImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getRoleActivity()
	 * @generated
	 */
	int ROLE_ACTIVITY = 4;

	/**
	 * The number of structural features of the '<em>Role Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ACTIVITY_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Role Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ACTIVITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.IssueTypeImpl <em>Issue Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.IssueTypeImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getIssueType()
	 * @generated
	 */
	int ISSUE_TYPE = 5;

	/**
	 * The number of structural features of the '<em>Issue Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Issue Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISSUE_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link collectiveAdaptationModel.impl.SolverImpl <em>Solver</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see collectiveAdaptationModel.impl.SolverImpl
	 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getSolver()
	 * @generated
	 */
	int SOLVER = 6;

	/**
	 * The number of structural features of the '<em>Solver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Solver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLVER_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.CollectiveAdaptation <em>Collective Adaptation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collective Adaptation</em>'.
	 * @see collectiveAdaptationModel.CollectiveAdaptation
	 * @generated
	 */
	EClass getCollectiveAdaptation();

	/**
	 * Returns the meta object for the containment reference list '{@link collectiveAdaptationModel.CollectiveAdaptation#getEventhandlers <em>Eventhandlers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Eventhandlers</em>'.
	 * @see collectiveAdaptationModel.CollectiveAdaptation#getEventhandlers()
	 * @see #getCollectiveAdaptation()
	 * @generated
	 */
	EReference getCollectiveAdaptation_Eventhandlers();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.EventHandler <em>Event Handler</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Event Handler</em>'.
	 * @see collectiveAdaptationModel.EventHandler
	 * @generated
	 */
	EClass getEventHandler();

	/**
	 * Returns the meta object for the containment reference list '{@link collectiveAdaptationModel.EventHandler#getEvent <em>Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Event</em>'.
	 * @see collectiveAdaptationModel.EventHandler#getEvent()
	 * @see #getEventHandler()
	 * @generated
	 */
	EReference getEventHandler_Event();

	/**
	 * Returns the meta object for the containment reference list '{@link collectiveAdaptationModel.EventHandler#getTriggeredAdaptations <em>Triggered Adaptations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Triggered Adaptations</em>'.
	 * @see collectiveAdaptationModel.EventHandler#getTriggeredAdaptations()
	 * @see #getEventHandler()
	 * @generated
	 */
	EReference getEventHandler_TriggeredAdaptations();

	/**
	 * Returns the meta object for the reference list '{@link collectiveAdaptationModel.EventHandler#getScope <em>Scope</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Scope</em>'.
	 * @see collectiveAdaptationModel.EventHandler#getScope()
	 * @see #getEventHandler()
	 * @generated
	 */
	EReference getEventHandler_Scope();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.Event <em>Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Event</em>'.
	 * @see collectiveAdaptationModel.Event
	 * @generated
	 */
	EClass getEvent();

	/**
	 * Returns the meta object for the reference list '{@link collectiveAdaptationModel.Event#getAdaptation <em>Adaptation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Adaptation</em>'.
	 * @see collectiveAdaptationModel.Event#getAdaptation()
	 * @see #getEvent()
	 * @generated
	 */
	EReference getEvent_Adaptation();

	/**
	 * Returns the meta object for the reference '{@link collectiveAdaptationModel.Event#getIssue <em>Issue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Issue</em>'.
	 * @see collectiveAdaptationModel.Event#getIssue()
	 * @see #getEvent()
	 * @generated
	 */
	EReference getEvent_Issue();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.Adaptation <em>Adaptation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Adaptation</em>'.
	 * @see collectiveAdaptationModel.Adaptation
	 * @generated
	 */
	EClass getAdaptation();

	/**
	 * Returns the meta object for the reference '{@link collectiveAdaptationModel.Adaptation#getSolver <em>Solver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Solver</em>'.
	 * @see collectiveAdaptationModel.Adaptation#getSolver()
	 * @see #getAdaptation()
	 * @generated
	 */
	EReference getAdaptation_Solver();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.RoleActivity <em>Role Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Activity</em>'.
	 * @see collectiveAdaptationModel.RoleActivity
	 * @generated
	 */
	EClass getRoleActivity();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.IssueType <em>Issue Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Issue Type</em>'.
	 * @see collectiveAdaptationModel.IssueType
	 * @generated
	 */
	EClass getIssueType();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.Solver <em>Solver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solver</em>'.
	 * @see collectiveAdaptationModel.Solver
	 * @generated
	 */
	EClass getSolver();

	/**
	 * Returns the meta object for class '{@link collectiveAdaptationModel.NamedElement <em>Named Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Named Element</em>'.
	 * @see collectiveAdaptationModel.NamedElement
	 * @generated
	 */
	EClass getNamedElement();

	/**
	 * Returns the meta object for the attribute '{@link collectiveAdaptationModel.NamedElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see collectiveAdaptationModel.NamedElement#getName()
	 * @see #getNamedElement()
	 * @generated
	 */
	EAttribute getNamedElement_Name();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CollectiveAdaptationModelFactory getCollectiveAdaptationModelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.CollectiveAdaptationImpl <em>Collective Adaptation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getCollectiveAdaptation()
		 * @generated
		 */
		EClass COLLECTIVE_ADAPTATION = eINSTANCE.getCollectiveAdaptation();

		/**
		 * The meta object literal for the '<em><b>Eventhandlers</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLECTIVE_ADAPTATION__EVENTHANDLERS = eINSTANCE.getCollectiveAdaptation_Eventhandlers();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.EventHandlerImpl <em>Event Handler</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.EventHandlerImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getEventHandler()
		 * @generated
		 */
		EClass EVENT_HANDLER = eINSTANCE.getEventHandler();

		/**
		 * The meta object literal for the '<em><b>Event</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT_HANDLER__EVENT = eINSTANCE.getEventHandler_Event();

		/**
		 * The meta object literal for the '<em><b>Triggered Adaptations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT_HANDLER__TRIGGERED_ADAPTATIONS = eINSTANCE.getEventHandler_TriggeredAdaptations();

		/**
		 * The meta object literal for the '<em><b>Scope</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT_HANDLER__SCOPE = eINSTANCE.getEventHandler_Scope();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.EventImpl <em>Event</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.EventImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getEvent()
		 * @generated
		 */
		EClass EVENT = eINSTANCE.getEvent();

		/**
		 * The meta object literal for the '<em><b>Adaptation</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT__ADAPTATION = eINSTANCE.getEvent_Adaptation();

		/**
		 * The meta object literal for the '<em><b>Issue</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT__ISSUE = eINSTANCE.getEvent_Issue();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.AdaptationImpl <em>Adaptation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.AdaptationImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getAdaptation()
		 * @generated
		 */
		EClass ADAPTATION = eINSTANCE.getAdaptation();

		/**
		 * The meta object literal for the '<em><b>Solver</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADAPTATION__SOLVER = eINSTANCE.getAdaptation_Solver();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.RoleActivityImpl <em>Role Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.RoleActivityImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getRoleActivity()
		 * @generated
		 */
		EClass ROLE_ACTIVITY = eINSTANCE.getRoleActivity();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.IssueTypeImpl <em>Issue Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.IssueTypeImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getIssueType()
		 * @generated
		 */
		EClass ISSUE_TYPE = eINSTANCE.getIssueType();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.SolverImpl <em>Solver</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.SolverImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getSolver()
		 * @generated
		 */
		EClass SOLVER = eINSTANCE.getSolver();

		/**
		 * The meta object literal for the '{@link collectiveAdaptationModel.impl.NamedElementImpl <em>Named Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see collectiveAdaptationModel.impl.NamedElementImpl
		 * @see collectiveAdaptationModel.impl.CollectiveAdaptationModelPackageImpl#getNamedElement()
		 * @generated
		 */
		EClass NAMED_ELEMENT = eINSTANCE.getNamedElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAMED_ELEMENT__NAME = eINSTANCE.getNamedElement_Name();

	}

} //CollectiveAdaptationModelPackage
