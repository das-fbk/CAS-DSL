/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Handler</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.EventHandler#getEvent <em>Event</em>}</li>
 *   <li>{@link collectiveAdaptationModel.EventHandler#getTriggeredAdaptations <em>Triggered Adaptations</em>}</li>
 *   <li>{@link collectiveAdaptationModel.EventHandler#getScope <em>Scope</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEventHandler()
 * @model
 * @generated
 */
public interface EventHandler extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Event</b></em>' containment reference list.
	 * The list contents are of type {@link collectiveAdaptationModel.Event}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' containment reference list.
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEventHandler_Event()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Event> getEvent();

	/**
	 * Returns the value of the '<em><b>Triggered Adaptations</b></em>' containment reference list.
	 * The list contents are of type {@link collectiveAdaptationModel.Adaptation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Triggered Adaptations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Triggered Adaptations</em>' containment reference list.
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEventHandler_TriggeredAdaptations()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Adaptation> getTriggeredAdaptations();

	/**
	 * Returns the value of the '<em><b>Scope</b></em>' reference list.
	 * The list contents are of type {@link collectiveAdaptationModel.RoleActivity}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scope</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scope</em>' reference list.
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getEventHandler_Scope()
	 * @model required="true"
	 * @generated
	 */
	EList<RoleActivity> getScope();

} // EventHandler
