/**
 */
package collectiveAdaptationModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Adaptation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.Adaptation#getSolver <em>Solver</em>}</li>
 * </ul>
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getAdaptation()
 * @model
 * @generated
 */
public interface Adaptation extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Solver</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Solver</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Solver</em>' reference.
	 * @see #setSolver(Solver)
	 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getAdaptation_Solver()
	 * @model required="true"
	 * @generated
	 */
	Solver getSolver();

	/**
	 * Sets the value of the '{@link collectiveAdaptationModel.Adaptation#getSolver <em>Solver</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Solver</em>' reference.
	 * @see #getSolver()
	 * @generated
	 */
	void setSolver(Solver value);

} // Adaptation
