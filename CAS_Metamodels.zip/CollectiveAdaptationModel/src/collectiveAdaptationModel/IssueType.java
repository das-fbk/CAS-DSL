/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.ecore.EObject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Issue Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getIssueType()
 * @model
 * @generated
 */
public interface IssueType extends EObject {
} // IssueType
