/**
 */
package collectiveAdaptationModel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see collectiveAdaptationModel.CollectiveAdaptationModelPackage#getRoleActivity()
 * @model
 * @generated
 */
public interface RoleActivity extends EObject {
} // RoleActivity
