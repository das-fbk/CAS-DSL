/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.Solver;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Solver</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SolverImpl extends MinimalEObjectImpl.Container implements Solver {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SolverImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.SOLVER;
	}

} //SolverImpl
