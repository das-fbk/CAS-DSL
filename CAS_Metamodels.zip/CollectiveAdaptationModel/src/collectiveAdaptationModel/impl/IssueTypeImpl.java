/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.IssueType;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Issue Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IssueTypeImpl extends MinimalEObjectImpl.Container implements IssueType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IssueTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.ISSUE_TYPE;
	}

} //IssueTypeImpl
