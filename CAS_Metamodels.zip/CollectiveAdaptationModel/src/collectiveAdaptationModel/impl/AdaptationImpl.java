/**
 */
package collectiveAdaptationModel.impl;

import collectiveAdaptationModel.Adaptation;
import collectiveAdaptationModel.CollectiveAdaptationModelPackage;
import collectiveAdaptationModel.Solver;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Adaptation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link collectiveAdaptationModel.impl.AdaptationImpl#getSolver <em>Solver</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AdaptationImpl extends NamedElementImpl implements Adaptation {
	/**
	 * The cached value of the '{@link #getSolver() <em>Solver</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSolver()
	 * @generated
	 * @ordered
	 */
	protected Solver solver;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AdaptationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollectiveAdaptationModelPackage.Literals.ADAPTATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Solver getSolver() {
		if (solver != null && solver.eIsProxy()) {
			InternalEObject oldSolver = (InternalEObject)solver;
			solver = (Solver)eResolveProxy(oldSolver);
			if (solver != oldSolver) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollectiveAdaptationModelPackage.ADAPTATION__SOLVER, oldSolver, solver));
			}
		}
		return solver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Solver basicGetSolver() {
		return solver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSolver(Solver newSolver) {
		Solver oldSolver = solver;
		solver = newSolver;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollectiveAdaptationModelPackage.ADAPTATION__SOLVER, oldSolver, solver));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ADAPTATION__SOLVER:
				if (resolve) return getSolver();
				return basicGetSolver();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ADAPTATION__SOLVER:
				setSolver((Solver)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ADAPTATION__SOLVER:
				setSolver((Solver)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollectiveAdaptationModelPackage.ADAPTATION__SOLVER:
				return solver != null;
		}
		return super.eIsSet(featureID);
	}

} //AdaptationImpl
