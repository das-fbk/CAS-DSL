/**
 */
package collectiveAdaptationModel.tests;

import collectiveAdaptationModel.CollectiveAdaptationModelFactory;
import collectiveAdaptationModel.RoleActivity;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Role Activity</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class RoleActivityTest extends TestCase {

	/**
	 * The fixture for this Role Activity test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleActivity fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(RoleActivityTest.class);
	}

	/**
	 * Constructs a new Role Activity test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleActivityTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Role Activity test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(RoleActivity fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Role Activity test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleActivity getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(CollectiveAdaptationModelFactory.eINSTANCE.createRoleActivity());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //RoleActivityTest
